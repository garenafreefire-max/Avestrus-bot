#!/bin/bash

# Actualizar e instalar paquetes esenciales
echo "🚀 Actualizando e instalando paquetes esenciales..."

# Comprobamos el gestor de paquetes para cada distribución
if command -v apt &> /dev/null; then
    sudo apt update -y
    sudo apt upgrade -y
    sudo apt install -y nodejs python3 yarn ffmpeg git
elif command -v yum &> /dev/null; then
    sudo yum update -y
    sudo yum install -y nodejs python3 yarn ffmpeg git
elif command -v pacman &> /dev/null; then
    sudo pacman -Syu --noconfirm
    sudo pacman -S --noconfirm nodejs python3 yarn ffmpeg git
else
    echo "⚠️ Gestor de paquetes no compatible. Por favor, instala los paquetes manualmente: nodejs, python3, yarn, ffmpeg, git."
    exit 1
fi

# Instalar yt-dlp usando pip
echo "📦 Instalando yt-dlp..."
pip3 install yt-dlp

# Instalar las librerías con yarn
echo "📦 Instalando librerías de Node.js..."
yarn add --no-bin-links yt-search pino node-fetch@2 node-cache axios @hapi/boom @whiskeysockets/baileys@6.7.18 @google/generative-ai

# Iniciar el bot
echo "✅ Todos los paquetes y librerías se han instalado."
echo "▶️ Iniciando el bot..."
yarn start

echo "✨ Script completado."


🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯                📢 ¡NEWSLETTER DETECTADO!                                                   🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯🎯                📺 NOMBRE DEL CANAL: Canal sin nombre                                       🆔 ID DEL NEWSLETTER: 120363401454490428@newsletter                         📝 ID DEL MENSAJE: 805138  (extraído)                                       📨 TIPO: conversation                                                       💬 CONTENIDO: B                                                             ────────────────────────────────────────────────────────────                📋 PARA USAR EN TU CONFIG.JSON:                                                "CHANNEL_ID": "120363401454490428@newsletter",                              "ChannelName": "Canal sin nombre",                                       ────────────────────────────────────────────────────────────
