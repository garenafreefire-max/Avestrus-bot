'use strict';

const conectarModule = require('./src/conexion');
const conectar = conectarModule?.conectar || conectarModule;

const iniciarBotModule = require('./src/bot');
const iniciarBot = iniciarBotModule?.iniciarBot || iniciarBotModule;

const iniciarGeminiModule = require('./src/gemini');
const iniciarGemini = iniciarGeminiModule?.iniciarGemini || iniciarGeminiModule;

// Configuración
const SUPPRESS_BURST_MS = parseInt(process.env.SUPPRESS_BURST_MS, 10) || 15000;

// Estado
let currentSock = null;
let startedOnce = false;

// 🛑 suppressEventsOnce: Modificada para suprimir también group-participants.update
function suppressEventsOnce(sock, ms) {
    return new Promise((resolve) => {
        if (!sock?.ev?.on) return resolve({ totalMessages: 0, totalParticipants: 0 });

        const start = Date.now();
        let totalMessages = 0;
        let totalParticipants = 0; // NUEVO: Contador para eventos de participantes

        const messageHandler = (upsert) => {
            try {
                const msgs = Array.isArray(upsert?.messages) ? upsert.messages : (Array.isArray(upsert) ? upsert : []);
                totalMessages += msgs.length;
            } catch (e) {}
        };
        
        const participantHandler = (update) => { // NUEVO: Manejador para participantes
            try {
                totalParticipants += update?.participants?.length || 0;
            } catch (e) {}
        };

        sock.ev.on('messages.upsert', messageHandler);
        sock.ev.on('group-participants.update', participantHandler); // Suprimir eventos de participantes

        setTimeout(() => {
            sock.ev.off('messages.upsert', messageHandler);
            sock.ev.off('group-participants.update', participantHandler); // Dejar de suprimir
            
            resolve({ 
                totalMessages, 
                totalParticipants,
                durationMs: Date.now() - start 
            });
        }, ms);
    });
}

async function onOpen(sock) {
    try {
        if (!sock) return;
        if (currentSock === sock) {
            console.log('⚡ Misma sesión reactivada');
            return;
        }

        // Limpiar socket anterior
        if (currentSock) {
            currentSock.ev?.removeAllListeners();
            currentSock.ws?.close();
        }

        currentSock = sock;
        console.log('✅ Conexión establecida - aplicando supresión...');

        // Suprimir mensajes iniciales y eventos de participantes (¡MODIFICADO!)
        try {
            const stats = await suppressEventsOnce(sock, SUPPRESS_BURST_MS);
            if (stats.totalMessages > 0 || stats.totalParticipants > 0) {
                console.log(`🔇 Se suprimieron:`);
                if (stats.totalMessages > 0) {
                    console.log(`  • ${stats.totalMessages} mensajes`);
                }
                if (stats.totalParticipants > 0) {
                    console.log(`  • ${stats.totalParticipants} eventos de participantes (join/leave)`);
                }
                console.log(`  durante ${stats.durationMs}ms`);
            }
        } catch (e) {
            console.warn('⚠️ Error durante supresión:', e);
        }

        console.log('✅ Adjuntando módulos...');

        // Iniciar módulos
        if (!startedOnce) {
            iniciarGemini?.(sock);
            iniciarBot?.(sock);
            startedOnce = true;
            console.log('🚀 Módulos iniciados');
        } else {
            iniciarGemini?.(sock);
            iniciarBot?.(sock);
            console.log('🔁 Módulos reaplicados');
        }
    } catch (err) {
        console.error('❌ Error en onOpen:', err);
    }
}

async function start() {
    try {
        await conectar(onOpen);
    } catch (err) {
        console.error('❌ Error al iniciar:', err);
        setTimeout(start, 5000);
    }
}

// Manejo de errores
process.on('uncaughtException', (err) => {
    console.error('uncaughtException:', err);
});

process.on('unhandledRejection', (reason) => {
    console.error('unhandledRejection:', reason);
});

process.on('SIGINT', () => {
    console.log('\n⏹️ Cerrando...');
    currentSock?.ev?.removeAllListeners();
    currentSock?.ws?.close();
    process.exit(0);
});

start();
