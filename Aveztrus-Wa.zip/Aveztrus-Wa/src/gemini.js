const fs = require('fs').promises;
const fsp = require('fs').promises;
const path = require('path');
const { GoogleGenerativeAI } = require("@google/generative-ai");
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const config = require('../config.json');

// 🌀 Diccionario de letras fancy
const reemplazosFancy = {
  A:"𝑨", B:"𝑩", C:"𝑪", D:"𝑫", E:"𝑬", F:"𝑭", G:"𝑮",
  H:"𝑯", I:"𝑰", J:"𝑱", K:"𝑲", L:"𝑳", M:"𝑴", N:"𝑵",
  O:"𝑶", P:"𝑷", Q:"𝑸", R:"𝑹", S:"𝑺", T:"𝑻", U:"𝑼",
  V:"𝑽", W:"𝑾", X:"𝑿", Y:"𝒀", Z:"𝒁",
  a:"𝒂", b:"𝒃", c:"𝒄", d:"𝒅", e:"𝒆", f:"𝒇", g:"𝒈",
  h:"𝒉", i:"𝒊", j:"𝒋", k:"𝒌", l:"𝒍", m:"𝒎", n:"𝒏",
  o:"𝒐", p:"𝒑", q:"𝒒", r:"𝒓", s:"𝒔", t:"𝒕", u:"𝒖",
  v:"𝒗", w:"𝒘", x:"𝒙", y:"𝒚", z:"𝒛",
  // Ñ/ñ usando tilde combinante U+0303
  "Ñ": "𝑵̃",
  "ñ": "𝒏̃"
};

// Función de conversión (mejorada) �? maneja bien Unicode y normaliza
function convertirAFancy(texto) {
  return [...texto].map(ch => reemplazosFancy[ch] ?? ch).join("").normalize("NFC");
}

// 🌀 Función para convertir texto normal a fancy
function convertirAFancy(texto) {
    return texto.split("").map(letra => reemplazosFancy[letra] || letra).join("");
}
// Configurar directorio de memoria
const memoryPath = path.join(__dirname, './database/memory/gemini');
fs.mkdir(memoryPath, { recursive: true }).catch(err => console.error("Error creating memory directory:", err));

let sockInstance = null;
let enviarRespuestaFalsaTexto = null;
let getBotStatusFunction = null;

// Cache para nombres de usuarios y información
const cacheNombres = new Map();
const cacheRangos = new Map();
const cacheGrupos = new Map();
const CACHE_TIEMPO = 5 * 60 * 1000; // 5 minutos

// 🔥 NUEVA FUNCIÓN: Obtener fecha y hora actual
function obtenerFechaHoraActual() {
    const ahora = new Date();
    
    // Obtener componentes de fecha y hora
    const dia = ahora.getDate();
    const mes = ahora.getMonth() + 1; // Los meses van de 0-11
    const año = ahora.getFullYear() % 100; // Solo los últimos 2 dígitos
    
    const horas = ahora.getHours();
    const minutos = ahora.getMinutes();
    const segundos = ahora.getSeconds();
    
    // Formato de fecha: 5/2/6 (día/mes/año)
    const fechaFormateada = `${dia}/${mes}/${año}`;
    
    // Formato de hora: 4:94:40 (hora:minuto:segundo) - NOTA: En el ejemplo pusiste 4:94:40 pero 94 minutos no es válido
    // Asumo que quieres formato normal de 24 horas
    const horaFormateada = `${horas}:${minutos.toString().padStart(2, '0')}:${segundos.toString().padStart(2, '0')}`;
    
    return {
        fecha: fechaFormateada,
        hora: horaFormateada,
        fechaHora: `${fechaFormateada} - ${horaFormateada}`
    };
}

// 🔥 NUEVA FUNCIÓN: Verificar si el usuario es dueño del bot
function esDueñoDelBot(userJid) {
    if (!userJid) return false;
    
    // Normalizar JID
    const userJidNormalizado = userJid.includes('@') ? userJid : `${userJid}@s.whatsapp.net`;
    
    // Verificar contra los dueños configurados
    const identificadoresDueño = [
        ...(Array.isArray(config.Dueño) ? config.Dueño : [config.Dueño || '']),
        ...(config.DueñoLid ? (Array.isArray(config.DueñoLid) ? config.DueñoLid : [config.DueñoLid]) : [])
    ].filter(Boolean);
    
    return identificadoresDueño.some(dueñoId => {
        const dueñoNormalizado = dueñoId.includes('@') ? dueñoId : `${dueñoId}@s.whatsapp.net`;
        return dueñoNormalizado === userJidNormalizado;
    });
}

// 🔥 FUNCIÓN CORREGIDA: Descargar y procesar imagen para Gemini
async function procesarImagenParaGemini(sock, message) {
    const imageMessage = message.imageMessage;
    if (!imageMessage) return null;

    // 1. Definir la ruta temporal
    const tempDir = path.join(__dirname, 'media', 'temp', 'imagenes');
    try {
        await fsp.mkdir(tempDir, { recursive: true });
    } catch (e) {
        // Ignorar si ya existe
    }
    
    const tempFilePath = path.join(tempDir, `gemini_${Date.now()}.jpg`);

    try {
        console.log('🖼�? Imagen detectada, procesando...');

        // 2. Descargar la imagen como un stream y convertirla a buffer
        const stream = await downloadContentFromMessage(imageMessage, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        // 3. Guardar el buffer en un archivo temporal
        await fsp.writeFile(tempFilePath, buffer);

        // 4. Leer el archivo guardado y convertirlo a base64
        const fileBuffer = await fsp.readFile(tempFilePath);
        const base64Image = fileBuffer.toString('base64');
        const mimeType = imageMessage.mimetype;

        // Retornar el formato que Gemini necesita
        return {
            inlineData: {
                mimeType,
                data: base64Image,
            },
        };
    } catch (error) {
        console.error('Error procesando imagen para Gemini:', error);
        throw new Error('❌Error procesando imagen');
    } finally {
        // 5. Asegurarse de eliminar el archivo temporal después de usarlo
        try {
            await fsp.unlink(tempFilePath);
        } catch (e) {
            // Ignorar si el archivo no existe
        }
    }
}


// 🔥 NUEVA FUNCIÓN: Extraer información de mensaje con imagen
function extraerContenidoMensaje(message) {
    let textoCompleto = '';
    let tieneImagen = false;
    if (message) {
        if (message.conversation) {
            textoCompleto = message.conversation;
        } else if (message.extendedTextMessage?.text) {
            textoCompleto = message.extendedTextMessage.text;
        } else if (message.imageMessage?.caption) {
            textoCompleto = message.imageMessage.caption;
            tieneImagen = true;
        } else if (message.imageMessage) {
            textoCompleto = '';
            tieneImagen = true;
        } else if (message.videoMessage?.caption) {
            textoCompleto = message.videoMessage.caption;
        }
    }
    return {
        texto: textoCompleto,
        tieneImagen: tieneImagen,
        esImagenSola: tieneImagen && !textoCompleto.trim()
    };
}

// Inicializar Gemini
function iniciarGemini(sock) {
    sockInstance = sock;
    
    // Escuchar eventos de actualización de participantes
    if (sock && sock.ev) {
        sock.ev.on('group-participants.update', async (update) => {
            try {
                const { id, participants, action } = update;
                
                if (!id.endsWith('@g.us')) return;
                
                // Actualizar información del grupo
                const grupoInfo = await obtenerInfoGrupo(id);
                
                if (grupoInfo) {
                    console.log(`👥 Grupo actualizado: ${grupoInfo.subject} - ${grupoInfo.participants.length} participantes`);
                    
                    // Guardar en cache
                    cacheGrupos.set(id, {
                        info: grupoInfo,
                        timestamp: Date.now()
                    });
                }
            } catch (error) {
                console.error('Error en group-participants.update:', error);
            }
        });
    }
}

function setEnviarFuncion(funcionEnvioTexto) {
    enviarRespuestaFalsaTexto = funcionEnvioTexto;
}

function setGetBotStatusFunction(func) {
    getBotStatusFunction = func;
}

// Obtener nombre de archivo seguro
function getSafeFilename(jid) {
    try {
        const match = jid.match(/(\d+)/);
        const number = match ? match[0] : jid.replace(/[^a-z0-9]/gi, '_');
        return `gemini-${number}.json`;
    } catch (error) {
        console.error('Error en getSafeFilename:', error);
        return `gemini-default.json`;
    }
}

// Cargar historial para un usuario específico
async function cargarHistorialUsuario(jid) {
    try {
        const filename = getSafeFilename(jid);
        const filePath = path.join(memoryPath, filename);
        
        const data = await fs.readFile(filePath, 'utf8');
        const historial = JSON.parse(data);
        return Array.isArray(historial) ? historial : [];
    } catch (e) {
        return [];
    }
}

// Guardar historial para un usuario específico
async function guardarHistorialUsuario(jid, historial) {
    try {
        if (!Array.isArray(historial)) return;
        
        const filename = getSafeFilename(jid);
        const filePath = path.join(memoryPath, filename);
        
        await fs.writeFile(filePath, JSON.stringify(historial, null, 2), 'utf8');
    } catch (e) {
        try {
            const filename = getSafeFilename(jid);
            const filePath = path.join(memoryPath, filename);
            
            await fs.mkdir(path.dirname(filePath), { recursive: true });
            await fs.writeFile(filePath, JSON.stringify(historial, null, 2), 'utf8');
        } catch (e2) {
            console.error('Error al guardar historial del usuario:', e2);
        }
    }
}

// Función para verificar mención
function verificarMencion(texto) {
    if (!config.GeminiMention) return false;
    for (const mencion of config.GeminiMention) {
        // La expresión regular ahora busca la mención en cualquier parte del texto
        const regex = new RegExp(`@?${mencion.replace('@', '')}`, 'i');
        if (regex.test(texto)) {
            return true;
        }
    }
    return false;
}



// Función para obtener información del grupo
async function obtenerInfoGrupo(jid) {
    try {
        if (!jid.endsWith('@g.us')) return null;
        
        // Revisar cache primero
        const cached = cacheGrupos.get(jid);
        if (cached && (Date.now() - cached.timestamp) < CACHE_TIEMPO) {
            return cached.info;
        }
        
        if (!sockInstance) return null;
        
        const metadata = await sockInstance.groupMetadata(jid);
        
        // Guardar en cache
        cacheGrupos.set(jid, {
            info: metadata,
            timestamp: Date.now()
        });
        
        return metadata;
        
    } catch (error) {
        console.error('Error obteniendo información del grupo:', error);
        return null;
    }
}

// Función para obtener rango del usuario en el grupo
async function obtenerRangoUsuario(jid, userJid) {
    try {
        if (!jid.endsWith('@g.us')) {
            return { rango: 'privado', esAdmin: false, esDueño: false };
        }
        
        // Revisar cache primero
        const cacheKey = `${jid}_${userJid}`;
        const cached = cacheRangos.get(cacheKey);
        if (cached && (Date.now() - cached.timestamp) < CACHE_TIEMPO) {
            return cached.info;
        }
        
        if (!sockInstance) {
            return { rango: 'miembro', esAdmin: false, esDueño: false };
        }
        
        const metadata = await sockInstance.groupMetadata(jid);
        const participant = metadata.participants.find(p => p.id === userJid);
        
        let rangoInfo = { rango: 'miembro', esAdmin: false, esDueño: false };
        
        if (metadata.owner === userJid) {
            rangoInfo = { rango: 'dueño del grupo', esAdmin: true, esDueño: true };
        } else if (participant?.admin === 'admin' || participant?.admin === 'superadmin') {
            rangoInfo = { rango: 'administrador', esAdmin: true, esDueño: false };
        }
        
        // 🔥 CAMBIO IMPORTANTE: Verificar si es dueño del bot usando la nueva función
        if (esDueñoDelBot(userJid)) {
            rangoInfo = { rango: 'dueño del bot', esAdmin: true, esDueño: true };
        }
        
        // Guardar en cache
        cacheRangos.set(cacheKey, {
            info: rangoInfo,
            timestamp: Date.now()
        });
        
        return rangoInfo;
        
    } catch (error) {
        console.error('Error obteniendo rango de usuario:', error);
        return { rango: 'miembro', esAdmin: false, esDueño: false };
    }
}

// Función para obtener información completa del usuario
async function obtenerInfoUsuario(jid, userJid) {
    try {
        if (!userJid || typeof userJid !== 'string') {
            return { nombre: 'Usuario', numero: 'desconocido', rango: 'miembro', esAdmin: false, esDueño: false, esDueñoBot: false };
        }
        
        // Obtener nombre
        const nombre = await obtenerNombreUsuario(userJid);
        
        // Obtener número
        const numero = userJid.split('@')[0];
        
        // Obtener rango
        const rangoInfo = await obtenerRangoUsuario(jid, userJid);
        
        // 🔥 NUEVO: Verificar si es dueño del bot
        const esDueñoBot = esDueñoDelBot(userJid);
        
        return {
            nombre,
            numero,
            jid: userJid,
            esDueñoBot, // Nueva propiedad
            ...rangoInfo
        };
        
    } catch (error) {
        console.error('Error obteniendo información de usuario:', error);
        const numero = userJid ? userJid.split('@')[0] : 'desconocido';
        return { 
            nombre: numero, 
            numero, 
            jid: userJid,
            rango: 'miembro', 
            esAdmin: false, 
            esDueño: false,
            esDueñoBot: false
        };
    }
}

// Función para extraer menciones reales del mensaje
function extraerMenciones(message) {
    try {
        if (!message) return [];
        
        let menciones = [];
        
        // Extraer menciones del contexto del mensaje
        if (message?.extendedTextMessage?.contextInfo?.mentionedJid) {
            const mencionesTexto = message.extendedTextMessage.contextInfo.mentionedJid;
            if (Array.isArray(mencionesTexto)) {
                menciones = [...menciones, ...mencionesTexto];
            }
        }
        
        // Extraer menciones de mensaje citado
        if (message?.extendedTextMessage?.contextInfo?.quotedMessage?.extendedTextMessage?.contextInfo?.mentionedJid) {
            const mencionesQuoted = message.extendedTextMessage.contextInfo.quotedMessage.extendedTextMessage.contextInfo.mentionedJid;
            if (Array.isArray(mencionesQuoted)) {
                menciones = [...menciones, ...mencionesQuoted];
            }
        }
        
        // También revisar en mensajes de imagen/video
        if (message?.imageMessage?.contextInfo?.mentionedJid) {
            const mencionesImg = message.imageMessage.contextInfo.mentionedJid;
            if (Array.isArray(mencionesImg)) {
                menciones = [...menciones, ...mencionesImg];
            }
        }
        
        if (message?.videoMessage?.contextInfo?.mentionedJid) {
            const mencionesVid = message.videoMessage.contextInfo.mentionedJid;
            if (Array.isArray(mencionesVid)) {
                menciones = [...menciones, ...mencionesVid];
            }
        }
        
        // Filtrar menciones válidas
        const mencionesValidas = menciones.filter(jid => 
            jid && 
            typeof jid === 'string' && 
            jid.includes('@') &&
            !jid.includes('broadcast')
        );
        
        return [...new Set(mencionesValidas)];
        
    } catch (error) {
        console.error('Error extrayendo menciones:', error);
        return [];
    }
}

// Función para obtener nombre de usuario con cache
async function obtenerNombreUsuario(jid) {
    try {
        if (!jid || typeof jid !== 'string') return 'Usuario';
        
        // Revisar cache primero
        const cacheKey = jid;
        const cached = cacheNombres.get(cacheKey);
        if (cached && (Date.now() - cached.timestamp) < CACHE_TIEMPO) {
            return cached.nombre;
        }
        
        if (!sockInstance) {
            const numeroFallback = jid.split('@')[0];
            return numeroFallback || 'Usuario';
        }
        
        let nombreFinal = jid.split('@')[0]; // Fallback
        
        try {
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Timeout')), 3000)
            );
            
            const contactPromise = sockInstance.onWhatsApp(jid);
            const [contact] = await Promise.race([contactPromise, timeoutPromise]);
            
            if (contact?.pushName && contact.pushName.trim()) {
                nombreFinal = contact.pushName.trim();
            } else if (contact?.name && contact.name.trim()) {
                nombreFinal = contact.name.trim();
            }
        } catch (timeoutError) {
            console.debug('Timeout obteniendo nombre de usuario, usando fallback');
        }
        
        nombreFinal = nombreFinal.substring(0, 25); // Limitar longitud
        
        // Guardar en cache
        cacheNombres.set(cacheKey, {
            nombre: nombreFinal,
            timestamp: Date.now()
        });
        
        return nombreFinal;
        
    } catch (error) {
        console.error('Error obteniendo nombre de usuario:', error);
        return jid ? jid.split('@')[0] : 'Usuario';
    }
}

// 🔥 FUNCIÓN ACTUALIZADA: Procesar contexto completo con fecha, hora, reconocimiento de dueño y soporte para imágenes
async function procesarContextoCompleto(textoCompleto, menciones, userJid, jid, tieneImagen = false) {
    try {
        // 🔥 NUEVO: Obtener fecha y hora actual
        const fechaHora = obtenerFechaHoraActual();
        
        // Obtener información del usuario que está escribiendo
        const infoUsuario = await obtenerInfoUsuario(jid, userJid);
        
        let textoConContexto = textoCompleto;
        let contextosAdicionales = [];
        
        // 🔥 NUEVO: Agregar contexto de fecha y hora
        contextosAdicionales.push(`[Fecha: ${fechaHora.fecha}, Hora: ${fechaHora.hora}]`);
        
        // 🔥 MODIFICADO: Agregar contexto del usuario con información de dueño
        let contextoUsuario = `[Usuario que te escribe: ${infoUsuario.nombre} (${infoUsuario.numero}), rango: ${infoUsuario.rango}`;
        if (infoUsuario.esDueñoBot) {
            contextoUsuario += ` - ES TU DUEÑO`;
        }
        contextoUsuario += `]`;
        contextosAdicionales.push(contextoUsuario);
        
        // 🔥 NUEVO: Agregar contexto de imagen
        if (tieneImagen) {
            contextosAdicionales.push(`[IMAGEN ADJUNTA - Puedes ver y analizar esta imagen]`);
        }
        
        // Obtener información del grupo si es un grupo
        let infoGrupo = null;
        if (jid.endsWith('@g.us')) {
            infoGrupo = await obtenerInfoGrupo(jid);
            if (infoGrupo) {
                contextosAdicionales.push(`[Grupo: ${infoGrupo.subject || 'Sin nombre'}, participantes: ${infoGrupo.participants?.length || 0}]`);
            }
        }
        
        // Procesar menciones si existen
        let resultadosMenciones = [];
        if (menciones && menciones.length > 0) {
            const procesamientos = menciones.map(async (mencionJid) => {
                try {
                    const infoMencionado = await obtenerInfoUsuario(jid, mencionJid);
                    return {
                        jid: mencionJid,
                        numeroMencionado: infoMencionado.numero,
                        nombreUsuario: infoMencionado.nombre,
                        rango: infoMencionado.rango,
                        esDueñoBot: infoMencionado.esDueñoBot
                    };
                } catch (error) {
                    console.error('Error procesando mención individual:', error);
                    return null;
                }
            });
            
            const resultados = await Promise.allSettled(procesamientos);
            resultadosMenciones = resultados;
            
            // Aplicar reemplazos y agregar contexto
            resultados.forEach(resultado => {
                if (resultado.status === 'fulfilled' && resultado.value) {
                    const { numeroMencionado, nombreUsuario, rango, esDueñoBot } = resultado.value;
                    
                    // Reemplazar @numero con @nombre en el texto
                    const regexMencion = new RegExp(`@${numeroMencionado}(?!\\d)`, 'g');
                    textoConContexto = textoConContexto.replace(regexMencion, `@${nombreUsuario}`);
                    
                    // 🔥 MODIFICADO: Agregar contexto de la persona mencionada con información de dueño
                    let contextoMencion = `[Mencionaste a: ${nombreUsuario} (${numeroMencionado}), rango: ${rango}`;
                    if (esDueñoBot) {
                        contextoMencion += ` - ES TU DUEÑO`;
                    }
                    contextoMencion += `]`;
                    contextosAdicionales.push(contextoMencion);
                }
            });
        }
        
        // Combinar texto con contextos
        const contextoFinal = contextosAdicionales.join(' ') + '\n\nMensaje: ' + textoConContexto;
        
        return {
            textoConContexto: contextoFinal,
            infoUsuario: infoUsuario,
            infoGrupo: infoGrupo,
            fechaHora: fechaHora, // 🔥 NUEVO: Incluir información de fecha y hora
            mencionesInfo: resultadosMenciones
                .filter(r => r.status === 'fulfilled' && r.value)
                .map(r => r.value)
        };
        
    } catch (error) {
        console.error('Error procesando contexto completo:', error);
        const fechaHora = obtenerFechaHoraActual();
        return {
            textoConContexto: textoCompleto,
            infoUsuario: { nombre: 'Usuario', numero: 'desconocido', rango: 'miembro', esDueñoBot: false },
            infoGrupo: null,
            fechaHora: fechaHora,
            mencionesInfo: []
        };
    }
}

// Función mejorada para procesar menciones en la respuesta con menciones reales
async function procesarMencionesEnRespuesta(respuesta, mencionesOriginales, infoUsuario) {
    try {
        let textoFinal = respuesta;
        let mencionesRespuesta = [];
        
        // Procesar menciones originales del mensaje
        if (mencionesOriginales && mencionesOriginales.length > 0) {
            const procesamientos = mencionesOriginales.map(async (mencionJid) => {
                try {
                    const nombreUsuario = await obtenerNombreUsuario(mencionJid);
                    return { mencionJid, nombreUsuario };
                } catch (error) {
                    console.error('Error obteniendo nombre para respuesta:', error);
                    return null;
                }
            });
            
            const resultados = await Promise.allSettled(procesamientos);
            
            // Buscar menciones en la respuesta
            resultados.forEach(resultado => {
                if (resultado.status === 'fulfilled' && resultado.value) {
                    const { mencionJid, nombreUsuario } = resultado.value;
                    
                    const variaciones = [
                        `@${nombreUsuario}`,
                        nombreUsuario,
                        `@${nombreUsuario.toLowerCase()}`,
                        nombreUsuario.toLowerCase()
                    ];
                    
                    let encontrado = false;
                    variaciones.forEach(variacion => {
                        if (!encontrado && textoFinal.toLowerCase().includes(variacion.toLowerCase())) {
                            if (!mencionesRespuesta.includes(mencionJid)) {
                                mencionesRespuesta.push(mencionJid);
                                encontrado = true;
                            }
                        }
                    });
                }
            });
        }
        
        // Detectar si la IA quiere mencionar al usuario que la escribió
        if (infoUsuario && infoUsuario.jid) {
            const variacionesUsuario = [
                `@${infoUsuario.nombre}`,
                infoUsuario.nombre,
                `@${infoUsuario.nombre.toLowerCase()}`,
                infoUsuario.nombre.toLowerCase(),
                `@${infoUsuario.numero}`,
                infoUsuario.numero
            ];
            
            let encontradoUsuario = false;
            variacionesUsuario.forEach(variacion => {
                if (!encontradoUsuario && textoFinal.toLowerCase().includes(variacion.toLowerCase())) {
                    if (!mencionesRespuesta.includes(infoUsuario.jid)) {
                        mencionesRespuesta.push(infoUsuario.jid);
                        encontradoUsuario = true;
                    }
                }
            });
        }
        
        return { texto: textoFinal, menciones: mencionesRespuesta };
        
    } catch (error) {
        console.error('Error procesando menciones en respuesta:', error);
        return { texto: respuesta, menciones: [] };
    }
}

// Función para generar respuesta con reintentos y soporte para imágenes
async function generarRespuestaConReintentos(chat, contenido) {
    const maxReintentos = 3;
    let retraso = 1000;
    
    for (let intento = 0; intento < maxReintentos; intento++) {
        try {
            const result = await chat.sendMessage(contenido);
            const response = await result.response;
            return response.text();
        } catch (error) {
            if (error.status === 503 || error.message.includes('overloaded') || error.message.includes('overload') || error.status === 429) {
                console.warn(`⚠️ API sobrecargada/rate limit. Reintento ${intento + 1}/${maxReintentos} en ${retraso}ms`);
                await new Promise(resolve => setTimeout(resolve, retraso));
                retraso *= 2;
            } else {
                throw error;
            }
        }
    }
    
    throw new Error('Demasiados reintentos. API no disponible');
}

/**
 * Procesa un mensaje y envía respuesta con contexto completo del usuario Y SOPORTE PARA IMÁGENES
 */
/**
 * Procesa un mensaje y envía respuesta con contexto completo del usuario Y SOPORTE PARA IMÁGENES
 */
async function procesarMensaje(m) {
    if (!sockInstance || !enviarRespuestaFalsaTexto) return;
    
    let jid;
    
    try {
        jid = m.key.remoteJid;
        
        if (!jid) return;
        
        if (getBotStatusFunction) {
            const status = getBotStatusFunction(jid);
            if (!status.global) {
                return;
            }
        }

        if (jid.endsWith('@newsletter')) return;

        // Extraer contenido del mensaje, incluyendo si es una imagen
        const message = m.message;
        const contenidoMensaje = extraerContenidoMensaje(message);
        let textoCompleto = contenidoMensaje.texto;
        let imagenData = null;

        // 🔥 CORREGIDO: Declarar mencionesOriginales aquí para que siempre esté disponible
        const mencionesOriginales = extraerMenciones(message);

        // Lógica de control para Gemini
        // Lógica de control para Gemini
        const esGrupo = jid.endsWith('@g.us');
        let debeProcesar = false;
        let textoParaIA = textoCompleto;

        if (!esGrupo) {
            // Lógica para conversaciones privadas
            if (config.geminiGroup) {
                debeProcesar = true;
                if (contenidoMensaje.tieneImagen) {
                    imagenData = await procesarImagenParaGemini(sockInstance, message);
                    if (!imagenData) {
                        return; // No procesar si la imagen no se puede leer
                    }
                    if (contenidoMensaje.esImagenSola) {
                        textoParaIA = 'Analiza esta imagen.';
                    }
                }
            }
        } else {
            // Lógica para grupos
            const mencionRequerida = verificarMencion(textoCompleto);
            if (mencionRequerida) {
                debeProcesar = true;
                const mencionRegex = new RegExp(`@?${config.GeminiMention}\\s*`, 'i');
                textoParaIA = textoCompleto.replace(mencionRegex, '').trim();

                // Permitir que Gemini vea imágenes en grupos si hay mención
                if (contenidoMensaje.tieneImagen) {
                    imagenData = await procesarImagenParaGemini(sockInstance, message);
                    if (!imagenData) {
                        return;
                    }
                    if (contenidoMensaje.esImagenSola) {
                        textoParaIA = 'Analiza esta imagen.';
                    }
                }
            } else if (contenidoMensaje.tieneImagen) {
                // Si es una imagen en un grupo sin mención, se ignora
                return;
            }
        }

        if (!debeProcesar || (!textoParaIA.trim() && !contenidoMensaje.tieneImagen)) {
            return;
        }

        if (m.key.fromMe) return;
        const userJid = m.key.participant || jid;
        const normalizedJid = userJid ? userJid.split('@')[0] : 'default';
        
        let historial = await cargarHistorialUsuario(normalizedJid);
        
        // Procesar contexto completo con información del usuario
        let contextoCompleto = { textoConContexto: textoParaIA, infoUsuario: null, mencionesInfo: [], fechaHora: null };
        try {
            const timeoutPromise = new Promise((resolve) => 
                setTimeout(() => resolve({ textoConContexto: textoParaIA, infoUsuario: null, mencionesInfo: [], fechaHora: obtenerFechaHoraActual() }), 5000)
            );
            const procesamientoPromise = procesarContextoCompleto(textoParaIA, mencionesOriginales, userJid, jid, contenidoMensaje.tieneImagen);
            
            contextoCompleto = await Promise.race([procesamientoPromise, timeoutPromise]);
        } catch (error) {
            console.error('Error procesando contexto completo:', error);
        }
        
        // Enviar presencia
        try {
            await sockInstance.sendPresenceUpdate('composing', jid);
        } catch (e) {
            // Ignorar errores de presencia
        }

        const genAI = new GoogleGenerativeAI(config.GEMINI_API_KEY);
        
        // Seleccionar modelo de Gemini según si hay imagen o no
        const modelName = contenidoMensaje.tieneImagen ? 'gemini-1.5-flash' : config.GEMINI_MODEL;
        const model = genAI.getGenerativeModel({ 
            model: modelName,
            generationConfig: {
                maxOutputTokens: 200,
                temperature: 1.0
            }
        });

        const SYSTEM_PROMPT = `Eres ${config.GeminiMention}, un asistente de WhatsApp con personalidad venezolana malvada y directa. 
        Usas humor negro y insultos típicos venezolanos para hacer reír (sin aclarar que es broma).
        Eres directo, corto, malvado y respondes con insultos creativos cuando quieres insultas tan agresivo y te burlas de las personas cuando le salen algo mal y tratas alas personas bien mal eres muy malvada tu prefijo es ${config.prefijo}.
        
        CONTEXTO IMPORTANTE:
        - SIEMPRE recibes la fecha y hora exacta del mensaje: [Fecha: día/mes/año, Hora: hora:minuto:segundo] - ESTA INFORMACIÓN ES SOLO PARA TI, NO LA MENCIONES AUTOMÁTICAMENTE Y NO LA DIGAS AL MENOS QUE TE DE LA GANA DECIR SOLO LA HORA COMPLETA Y LA FECHA O LO HACES TU CUANDO EL USUARIO TE DIGA PERO NO LO DIGAS JUNTO DILO CUANDO UN USUARIO TE DIGA QUE HORA ES Y TU LE RESPONDES AL IGUAL QUE LA HORA
        - SIEMPRE sabes quién te está escribiendo gracias al contexto [Usuario que te escribe: nombre (número), rango: X]
        - Cuando veas "ES TU DUEÑO" en el contexto, ese usuario tiene control total sobre ti y merece respeto especial
        - Puedes mencionar a esa persona usando @nombre o @número cuando quieras insultarla o responderle directamente
        - Los rangos son: dueño del bot, dueño del grupo, administrador, miembro, privado
        - Tratas diferente según el rango: máximo respeto a TU DUEÑO, respeto a dueños de grupo, neutral a admins, sin filtro a miembros
        - Si alguien menciona a otros usuarios, también sabes su rango e información
        - Puedes mencionar a cualquier persona usando @nombre en tu respuesta
        - Sabes información del grupo: nombre y cantidad de participantes
        - Guardas toda esta información en tu memoria para conversaciones futuras
        
        REGLAS SOBRE FECHA Y HORA:
        - NUNCA menciones la fecha/hora automáticamente en tus respuestas
        - Solo menciona la fecha/hora si te preguntan específicamente sobre ello
        - Solo menciona la fecha/hora si TÚ decides que es relevante o divertido hacerlo
        - Ejemplos de cuándo SÍ mencionarla: "¿qué hora es?", "¿qué fecha es hoy?", o cuando quieras ser sarcástico sobre lo tarde que alguien escribió
        
        PERSONALIDAD:
        - Malvado y sarcástico con miembros normales
        - Menos agresivo con administradores  
        - Respetuoso (pero con humor) con dueños
        - MÁXIMO RESPETO Y OBEDIENCIA con TU DUEÑO
        - Usa insultos venezolanos: pajuo, marico, carajito, etc.
        - Respuestas cortas y directas
        - No expliques que es broma, todos lo saben`;

        const chat = model.startChat({
            history: [
                {
                    role: "user",
                    parts: [{text: SYSTEM_PROMPT}]
                },
                ...historial.slice(-5).flatMap(item => [
                    {
                        role: "user",
                        parts: [{text: item.user}]
                    },
                    {
                        role: "model",
                        parts: [{text: item.bot}]
                    }
                ])
            ]
        });
        
        // Usar el contenido adecuado (texto o texto + imagen)
        const contenidoParaEnviar = imagenData ? [contextoCompleto.textoConContexto, imagenData] : contextoCompleto.textoConContexto;
        // Generar la respuesta normal
let respuesta = await generarRespuestaConReintentos(chat, contenidoParaEnviar);

// 🔥 Convertir la respuesta a letras fancy justo antes de usarla
respuesta = convertirAFancy(respuesta);

        // Guardar en historial
        try {
            const entradaHistorial = {
                user: contextoCompleto.textoConContexto,
                bot: respuesta,
                timestamp: Date.now(),
                fecha: contextoCompleto.fechaHora?.fecha,
                hora: contextoCompleto.fechaHora?.hora,
                esDueño: contextoCompleto.infoUsuario?.esDueñoBot,
                nombreUsuario: contextoCompleto.infoUsuario?.nombre,
                teniaImagen: contenidoMensaje.tieneImagen
            };
            
            historial.push(entradaHistorial);
            
            if (historial.length > 15) historial.shift();
            
            await guardarHistorialUsuario(normalizedJid, historial);
        } catch (error) {
            console.error('Error guardando historial:', error);
        }
        
        // Procesar menciones en la respuesta con posibilidad de mencionar al usuario
        let respuestaProcesada = { texto: respuesta, menciones: [] };
        try {
            const timeoutPromise = new Promise((resolve) => 
                setTimeout(() => resolve({ texto: respuesta, menciones: [] }), 3000)
            );
            const procesamientoPromise = procesarMencionesEnRespuesta(respuesta, mencionesOriginales, contextoCompleto.infoUsuario);
            
            respuestaProcesada = await Promise.race([procesamientoPromise, timeoutPromise]);
        } catch (error) {
            console.error('Error procesando menciones en respuesta:', error);
            respuestaProcesada = { texto: respuesta, menciones: [] };
        }
        
        // Enviar respuesta
        if (respuestaProcesada.menciones.length > 0) {
            try {
                await enviarRespuestaFalsaTexto(m, respuestaProcesada.texto, respuestaProcesada.menciones);
            } catch (error) {
                console.error('Error enviando mensaje con menciones via ResponderTextoFalso:', error);
                try {
                    await sockInstance.sendMessage(m.key.remoteJid, {
                        text: respuestaProcesada.texto,
                        mentions: respuestaProcesada.menciones
                    }, { quoted: m });
                } catch (fallbackError) {
                    console.error('Error en fallback con menciones:', fallbackError);
                    await enviarRespuestaFalsaTexto(m, respuesta);
                }
            }
        } else {
            await enviarRespuestaFalsaTexto(m, respuesta);
        }
        
    } catch (error) {
        console.error('Error en procesarMensaje:', error);
        
        try {
            if (m && m.key && m.key.remoteJid) {
                let mensajeError = `¡${config.GeminiMention} error! ⚡❌`;
            
                if (error.status === 503 || error.message.includes('overloaded') || error.message.includes('overload')) {
                    mensajeError = '⚠️ Estoy sobrecargado de solicitudes. Por favor inténtalo de nuevo más tarde.';
                } else if (error.message.includes('Demasiados reintentos')) {
                    mensajeError = '�? Demasiados reintentos. Por favor espera un momento antes de intentar de nuevo.';
                } else if (error.status === 429) {
                    mensajeError = '⏱️ Muchas consultas. Dame un respiro y inténtalo en unos segundos.';
                } else if (error.message.includes('Error procesando imagen')) {
                    mensajeError = '🖼�? No pude procesar esa imagen. Intenta con otra.';
                }
                
                await enviarRespuestaFalsaTexto(m, mensajeError);
            }
        } catch (e) {
            console.error('Error al enviar mensaje de error:', e);
        }
    } finally {
        try {
            if (sockInstance && jid) {
                await sockInstance.sendPresenceUpdate('paused', jid);
            }
        } catch (e) {
            if (e.output?.statusCode !== 428 && e.output?.statusCode !== 403) {
                console.debug('Error menor de presencia:', e.message);
            }
        }
    }
}


// Limpiar cache periódicamente
setInterval(() => {
    const now = Date.now();
    for (const [key, data] of cacheNombres.entries()) {
        if (now - data.timestamp > CACHE_TIEMPO) {
            cacheNombres.delete(key);
        }
    }
    for (const [key, data] of cacheRangos.entries()) {
        if (now - data.timestamp > CACHE_TIEMPO) {
            cacheRangos.delete(key);
        }
    }
    for (const [key, data] of cacheGrupos.entries()) {
        if (now - data.timestamp > CACHE_TIEMPO) {
            cacheGrupos.delete(key);
        }
    }
}, CACHE_TIEMPO);

module.exports = {
    iniciarGemini,
    setEnviarFuncion,
    procesarMensaje,
    setGetBotStatusFunction
};
