const fs = require('fs');
const path = require('path');
const readline = require('readline/promises');
const process = require('node:process');
const pino = require('pino');
const qrcode = require('qrcode-terminal');

// 🚨 CONFIGURACIÓN DEL LOGGER PARA MÁXIMA SUPRESIÓN DE LOGS INTERNOS (Pino Filter)
const logDestination = pino.destination({ sync: false });
const filteredLogger = pino(
    { level: process.env.BAILEYS_LOG_LEVEL || 'info' },
    logDestination
);

// Sobrescribir la función 'write' para filtrar los mensajes no deseados
logDestination.write = (logEntry) => {
    if (
        // --- GRUPO 1: ERRORES DE CIFRADO (Bad MAC, Failed to decrypt, etc.) ---
        logEntry.includes('Bad MAC') || 
        logEntry.includes('Failed to decrypt message') || 
        logEntry.includes('Session error') || 
        logEntry.includes('Over 2000 messages into the future') ||
        logEntry.includes('failed to decrypt message') || 
        logEntry.includes('Failed to decrypt message with any known session') ||
        
        // Filtros expandidos para la pila de llamadas (stack trace) del Bad MAC
        logEntry.includes('at Object.verifyMAC') || 
        logEntry.includes('at SessionCipher.doDecryptWhisperMessage') ||
        logEntry.includes('at async SessionCipher.decryptWithSessions') ||

        // --- GRUPO 2: ERRORES y MENSAJES de SINCRONIZACIÓN y CHAT STATE (NUEVO) ---
        logEntry.includes('resyncing critical_unblock_low') ||
        logEntry.includes('tried remove, but no previous op') ||
        logEntry.includes('failed to sync state from version') ||
        logEntry.includes('archive setting updated') ||
        logEntry.includes('Closing open session in favor of incoming prekey bundle') ||
        logEntry.includes('Closing session: SessionEntry') || // Filtra el volcado de objetos de sesión
        logEntry.includes('resyncing critical_block') ||
        logEntry.includes('synced critical_block') ||
        logEntry.includes('resyncing regular') ||
        logEntry.includes('synced regular') ||

        // --- GRUPO 3: MENSAJES VARIOS DE CONEXIÓN E INTERCAMBIO DE CLAVES ---
        logEntry.includes('Error: No image processing library available') || // Error de imagen (desactivado, pero filtrado)
        logEntry.includes('"msg":"failed to obtain extra info"') ||
        logEntry.includes('injecting new app state sync keys') ||
        logEntry.includes('got history notification') ||
        logEntry.includes('uploading pre-keys') ||
        logEntry.includes('uploaded pre-keys') ||
        logEntry.includes('pre-keys found on server') ||
        logEntry.includes('offline preview received') ||
        logEntry.includes('clean dirty bits') ||
        logEntry.includes('sent retry receipt') || 

        // --- GRUPO 4: MENSAJES BÁSICOS DE ESTADO DE CONEXIÓN (INFORMATIVOS) ---
        logEntry.includes('"msg":"connected to WA"') ||
        logEntry.includes('"msg":"logging in..."') ||
        logEntry.includes('handled') && logEntry.includes('offline messages/notifications') ||
        logEntry.includes('Connection is now') ||
        logEntry.includes('History sync is disabled by config') ||
        logEntry.includes('"msg":"opened connection to WA"') ||
        logEntry.includes('awaiting initial')
    ) {
        return; // Descartar el log
    }
    process.stdout.write(logEntry); 
};
// ----------------------------------------------------------------------------------------------------

const Baileys = require('@whiskeysockets/baileys');
const {
  makeWASocket,
  DisconnectReason,
  Browsers,
  makeCacheableSignalKeyStore,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  isJidBroadcast,
  isJidStatusBroadcast,
  isJidNewsletter
} = Baileys;

const makeInMemoryStoreLib = Baileys.makeInMemoryStore || (Baileys.default && Baileys.default.makeInMemoryStore) || null;

function createFallbackStore() {
  const store = {
    chats: new Map(),
    contacts: new Map(),
    messages: new Map(),
    getMessage: (key) => {
      if (!key) return null;
      const id = key.id || (key.key && key.key.id);
      return id ? store.messages.get(id) || null : null;
    },
    bind: (ev) => {
      ev.on('chats.set', ({ chats = [] }) => {
        chats.forEach(c => {
          const id = c.id || (c.id?.toString()) || JSON.stringify(c);
          store.chats.set(id, c);
        });
      });

      ev.on('contacts.set', ({ contacts = [] }) => {
        contacts.forEach(contact => {
          if (contact.id) store.contacts.set(contact.id, contact);
        });
      });

      ev.on('messages.upsert', (m) => {
        const messages = m?.messages || (Array.isArray(m) ? m : []);
        messages.forEach(msg => {
          const id = msg.key?.id || (msg.key && JSON.stringify(msg.key)) || Date.now().toString();
          store.messages.set(id, msg);
        });
      });

      ev.on('creds.update', (creds) => {
        store.creds = creds;
      });
    }
  };

  return store;
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
let socket;

function sanitizeFilename(s) {
  return String(s).replace(/[\/\\?%*:|"<> ]+/g, '_');
}

async function conectar(onOpenCallback) {
  const authPath = path.resolve('sections/main_section/auth');
  if (!fs.existsSync(authPath)) fs.mkdirSync(authPath, { recursive: true });

  const pairingConfigPath = path.join(authPath, 'pairing.json');

  const { state, saveCreds } = await useMultiFileAuthState(authPath);
  const { version } = await fetchLatestBaileysVersion();
  
  const logger = filteredLogger;

  let pairingMode = null;

  if (!state.creds.registered) {
    try {
      if (fs.existsSync(pairingConfigPath)) {
        const raw = fs.readFileSync(pairingConfigPath, 'utf8');
        const cfg = JSON.parse(raw || '{}');
        if (cfg && (cfg.mode === '1' || cfg.mode === '2')) {
          pairingMode = cfg.mode;
        }
      }
    } catch (e) {
      console.warn('No se pudo leer pairing.json, se preguntará por método de emparejamiento.', e);
    }

    if (!pairingMode) {
      console.log('\nSelecciona método de emparejamiento (esto se guardará para evitar que vuelva a preguntarte):');
      console.log('  1) Código numérico (8 dígitos)');
      console.log('  2) QR en terminal\n');

      let choice = null;
      while (!choice) {
        try {
          choice = (await rl.question('Ingresa 1 o 2: ')).trim();
        } catch (err) {
          console.warn('Lectura interrumpida. Se usará modo QR por defecto.');
          choice = '2';
        }
        if (choice !== '1' && choice !== '2') {
          console.log('Opción inválida. Ingresa 1 o 2.');
          choice = null;
        } else {
          pairingMode = choice;
          try {
            fs.writeFileSync(pairingConfigPath, JSON.stringify({ mode: pairingMode }, null, 2), 'utf8');
          } catch (e) {
            console.warn('No se pudo guardar pairing.json, la elección se usará solo en esta sesión.', e);
          }
        }
      }
      console.log(`Has elegido: ${pairingMode === '1' ? 'Código' : 'QR'}.\n`);
    }
  }

  const store = makeInMemoryStoreLib ? makeInMemoryStoreLib({ logger }) : createFallbackStore();

  socket = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys)
    },
    browser: Browsers.windows('Opera'),
    keepAliveIntervalMs: 30000,
    markOnlineOnConnect: true,
    syncFullHistory: false,
    shouldIgnoreJid: jid => isJidBroadcast(jid) || isJidStatusBroadcast(jid) || isJidNewsletter(jid),
    logger, 
    maxPrekeys: 300,
    // CLAVE: Deshabilita la generación de miniaturas
    generateHighQualityLinkPreview: false 
  });

  if (store && typeof store.bind === 'function') store.bind(socket.ev);

  socket.ev.on('connection.update', update => {
    const { connection, lastDisconnect, qr } = update;

    if (pairingMode === '2' && qr) {
      console.log('\n\x1b[33m[QR] Escanea este código con tu teléfono:\x1b[0m');
      qrcode.generate(qr, { small: true });
    }

    if (connection === 'open') {
      // Nota: El mensaje "✅ BOT CONECTADO CORRECTAMENTE" debe estar *fuera* de la función de filtro, 
      // así que no lo incluimos en las reglas de filtrado de arriba para que se muestre.
      console.log('\x1b[42m\x1b[30m ✅ BOT CONECTADO CORRECTAMENTE \x1b[0m');
      if (onOpenCallback) onOpenCallback(socket);
    }

    if (connection === 'close') {
      console.log('\x1b[41m\x1b[37m ❌ BOT DESCONECTADO \x1b[0m');
      const error = lastDisconnect?.error;
      const statusCode = error?.output?.statusCode ?? error?.statusCode;

      switch (statusCode) {
        case DisconnectReason.loggedOut:
          console.error('\x1b[41m\x1b[37m 🔒 Sesión cerrada (logged out). Debes re-emparejar. \x1b[0m');
          console.warn('\x1b[33m⚠️ OJO: Ya NO se borra la carpeta auth automáticamente.\x1b[0m');
          process.exit(1);
        case DisconnectReason.badSession:
          console.error('\x1b[41m\x1b[37m ⚠️ Sesión corrupta. Debes borrar manualmente auth/. \x1b[0m');
          process.exit(1);
        default:
          console.log('\x1b[44m\x1b[37m 🔁 Intentando reconectar en 5s... \x1b[0m');
          setTimeout(() => conectar(onOpenCallback), 5000);
      }
    }
  });

  socket.ev.on('creds.update', saveCreds);

  if (!state.creds.registered) {
    if (pairingMode === '1') {
      try {
        const numero = await rl.question('📱 Ingresa tu número (ej. 5899999999): ');
        const limpio = numero.replace(/\D/g, '');
        console.log('Solicitando código...');
        const codigo = await socket.requestPairingCode(limpio);
        console.log(`➡️ Código recibido: ${codigo}`);
      } catch (err) {
        console.error('Error durante pairing con código:', err);
      }
    } else {
      console.log('📡 Escanea el QR en la terminal para vincular.');
    }
  }

  return socket;
}

module.exports = { conectar };
