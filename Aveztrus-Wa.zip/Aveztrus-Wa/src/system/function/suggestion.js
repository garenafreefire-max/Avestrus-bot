// Archivo: ./system/function/suggestion.js

const stringSimilarity = require('string-similarity');

/**
 * Procesa un comando no encontrado y sugiere alternativas si es posible.
 * @param {object} ctx - El objeto de contexto del comando (m, responderTexto, comandosMap, etc.).
 */
async function handleCommandNotFound(ctx) {
    const { m, responderTexto, comandosMap, config, comando } = ctx;

    // Obtener todos los comandos válidos del mapa de comandos
    const allCommands = Array.from(comandosMap.keys());
    
    // Si la entrada es muy corta, no sugerimos nada
    if (comando.length < 2) {
        await responderTexto(m, `❌ El comando \`${config.prefijo}${comando}\` no existe.`);
        return;
    }

    const matches = stringSimilarity.findBestMatch(comando, allCommands);
    const bestMatch = matches.bestMatch;
    const similarityThreshold = 0.5; // Puedes ajustar este valor

    if (bestMatch.rating >= similarityThreshold) {
        const percentage = Math.round(bestMatch.rating * 100);
        const mensajeError = `❌ Este comando no existe. ¿Quizás quisiste escribir \`${config.prefijo}${bestMatch.target}\`? (Similitud del ${percentage}%).`;
        await responderTexto(m, mensajeError);
    } else {
        await responderTexto(m, `❌ El comando \`${config.prefijo}${comando}\` no existe.`);
    }
}

module.exports = { handleCommandNotFound };
