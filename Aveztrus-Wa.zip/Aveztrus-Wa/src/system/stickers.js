const fs = require('fs');
const { execSync } = require('child_process');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

async function createSticker(quoted, type, tempDir) {
    const timestamp = Date.now();
    let inputPath, outputPath;

    try {
        const stream = await downloadContentFromMessage(quoted, type);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

        if (type === 'image') {
            inputPath = path.join(tempDir, `img_${timestamp}.jpg`);
            outputPath = path.join(tempDir, `sticker_${timestamp}.webp`);
            fs.writeFileSync(inputPath, buffer);
            execSync(`ffmpeg -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=increase" "${outputPath}"`);
        } else { // video
            inputPath = path.join(tempDir, `vid_${timestamp}.mp4`);
            outputPath = path.join(tempDir, `sticker_${timestamp}.webp`);
            fs.writeFileSync(inputPath, buffer);

            const videoDuration = quoted.seconds;
            if (videoDuration > 8) throw new Error('El video no puede durar más de 8 segundos');

            execSync(`ffmpeg -i "${inputPath}" -vcodec libwebp -fs 0.99M -filter_complex "[0:v] scale=512:512, fps=15, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse" -f webp "${outputPath}"`);
        }

        return outputPath; // devolvemos la ruta directa
    } catch (error) {
        if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
        if (outputPath && fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
        throw error;
    }
}

module.exports = { createSticker };