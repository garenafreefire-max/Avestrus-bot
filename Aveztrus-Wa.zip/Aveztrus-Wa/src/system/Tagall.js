module.exports = {
    obtenerTextoComando: (m, prefijo, nombreComando) => {
        const textoCompleto = m.message?.conversation || m.message?.extendedTextMessage?.text;
        if (!textoCompleto) return '';
        
        // Corta el prefijo y el nombre del comando para obtener solo el mensaje
        const inicioMensaje = prefijo.length + nombreComando.length;
        const mensajeFinal = textoCompleto.slice(inicioMensaje).trimStart();
        
        return mensajeFinal;
    }
};
