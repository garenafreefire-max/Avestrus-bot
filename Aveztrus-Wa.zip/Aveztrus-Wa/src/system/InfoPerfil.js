const path = require('path');

/**
 * Cambia la descripción del perfil del bot en WhatsApp.
 * @param {import('@whiskeysockets/baileys').WASocket} sock
 * @param {string} nuevaDescripcion La nueva descripción para el perfil del bot.
 */
async function cambiarDescripcion(sock, nuevaDescripcion) {
    try {
        await sock.updateProfileStatus(nuevaDescripcion);
        return true;
    } catch (error) {
        console.error('Error en cambiarDescripcion:', error);
        return false;
    }
}

module.exports = {
    cambiarDescripcion,
};
