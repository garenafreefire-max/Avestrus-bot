const path = require('path');

module.exports = {
    nombre: 'on',
    descripcion: 'Prende el bot en este grupo.',
    comando: ['on', 'onbot'],
    ejecutar: async (ctx) => {
        const { jid, setBotStatus, ResponderTextoFalso, esAdmin } = ctx;

        if (!jid.endsWith('@g.us')) {
            return ResponderTextoFalso('❌ Este comando solo se puede usar en grupos.');
        }
        if (!esAdmin) {
            return ResponderTextoFalso('⚠️ No tienes permiso para usar este comando.');
        }

        const success = setBotStatus(jid, true); // 🔹 ahora agrega a la lista
        if (success) {
            await ResponderTextoFalso('🟢 Bot encendido en este grupo.');
        } else {
            await ResponderTextoFalso('❌ Ocurrió un error al encender el bot. Inténtalo de nuevo.');
        }
    }
};