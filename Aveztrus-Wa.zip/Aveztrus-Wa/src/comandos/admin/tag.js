const { obtenerTextoComando } = require('../../system/tagall');

module.exports = {
    nombre: 'heg',
    descripcion: 'Menciona a todos los miembros del grupo con un mensaje que soporte múltiples líneas.',
    comando: ['tag', 'tagall', 'todos'],
    ejecutar: async (ctx) => {
        // Asegúrate de incluir 'ResponderTextoFalso' en el destructuring de ctx
        const { jid, ResponderTextoFalso, sock, config, m } = ctx;

        if (!jid.endsWith('@g.us')) {
            // Usa ResponderTextoFalso para el mensaje de error también
            return ResponderTextoFalso('❌ Este comando solo funciona en grupos.');
        }

        const mensajeParaEnviar = obtenerTextoComando(m, config.prefijo, 'heg');

        if (!mensajeParaEnviar.trim()) {
            return ResponderTextoFalso(`❌ Debes especificar un mensaje. Ejemplo: ${config.prefijo}tag a todos`);
        }

        try {
            const metadata = await sock.groupMetadata(jid);
            const participantes = metadata.participants;
            
            const jids = participantes
                .filter(p => p.id !== `${config.Botnumero}@s.whatsapp.net`)
                .map(p => p.id);

            if (jids.length === 0) {
                return ResponderTextoFalso('❌ No hay miembros para mencionar.');
            }

            if (jids.length > 600) {
                return ResponderTextoFalso('❌ Demasiados miembros (máx 600 menciones).');
            }

            // Usa ResponderTextoFalso para enviar el mensaje con las menciones y el contexto falso
            await ResponderTextoFalso(mensajeParaEnviar, jids);
            
        } catch (error) {
            console.error('Error en tag:', error);
            ResponderTextoFalso('❌ Ocurrió un error al mencionar a todos.');
        }
    }
};
