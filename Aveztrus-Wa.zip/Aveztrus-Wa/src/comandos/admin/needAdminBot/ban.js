// ban.js

module.exports = {
    nombre: 'ban',
    descripcion: 'Banea a un usuario del grupo',
    comando: ['ban', 'kick'],
    ejecutar: async (ctx) => {
        const { args, EnviarRespuestaFalsa, jid, m, sock } = ctx;

        // Verificar si estamos en un grupo
        if (!jid.endsWith('@g.us')) {
            return EnviarRespuestaFalsa('⚠️ Este comando solo funciona en grupos');
        }

        // Obtener usuarios mencionados
        const mencionados = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

        // Verificar si se mencionó a alguien
        if (mencionados.length === 0) {
            return EnviarRespuestaFalsa('🔎 Debes mencionar a un usuario');
        }

        // Función de utilidad para introducir un retraso
        const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

        try {
            // Recorremos el array de usuarios mencionados para banearlos de uno en uno
            for (const usuario of mencionados) {
                // Intentar banear al usuario
                await sock.groupParticipantsUpdate(
                    jid,
                    [usuario], // Pasamos el usuario individualmente en un array
                    'remove'
                );
                
                // Pequeño retraso de 1 segundo entre cada ban para evitar comportamientos masivos
                await sleep(1000);
            }

            // Enviar confirmación con respuesta falsa
            await EnviarRespuestaFalsa(`✅ Usuario(s) baneado(s) correctamente`);

        } catch (error) {
            // Manejar errores específicos
            if (error.message.includes('not-authorized') ||
                error.message.includes('not an admin') ||
                error.output?.statusCode === 401) {
                await EnviarRespuestaFalsa('❌ No puedo banear al usuario porque no soy administrador');
            } else {
                // Solo mostrar errores inesperados en consola
                console.error('Error inesperado en comando ban:', error);
                await EnviarRespuestaFalsa('❌ Ocurrió un error al banear al usuario');
            }
        }
    }
};
