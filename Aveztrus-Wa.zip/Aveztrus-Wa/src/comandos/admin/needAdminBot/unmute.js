const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'unmute',
    descripcion: 'Desmutea a un usuario en el grupo para que sus mensajes ya no sean eliminados.',
    comando: ['unmute', 'desmutear'],
    ejecutar: async (ctx) => {
        const { responderTexto, jid, m, sock } = ctx;

        if (!jid.endsWith('@g.us')) {
            return responderTexto('⚠️ Este comando solo funciona en grupos.');
        }

        const mencionados = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        
        if (mencionados.length === 0) {
            return responderTexto('🔎 Debes mencionar al usuario que quieres desmutear.');
        }

        const userJid = mencionados[0];

        let pushName = userJid.split('@')[0];
        try {
            const [contact] = await sock.onWhatsApp(userJid);
            if (contact?.pushName) {
                pushName = contact.pushName;
            }
        } catch (error) {
            // No hacer nada, usar el nombre por defecto si falla
        }

        const dbPath = path.join(__dirname, '..', '..', '..', 'database', 'muted_users.json');

        try {
            let mutedUsers = {};
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                mutedUsers = JSON.parse(data);
            } catch (readError) {
                // Si el archivo no existe o está vacío, no hay usuarios silenciados
                return responderTexto(`⚠️ El usuario @${pushName} no está silenciado en este grupo.`);
            }

            // Lógica corregida para desmutear por grupo
            if (!mutedUsers[jid] || !mutedUsers[jid][userJid]) {
                return responderTexto(`⚠️ El usuario @${pushName} no está silenciado en este grupo.`);
            }

            delete mutedUsers[jid][userJid];

            // Si el grupo se queda sin usuarios silenciados, borra la entrada del grupo
            if (Object.keys(mutedUsers[jid]).length === 0) {
                delete mutedUsers[jid];
            }

            await fs.writeFile(dbPath, JSON.stringify(mutedUsers, null, 2));

            const mensaje = `✅ El usuario @${pushName} fue desmuteado en este grupo.`;

            await sock.sendMessage(jid, {
                text: mensaje,
                mentions: [userJid]
            });

        } catch (error) {
            console.error('Error en comando unmute:', error);
            await responderTexto('❌ Ocurrió un error al desmutear al usuario.');
        }
    }
};
