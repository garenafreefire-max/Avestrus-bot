module.exports = {
    nombre: 'abrir',
    descripcion: 'Abre el grupo para todos los miembros',
    comando: ['abrir', 'open'],
    ejecutar: async (ctx) => {
        const { sock, jid, EnviarRespuestaFalsa } = ctx;
        
        try {
            // Obtener metadatos actualizados del grupo
            const metadata = await sock.groupMetadata(jid);
            
            // Verificar si el grupo ya está abierto
            if (!metadata.announce) {
                await EnviarRespuestaFalsa('⚠️ No puedo abrir el grupo porque ya está abierto');
                return;
            }
            
            // Intentar abrir el grupo
            await sock.groupSettingUpdate(jid, 'not_announcement');
            await EnviarRespuestaFalsa('✅ El grupo ha sido abierto con éxito');
            
        } catch (error) {
            // Manejar errores específicos
            if (error.message.includes('not-authorized') || 
                error.message.includes('not an admin') || 
                error.output?.statusCode === 401) {
                await EnviarRespuestaFalsa('❌ No puedo abrir el grupo porque no soy administrador');
            } else if (error.message.includes('announcement') || 
                       error.message.includes('already open')) {
                await EnviarRespuestaFalsa('⚠️ No puedo abrir el grupo porque ya está abierto');
            } else {
                console.error('Error inesperado en comando abrir:', error);
                await EnviarRespuestaFalsa('❌ Ocurrió un error al abrir el grupo');
            }
        }
    }
};