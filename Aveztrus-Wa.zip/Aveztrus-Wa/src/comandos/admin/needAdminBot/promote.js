module.exports = {
    nombre: 'promote',
    descripcion: 'Convierte a un usuario en administrador del grupo',
    comando: ['promote', 'daradmin'],
    ejecutar: async (ctx) => {
        const { responderTexto, jid, m, sock } = ctx;
        
        try {
            // Verificar si es grupo
            if (!jid.endsWith('@g.us')) {
                return responderTexto('⚠️ Este comando solo funciona en grupos');
            }

            // Obtener usuarios mencionados
            const mencionados = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
            
            // Verificar menciones
            if (mencionados.length === 0) {
                return responderTexto('🔎 Debes mencionar al usuario que quieres hacer admin');
            }

            // Obtener metadatos del grupo
            const metadata = await sock.groupMetadata(jid);
            const participantes = metadata.participants;
            
            // Procesar cada usuario mencionado
            const resultados = [];
            const menciones = [];
            const pushNames = [];
            
            for (const user of mencionados) {
                // Obtener pushname primero
                let pushName = user.split('@')[0]; // Valor por defecto
                try {
                    const [contact] = await sock.onWhatsApp(user);
                    if (contact?.pushName) {
                        pushName = contact.pushName;
                    }
                } catch (error) {
                    // Mantener valor por defecto
                }
                
                // Buscar al usuario en los participantes
                const participante = participantes.find(p => p.id === user);
                
                if (!participante) {
                    resultados.push('❌ El usuario no está en el grupo');
                    menciones.push(user);
                    pushNames.push(pushName);
                    continue;
                }
                
                // Verificar si ya es admin
                if (participante.admin === 'admin' || participante.admin === 'superadmin') {
                    resultados.push('⚠️ El usuario ya es administrador');
                    menciones.push(user);
                    pushNames.push(pushName);
                    continue;
                }
                
                // Intentar promover
                try {
                    await sock.groupParticipantsUpdate(jid, [user], 'promote');
                    resultados.push('✅ Ahora es administrador');
                    menciones.push(user);
                    pushNames.push(pushName);
                } catch (error) {
                    resultados.push('❌ No pude hacer admin al usuario');
                    menciones.push(user);
                    pushNames.push(pushName);
                }
            }

            // Construir mensaje simplificado
            let mensaje = '';
            for (let i = 0; i < menciones.length; i++) {
                mensaje += `@${pushNames[i]} ${resultados[i]}\n`;
            }
            
            // Enviar respuesta con menciones
            await sock.sendMessage(jid, {
                text: mensaje.trim(),
                mentions: menciones
            });
            
        } catch (error) {
            // Manejar errores específicos
            if (error.message.includes('not-authorized') || 
                error.message.includes('not an admin') || 
                error.output?.statusCode === 401) {
                await responderTexto('❌ No tengo permisos para hacer administradores');
            } else {
                console.error('Error en comando promote:', error);
                await responderTexto('❌ Ocurrió un error al hacer administrador');
            }
        }
    }
};