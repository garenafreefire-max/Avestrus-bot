const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'mute',
    descripcion: 'Silencia a un usuario en el grupo para que sus mensajes sean eliminados.',
    comando: ['mute', 'silenciar'],
    ejecutar: async (ctx) => {
        const { responderTexto, jid, m, sock } = ctx;

        if (!jid.endsWith('@g.us')) {
            return responderTexto('⚠️ Este comando solo funciona en grupos.');
        }

        const mencionados = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        
        if (mencionados.length === 0) {
            return responderTexto('🔎 Debes mencionar al usuario que quieres silenciar.');
        }

        const userJid = mencionados[0];

        let pushName = userJid.split('@')[0];
        try {
            const [contact] = await sock.onWhatsApp(userJid);
            if (contact?.pushName) {
                pushName = contact.pushName;
            }
        } catch (error) {
            // No hacer nada, usar el nombre por defecto
        }
        
        const dbPath = path.join(__dirname, '..', '..', '..', 'database', 'muted_users.json');

        try {
            let mutedUsers = {};
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                mutedUsers = JSON.parse(data);
            } catch (readError) {
                // Si el archivo no existe o está vacío, la variable queda como {}
            }

            // Lógica corregida para mute por grupo
            if (!mutedUsers[jid]) {
                mutedUsers[jid] = {};
            }

            if (mutedUsers[jid][userJid]) {
                return responderTexto(`⚠️ El usuario @${pushName} ya está silenciado en este grupo.`);
            }

            mutedUsers[jid][userJid] = true;
            await fs.writeFile(dbPath, JSON.stringify(mutedUsers, null, 2));

            const mensaje = `✅ El usuario @${pushName} fue muteado en este grupo. Sus mensajes serán eliminados.`;

            await sock.sendMessage(jid, {
                text: mensaje,
                mentions: [userJid]
            });

        } catch (error) {
            console.error('Error en comando mute:', error);
            await responderTexto('❌ Ocurrió un error al silenciar al usuario.');
        }
    }
};
