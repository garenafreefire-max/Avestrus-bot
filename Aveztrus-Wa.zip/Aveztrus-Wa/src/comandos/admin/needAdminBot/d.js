module.exports = {
  nombre: 'd',
  descripcion: 'Elimina un mensaje respondiéndolo.',
  comando: ['d', 'del'],
  ejecutar: async (ctx) => {
    try {
      const { m, EnviarRespuestaFalsa, sock, jid } = ctx;

      // Verifica si se está respondiendo a un mensaje.
      if (!m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        return EnviarRespuestaFalsa('⚠️ Responde a un mensaje para eliminarlo.');
      }
      
      const quoted = m.message.extendedTextMessage.contextInfo;
      
      // Objeto de la clave del mensaje que se va a eliminar
      const keyToDelete = {
        remoteJid: jid,
        fromMe: false,
        id: quoted.stanzaId,
        participant: quoted.participant
      };
      
      // Objeto de la clave del comando del usuario para eliminarlo también
      const commandKey = {
        remoteJid: jid,
        fromMe: m.key.fromMe,
        id: m.key.id,
        participant: m.key.participant
      };
      
      // Intenta eliminar el mensaje respondido
      await sock.sendMessage(jid, { delete: keyToDelete });
      
      // Intenta eliminar el comando del usuario
      await sock.sendMessage(jid, { delete: commandKey });

    } catch (error) {
      console.error('Error al eliminar:', error);
      // No se envía mensaje al chat si hay un error, solo se registra en la consola.
    }
  }
};
