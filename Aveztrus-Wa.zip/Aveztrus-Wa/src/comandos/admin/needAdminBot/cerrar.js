module.exports = {
    nombre: 'cerrar',
    descripcion: 'Cierra el grupo solo para administradores',
    comando: ['cerrar', 'close'],
    ejecutar: async (ctx) => {
        const { sock, jid, EnviarRespuestaFalsa } = ctx;
        
        try {
            // Obtener metadatos actualizados del grupo
            const metadata = await sock.groupMetadata(jid);
            
            // Verificar si el grupo ya está cerrado
            if (metadata.announce) {
                await EnviarRespuestaFalsa('⚠️ No puedo cerrar el grupo porque ya está cerrado');
                return;
            }
            
            // Intentar cerrar el grupo
            await sock.groupSettingUpdate(jid, 'announcement');
            await EnviarRespuestaFalsa('✅ El grupo ha sido cerrado con éxito');
            
        } catch (error) {
            // Manejar errores específicos sin mostrar en consola
            if (error.message.includes('not-authorized') || 
                error.message.includes('not an admin') || 
                error.output?.statusCode === 401) {
                await EnviarRespuestaFalsa('❌ No puedo cerrar el grupo porque no soy administrador');
            } else if (error.message.includes('announcement') || 
                       error.message.includes('already closed')) {
                await EnviarRespuestaFalsa('⚠️ No puedo cerrar el grupo porque ya está cerrado');
            } else {
                // Solo mostrar errores inesperados en consola
                console.error('Error inesperado en comando cerrar:', error);
                await EnviarRespuestaFalsa('❌ Ocurrió un error al cerrar el grupo');
            }
        }
    }
};