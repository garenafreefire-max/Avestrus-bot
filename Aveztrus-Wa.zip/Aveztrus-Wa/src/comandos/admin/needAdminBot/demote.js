module.exports = {
    nombre: 'demote',
    descripcion: 'Quita privilegios de administrador a un usuario',
    comando: ['demote', 'quitaradmin'],
    ejecutar: async (ctx) => {
        const { responderTexto, jid, m, sock } = ctx;
        
        try {
            // Verificar si es grupo
            if (!jid.endsWith('@g.us')) {
                return responderTexto('⚠️ Este comando solo funciona en grupos');
            }

            // Obtener usuarios mencionados
            const mencionados = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
            
            // Verificar menciones
            if (mencionados.length === 0) {
                return responderTexto('🔎 Debes mencionar al administrador que quieres degradar');
            }

            // Obtener metadatos del grupo
            const metadata = await sock.groupMetadata(jid);
            const participantes = metadata.participants;
            
            // Procesar cada usuario mencionado
            const resultados = [];
            const menciones = [];
            const pushNames = [];
            
            for (const user of mencionados) {
                // Obtener pushname primero
                let pushName = user.split('@')[0]; // Valor por defecto
                try {
                    const [contact] = await sock.onWhatsApp(user);
                    if (contact?.pushName) {
                        pushName = contact.pushName;
                    }
                } catch (error) {
                    // Mantener valor por defecto
                }
                
                // Buscar al usuario en los participantes
                const participante = participantes.find(p => p.id === user);
                
                if (!participante) {
                    resultados.push('❌ El usuario no está en el grupo');
                    menciones.push(user);
                    pushNames.push(pushName);
                    continue;
                }
                
                // Verificar si no es admin
                if (!participante.admin || participante.admin === 'member') {
                    resultados.push('⚠️ El usuario no es administrador');
                    menciones.push(user);
                    pushNames.push(pushName);
                    continue;
                }
                
                // Intentar degradar
                try {
                    await sock.groupParticipantsUpdate(jid, [user], 'demote');
                    resultados.push('⚠️ Ya no es administrador');
                    menciones.push(user);
                    pushNames.push(pushName);
                } catch (error) {
                    resultados.push('❌ No pude quitar privilegios al usuario');
                    menciones.push(user);
                    pushNames.push(pushName);
                }
            }

            // Construir mensaje simplificado
            let mensaje = '';
            for (let i = 0; i < menciones.length; i++) {
                mensaje += `@${pushNames[i]} ${resultados[i]}\n`;
            }
            
            // Enviar respuesta con menciones
            await sock.sendMessage(jid, {
                text: mensaje.trim(),
                mentions: menciones
            });
            
        } catch (error) {
            // Manejar errores específicos
            if (error.message.includes('not-authorized') || 
                error.message.includes('not an admin') || 
                error.output?.statusCode === 401) {
                await responderTexto('❌ No tengo permisos para quitar administradores');
            } else {
                console.error('Error en comando demote:', error);
                await responderTexto('❌ Ocurrió un error al quitar privilegios');
            }
        }
    }
};