const path = require('path');

module.exports = {
    nombre: 'off',
    descripcion: 'Apaga el bot en este grupo. Solo los comandos de encendido y apagado funcionarán.',
    comando: ['off', 'offbot'],
    ejecutar: async (ctx) => {
        const { jid, setBotStatus, ResponderTextoFalso, esAdmin } = ctx;

        if (!jid.endsWith('@g.us')) {
            return ResponderTextoFalso('❌ Este comando solo se puede usar en grupos.');
        }
        if (!esAdmin) {
            return ResponderTextoFalso('⚠️ No tienes permiso para usar este comando.');
        }

        const success = setBotStatus(jid, false); // 🔹 ahora quita de la lista
        if (success) {
            await ResponderTextoFalso('🔴 Bot apagado en este grupo. Solo admins podrán volver a encenderlo.');
        } else {
            await ResponderTextoFalso('❌ Ocurrió un error al apagar el bot. Inténtalo de nuevo.');
        }
    }
};