const path = require('path');
const fs = require('fs');

module.exports = {
  nombre: 'bienvenida',
  descripcion: 'Activa o desactiva los mensajes de bienvenida en el grupo.',
  comando: ['w'],
  ejecutar: async (ctx) => {
    // 🔹 Usamos solo las variables necesarias
    const { args, jid, responderTexto, esAdmin, config } = ctx;

    // Solo funciona en grupos
    if (!jid.endsWith('@g.us')) {
      return await responderTexto('⚠️ Este comando solo puede usarse en un grupo.');
    }

    if (!esAdmin) {
      return await responderTexto('❌ Este comando es solo para administradores.');
    }

    if (!args[0]) {
      return await responderTexto('⚠️ *Uso incorrecto:*\n\n' +
        `*${config.prefijo}w 1* - Activa la bienvenida.\n` +
        `*${config.prefijo}w 0* - Desactiva la bienvenida.`);
    }

    const estado = args[0] === '1';

    const welcomeConfigPath = path.join(__dirname, '../../database/welcome.json');
    let welcomeConfig = {};

    if (fs.existsSync(welcomeConfigPath)) {
      welcomeConfig = JSON.parse(fs.readFileSync(welcomeConfigPath, 'utf8'));
    }

    if (estado) {
      welcomeConfig[jid] = true;
      fs.writeFileSync(welcomeConfigPath, JSON.stringify(welcomeConfig, null, 2), 'utf8');
      await responderTexto('✅ Mensajes de bienvenida activados.');
    } else {
      welcomeConfig[jid] = false;
      fs.writeFileSync(welcomeConfigPath, JSON.stringify(welcomeConfig, null, 2), 'utf8');
      await responderTexto('❌ Mensajes de bienvenida desactivados.');
    }
  }
};
