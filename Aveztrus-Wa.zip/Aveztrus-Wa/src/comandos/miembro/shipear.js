const path = require('path');
const fs = require('fs');

// Ruta del archivo de registro de usuarios
const userRegPath = path.join(__dirname, '../../database/UserReg.json');

module.exports = {
  nombre: 'ship',
  descripcion: 'Empareja a dos miembros del grupo al azar por diversión.',
  comando: ['ship', 'pareja'],
  ejecutar: async (ctx) => {
    const { jid, remitente, sock, Botnumero, ResponderTextoFalso } = ctx;

    // Solo funciona en grupos
    if (!jid.endsWith('@g.us')) {
      await ResponderTextoFalso('⚠️ Este comando solo puede usarse en un grupo.');
      return;
    }

    // Cargar la base de datos de usuarios
    let usuarios = [];
    try {
      usuarios = JSON.parse(fs.readFileSync(userRegPath, 'utf8'));
    } catch (e) {
      console.error('Error al leer la base de datos de usuarios:', e);
      await ResponderTextoFalso('❌ Ocurrió un error al cargar los datos de usuario.');
      return;
    }

    // Obtener los participantes del grupo
    const metadata = await sock.groupMetadata(jid);
    const participantes = metadata.participants;
    
    // Obtener los JIDs de los usuarios que están registrados y en el grupo, excluyendo al bot.
    const usuariosEnGrupo = participantes
        .filter(p => usuarios.some(u => u.Usuario === p.id) && p.id !== Botnumero)
        .map(p => p.id);

    // Validar que haya al menos dos usuarios registrados en el grupo.
    if (usuariosEnGrupo.length < 2) {
      await ResponderTextoFalso('❌ No hay suficientes usuarios registrados en este grupo para formar una pareja.');
      return;
    }

    // Seleccionar dos JIDs al azar y asegurarse de que no sean el mismo.
    let usuario1Jid;
    let usuario2Jid;
    do {
      usuario1Jid = usuariosEnGrupo[Math.floor(Math.random() * usuariosEnGrupo.length)];
      usuario2Jid = usuariosEnGrupo[Math.floor(Math.random() * usuariosEnGrupo.length)];
    } while (usuario1Jid === usuario2Jid);

    // Obtener el nombre de los usuarios directamente de la metadata
    const usuario1Nombre = participantes.find(p => p.id === usuario1Jid)?.pushName || usuario1Jid.split('@')[0];
    const usuario2Nombre = participantes.find(p => p.id === usuario2Jid)?.pushName || usuario2Jid.split('@')[0];
    
    // Lista de mensajes aleatorios
    const mensajes = [
        `¡Felicidades! 🎉 @${usuario1Nombre} y @${usuario2Nombre} son la pareja del día. ¡Qué viva el amor! 🥰`,
        `¡OMG! 😱 Se me hace que @${usuario1Nombre} y @${usuario2Nombre} harían una pareja perfecta. ¿Qué opinan? 🤔`,
        `El destino ha hablado: la pareja perfecta es @${usuario1Nombre} y @${usuario2Nombre}. ¡Son dinamita pura!💥`,
        `Mi corazón de bot no se equivoca, @${usuario1Nombre} y @${usuario2Nombre} están destinados a estar juntos. ❤️`,
        `La vida es un viaje, y parece que @${usuario1Nombre} y @${usuario2Nombre} van a viajar juntos. 😉`
    ];

    // Seleccionar un mensaje aleatorio
    const mensajeAleatorio = mensajes[Math.floor(Math.random() * mensajes.length)];

    // Enviar el mensaje con las menciones
    await ResponderTextoFalso(mensajeAleatorio, [usuario1Jid, usuario2Jid]);
  }
};
