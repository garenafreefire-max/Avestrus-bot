const path = require('path');
const fs = require('fs').promises;

// Función para sanitizar texto y evitar caracteres problemáticos
function sanitizarTexto(texto) {
    return texto
        .normalize('NFD') // Descomponer caracteres acentuados
        .replace(/[\u0300-\u036f]/g, '') // Eliminar diacríticos
        .replace(/[^\w\sáéíóúÁÉÍÓÚñÑüÜ.,\-()]/gi, ''); // Permitir solo caracteres seguros
}

module.exports = {
    nombre: 'reg',
    descripcion: 'Te registra para los comandos de economía. Ejemplo: $reg Nombre | edad | país',
    comando: ['reg', 'registro', 'registrarme'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, args, userJid, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', 'database', 'UserReg.json');
        
        // Crear directorio si no existe
        try {
            await fs.mkdir(path.dirname(dbPath), { recursive: true });
        } catch (error) {
            console.error('Error creando directorio:', error);
        }
        
        const input = args.join(' ');
        const partes = input.split('|').map(p => p.trim());
        
        if (partes.length !== 3) {
            return ResponderTextoFalso(`⚠️ Formato incorrecto. Usa: *${config.prefijo}reg Nombre | edad | país*\nEjemplo: *${config.prefijo}reg Juan Pérez | 25 | México*`);
        }
        
        let [nombre, edad, pais] = partes;
        
        // Sanitizar entradas
        nombre = sanitizarTexto(nombre).substring(0, 30);
        pais = sanitizarTexto(pais).substring(0, 20);
        
        // Validaciones
        if (!nombre || !pais) {
            return ResponderTextoFalso('❌ El nombre y el país no pueden estar vacíos.');
        }
        
        const edadNum = parseInt(edad);
        if (isNaN(edadNum) || edadNum <= 0 || edadNum > 120) {
            return ResponderTextoFalso('❌ La edad debe ser un número entre 1 y 120 años.');
        }
        
        if (nombre.length < 2) {
            return ResponderTextoFalso('❌ El nombre debe tener al menos 2 caracteres.');
        }
        
        if (pais.length < 2) {
            return ResponderTextoFalso('❌ El país debe tener al menos 2 caracteres.');
        }

        try {
            let usuariosRegistrados = [];
            
            // Leer archivo existente con manejo de errores mejorado
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
                
                // Validar que sea un array
                if (!Array.isArray(usuariosRegistrados)) {
                    usuariosRegistrados = [];
                }
            } catch (readError) {
                // Si el archivo no existe o está corrupto, empezar con array vacío
                usuariosRegistrados = [];
            }

            // Verificar si el usuario ya está registrado
            const usuarioExistente = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (usuarioExistente) {
                return ResponderTextoFalso(`🚫 Ya estás registrado como *${usuarioExistente.Nombre}*.\nUsa *${config.prefijo}miperfil* para ver tu información.`);
            }

            // Verificar si el nombre ya existe
            const nombreExistente = usuariosRegistrados.find(u => 
                u.Nombre.toLowerCase() === nombre.toLowerCase()
            );
            
            if (nombreExistente) {
                return ResponderTextoFalso(`🚫 El nombre "*${nombre}*" ya está en uso. Por favor, elige otro.`);
            }

            // Crear fecha y hora actual
            const ahora = new Date();
            const fecha = ahora.toLocaleDateString('es-ES');
            const hora = ahora.toLocaleTimeString('es-ES');
            
            // Crear nuevo usuario
            const nuevoUsuario = {
                Usuario: userJid,
                Diamante: 10, // Bonus por registro
                Moneda: 100,  // Dinero inicial
                Banco: 0,
                Nombre: nombre,
                Edad: edadNum,
                País: pais,
                regFecha: fecha,
                regHora: hora
            };

            usuariosRegistrados.push(nuevoUsuario);

            // Guardar con codificación UTF-8 explícita
            await fs.writeFile(
                dbPath, 
                JSON.stringify(usuariosRegistrados, null, 2), 
                { encoding: 'utf8' }
            );

            // Mensaje de éxito
            await ResponderTextoFalso(
                `✅ ¡Registro completado, *${nombre}*!\n` +
                `📅 Fecha: *${fecha}*\n` +
                `⏰ Hora: *${hora}*\n` +
                `🎁 Bonus: *10 diamantes* y *100 monedas*\n\n` +
                `Usa *${config.prefijo}miperfil* para ver tu información.`
            );

        } catch (error) {
            console.error('Error en el comando reg:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al intentar registrarte. Intenta nuevamente.');
        }
    }
};