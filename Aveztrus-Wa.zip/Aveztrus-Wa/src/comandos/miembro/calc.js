const axios = require('axios');

module.exports = {
  nombre: 'calc',
  descripcion: 'Calculadora avanzada con Wolfram Alpha.',
  comando: ['calc', 'calcular', 'math'],

  /**
   * @param {Object} ctx - Objeto de contexto del mensaje
   * @param {string[]} ctx.args - Argumentos del comando
   * @param {function(string, string[], boolean=): Promise<void>} ctx.responderTexto - Función para responder texto (usando el nombre exacto de tu bot.js)
   * @param {Object} ctx.config - Objeto de configuración (contiene prefijo, WOLFRAM_API_URL, WOLFRAM_API_KEY)
   * @returns {Promise<void>}
   */
  ejecutar: async (ctx) => {
    // ➡️ CAMBIO CLAVE: Ahora usamos 'responderTexto' (todo en minúsculas)
    const { args, responderTexto, config } = ctx;

    if (!args || args.length === 0) {
      // ➡️ MEJORA DE DISEÑO: Más decorado
      return responderTexto(
        '🚀 *¡Calcula lo que sea!* 🧐\n\n' +
        `❌ *Uso Incorrecto:*\n` +
        `   Debes ingresar una operación matemática.\n\n` +
        `📌 *Ejemplo:* ${config.prefijo}calc (450 * 5) / 2\n\n` +
        '✨ *Símbolos Clave:*\n' +
        ' • *Suma:* `+`\n' +
        ' • *Resta:* `-`\n' +
        ' • *Multiplicación:* `*` o `x`\n' +
        ' • *División:* `/`\n' +
        ' • *Potencia:* `^` (ej: 2^3)\n' +
        ' • *Raíz Cuadrada:* `sqrt(número)`\n' +
        ' • *Paréntesis:* `( )` para agrupar'
      );
    }

    try {
      let queryRaw = args.join(' ');
      // Reemplazamos 'x' por '*' para cálculos, pero mantenemos 'x' para texto/consultas
      let query = queryRaw.replace(/x/gi, '*');

      const url = `${config.WOLFRAM_API_URL}?input=${encodeURIComponent(query)}&format=plaintext&output=JSON&reinterpret=true&translation=true&hl=es&appid=${config.WOLFRAM_API_KEY}`;
      
      const { data } = await axios.get(url);

      if (data.queryresult?.success) {
        let respuesta = '━━━━━━━━━━━\n';
        respuesta += '✨ *RESULTADO DE CÁLCULO* ✨\n';
        respuesta += '━━━━━━━━━━━\n';
        
        for (const pod of data.queryresult.pods || []) {
          const subpod = pod.subpods?.[0];
          if (!subpod) continue;

          // Solo procesamos el texto
          if (subpod.plaintext) {
            respuesta += `\n*${pod.title}*:\n` + `>>> ${subpod.plaintext.trim()}\n`;
          }
        }
        
        // ➡️ CAMBIO: Usar responderTexto para el resultado final
        await responderTexto(respuesta.trim());

      } else {
        // ➡️ MEJORA DE DISEÑO: Más decorado
        return responderTexto(
          '⚠️ *¡Cálculo Imposible!* 😭\n\n' +
          '❌ No pude resolver tu operación o consulta.\n' +
          '   Asegúrate de que la sintaxis sea correcta (usa `*` para multiplicar) o reformula tu pregunta.\n\n' +
          '✨ *Símbolos Clave:*\n' +
          ' • *Suma:* `+`\n' +
          ' • *Resta:* `-`\n' +
          ' • *Multiplicación:* `*` o `x`\n' +
          ' • *División:* `/`'
        );
      }
    } catch (error) {
      console.error('❌ Error con la API de Wolfram Alpha:', error);
      // ➡️ CAMBIO: Usar responderTexto para el error
      return responderTexto('🚨 *¡Error del Servidor!* 😱 Ocurrió un error al procesar tu cálculo. Inténtalo más tarde.');
    }
  }
};
