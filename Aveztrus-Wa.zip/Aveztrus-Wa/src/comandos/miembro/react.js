module.exports = {
    nombre: 'reaccionar',
       descripcion: 'Reacciona al mensaje con emojis progresivos',
          comando: ['reaccionar', 'react'],
               ejecutar: async (ctx) => {
                 try {
                   await ctx.reaccionarMensaje('🍆');
                     await new Promise(resolve => setTimeout(resolve, 1000));
                       await ctx.reaccionarMensaje('🥵');
                        await ctx.responderTexto('✅ ¡Reacciones completadas!');
                          } catch (error) {
                           console.error('Error en comando reaccionar:', error);
                            await ctx.responderTexto('❌ Ocurrió un error al reaccionar');
                              }
                               }
                                };