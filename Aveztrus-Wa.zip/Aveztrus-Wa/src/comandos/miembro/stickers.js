const fs = require('fs');
const path = require('path');
const { createSticker } = require('../../system/stickers');

module.exports = {
    nombre: 'sticker',
    descripcion: 'Convierte una imagen o video en sticker',
    comando: ['s'],
    ejecutar: async (ctx) => {
        const { m, responderTexto, config, EnviarStickerFalso } = ctx;

        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted) return responderTexto(`❌ Responde a una imagen, video o gif con ${config.prefijo}s`);

        try {
            const tempDir = path.join(__dirname, '../../media/temp/stickers');
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

            let stickerPath;

            if (quoted.imageMessage) {
                stickerPath = await createSticker(quoted.imageMessage, 'image', tempDir);
                await EnviarStickerFalso(m, stickerPath);
            } else if (quoted.videoMessage) {
                stickerPath = await createSticker(quoted.videoMessage, 'video', tempDir);
                await EnviarStickerFalso(m, stickerPath, true);
            } else if (quoted.stickerMessage && quoted.stickerMessage.isAnimated) {
                // Sticker animado ya existente
                const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
                const stream = await downloadContentFromMessage(quoted.stickerMessage, 'sticker');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

                const timestamp = Date.now();
                const inputPath = path.join(tempDir, `sticker_${timestamp}.webp`);
                fs.writeFileSync(inputPath, buffer);

                await EnviarStickerFalso(m, inputPath, true);
            } else {
                return responderTexto('❌ Formato no soportado. Responde a una imagen, video o gif.');
            }

            // Limpiar archivo temporal
            setTimeout(() => {
                try { if (fs.existsSync(stickerPath)) fs.unlinkSync(stickerPath); } catch {}
            }, 30000);

        } catch (error) {
            console.error('Error en s.js:', error);
            responderTexto(`❌ Ocurrió un error al ejecutar el comando: ${error.message}`);
        }
    }
};