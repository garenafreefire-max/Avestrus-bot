const fetch = require('node-fetch'); // node-fetch v2
const path = require('path');
const fs = require('fs');

/**
 * Escapa caracteres HTML para evitar inyección y asegurar que el texto se muestre correctamente.
 * @param {string} text - El texto a escapar.
 * @returns {string} El texto escapado.
 */
function escapeHtml(text) {
  if (typeof text !== 'string') return text;
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

module.exports = {
  descripcion: 'Obtiene información detallada de perfiles de TikTok',
  comando: ['tikinfouser'],
  
  /**
   * @param {Object} ctx - Objeto de contexto del mensaje
   * @param {string[]} ctx.args - Argumentos del comando
   * @param {function(string, string[], boolean=): Promise<void>} ctx.responderTexto - Función para responder texto (citar)
   * @param {function(string, string, string[]): Promise<any>} ctx.enviarImagen - Función para enviar imagen sin citar
   * @param {Object} ctx.config - Objeto de configuración
   * @returns {Promise<void>}
   */
  ejecutar: async (ctx) => {
    // ➡️ CAMBIO CLAVE: Usamos 'responderTexto' y 'enviarImagen'
    const { args, responderTexto, enviarImagen, config, reaccionarMensaje } = ctx;
    const rutaImagenDefecto = path.join(__dirname, '../../media/imagenes/defecto.jpg');

    try {
      if (!args[0]) {
        return await responderTexto(
          '┌─────────────────────────┐\n' +
          '│  ⚠️  *USO INCORRECTO* ⚠️  │\n' +
          '└─────────────────────────┘\n\n' +
          `▪️ Formato: ${config.prefijo}tikinfouser usuario123\n` +
          '▪️ Función: Análisis completo de perfil TikTok\n\n' +
          '➤ Proporciona un nombre de usuario válido'
        );
      }

      const username = args[0].replace('@', ''); // Limpiar el @ si lo ponen
      const apiUrl = `https://www.tiktok.com/@${username}`;

      // ➡️ Notificando que está en búsqueda
      await reaccionarMensaje('🔎');

      const response = await fetch(apiUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html',
          'Accept-Language': 'en-US,en;q=0.9',
        },
      });

      if (response.status === 404) {
          throw new Error('Perfil no encontrado');
      }
      if (!response.ok) {
          throw new Error('Error al conectar con TikTok');
      }

      const html = await response.text();

      // Función mejorada para obtener coincidencias
      const getMatch = (regex) => {
        const match = html.match(regex);
        // Si el match existe, devolvemos el primer grupo de captura
        return match && match[1] ? match[1] : null;
      };

      // Extracción de datos con un manejo de errores más robusto
      const followers = parseInt(getMatch(/"followerCount":(\d+)/)) || 0;
      const following = parseInt(getMatch(/"followingCount":(\d+)/)) || 0;
      const likes = parseInt(getMatch(/"heartCount":(\d+)/)) || 0;
      const videos = parseInt(getMatch(/"videoCount":(\d+)/)) || 0;
      const verified = getMatch(/"verified":(true|false)/) === 'true';
      let avatar = getMatch(/"avatarLarger":"([^"]+)"/)?.replace(/\\u002F/g, '/');
      const nickname = escapeHtml(getMatch(/"nickname":"([^"]+)"/) || username);
      const signature = escapeHtml(getMatch(/"signature":"([^"]+)"/) || 'Sin biografía disponible');
      const comments = parseInt(getMatch(/"commentCount":(\d+)/)) || 0;
      const diggs = parseInt(getMatch(/"diggCount":(\d+)/)) || 0; // Diggs son los Likes de sus videos, debería ser similar a 'likes'
      const shares = parseInt(getMatch(/"shareCount":(\d+)/)) || 0;
      const createTime = getMatch(/"createTime":(\d+)/);
      const lastActive = getMatch(/"lastActiveTime":(\d+)/);
      const bioLink = getMatch(/"bioLink":\{"link":"([^"]+)"/);
      const privateAccount = getMatch(/"privateAccount":(true|false)/) === 'true';

      const createDate = createTime ? new Date(parseInt(createTime) * 1000) : null;
      const lastActiveDate = lastActive ? new Date(parseInt(lastActive) * 1000) : null;
      const daysActive = createDate ? Math.floor((Date.now() - createDate) / 86400000) : 0;
      const hoursSinceLast = lastActiveDate ? Math.floor((Date.now() - lastActiveDate) / 3600000) : 0;

      // Cálculos mejorados
      const totalEngagement = likes + comments + shares;
      const avgLikes = videos > 0 ? Math.round(likes / videos) : 0;
      const avgComments = videos > 0 ? Math.round(comments / videos) : 0;
      const avgShares = videos > 0 ? Math.round(shares / videos) : 0;
      
      // Tasa de Interacción (Total Engagement / Followers)
      const interactionRate = followers > 0
        ? ((totalEngagement / followers) * 100).toFixed(2)
        : '0.00';
        
      // Crecimiento promedio diario de seguidores
      const growthRate = daysActive > 0 ? (followers / daysActive).toFixed(2) : '0.00';
      
      const msg = 
`╔══════════════════════════════╗
║         🎭 *TIKTOK STATS* 🎭         ║
╚══════════════════════════════╝

┏━━━━━━━ *PERFIL* ━━━━━━━┓
┃ Usuario: *@${escapeHtml(username)}*
┃ Nombre: ${nickname}
┃ Estado: ${verified ? '✅ Verificado' : '❌ No verificado'}
┃ Privacidad: ${privateAccount ? '🔒 Privada' : '🌐 Pública'}
┃ Creación: ${createDate ? createDate.toLocaleDateString('es-ES') : 'N/A'}
┃ Antigüedad: ${daysActive} días
┃ Última vez: ${hoursSinceLast > 24 ? `${Math.floor(hoursSinceLast / 24)} días` : `${hoursSinceLast} horas`}
┗━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━━ *AUDIENCIA* ━━━━━━━┓
┃ 👥 Seguidores: *${followers.toLocaleString()}*
┃ 👤 Siguiendo: ${following.toLocaleString()}
┃ 📊 Ratio F/S: ${(followers / (following || 1)).toFixed(2)}
┃ 📈 Crecimiento/día: *${growthRate}*
┗━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━━ *CONTENIDO* ━━━━━━━┓
┃ 🎬 Videos totales: ${videos.toLocaleString()}
┃ ❤️ Likes totales: ${likes.toLocaleString()}
┃ 💬 Comentarios: ${comments.toLocaleString()}
┃ 📤 Compartidos: ${shares.toLocaleString()}
┗━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━━ *MÉTRICAS* ━━━━━━━┓
┃ ⚡ Promedio likes/video: ${avgLikes.toLocaleString()}
┃ 💭 Promedio comentarios/video: ${avgComments.toLocaleString()}
┃ 🎯 Tasa de Interacción: *${interactionRate}%*
┗━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━━ *BIOGRAFÍA* ━━━━━━━┓
┃ ${signature}
${bioLink ? `┃ 🔗 Link: ${bioLink}` : ''}
┃ 🌐 Perfil: tiktok.com/@${username}
┗━━━━━━━━━━━━━━━━━━━━━━━┛

═══════════════════════════════
        ⚡ *Powered by ${config.NombreBot}* ⚡
═══════════════════════════════`;
      
      // ➡️ Cambio: Usar enviarImagen
      if (avatar) {
        // Enviar la imagen del avatar con el mensaje como caption
        await enviarImagen(avatar, msg);
      } else if (fs.existsSync(rutaImagenDefecto)) {
        // Si no hay avatar de TikTok, usar la imagen por defecto
        await enviarImagen(rutaImagenDefecto, msg);
      } else {
        // Si no hay imagen, enviar solo el texto citando
        await responderTexto(msg);
      }

    } catch (error) {
      console.error('Error en comando tik:', error);
      
      // ➡️ Cambio: Usar responderTexto para el mensaje de error
      const errorMessage = error.message.includes('Perfil no encontrado')
          ? `❌ No se pudo encontrar el perfil de *@${args[0].replace('@', '')}*.\nVerifica que el nombre de usuario sea correcto.`
          : '❌ Ocurrió un error al obtener la información de TikTok. Inténtalo de nuevo más tarde.';
          
      await responderTexto(
        '┌─────────────────────────┐\n│     ❌ *ERROR FATAL* ❌     │\n└─────────────────────────┘\n\n▪️ ' + errorMessage
      );
    }
  }
};
