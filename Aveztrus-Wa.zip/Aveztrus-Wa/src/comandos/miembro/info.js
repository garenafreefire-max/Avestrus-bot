const config = require('../../../config.json');

module.exports = {
    nombre: 'info',
    descripcion: 'Muestra información del bot',
    comando: ['info', 'botinfo'],
    ejecutar: async (ctx) => {
        const info = `
🤖 *${config.NombreBot}*
▢ Versión: ${config.version}
▢ Prefijo: ${config.prefijo}
▢ Desarrollador: ${config.Dueño.map(n => n.replace('@s.whatsapp.net', '')).join(', ')}
        `.trim();
        
        await ctx.responderTexto(info);
    }
};