const yts = require('yt-search');

module.exports = {
    nombre: 'ytsearch',
    descripcion: 'Busca videos en YouTube y devuelve hasta 6 enlaces',
    comando: ['ytsearch', 'yts'],
    
    /**
     * @param {Object} ctx - Objeto de contexto del mensaje
     * @param {string[]} ctx.args - Argumentos del comando
     * @param {function(string, string[], boolean=): Promise<void>} ctx.responderTexto - Función para responder texto
     * @param {Object} ctx.config - Objeto de configuración (contiene prefijo)
     * @returns {Promise<void>}
     */
    ejecutar: async (ctx) => {
        // ➡️ CAMBIO CLAVE: Usamos 'responderTexto' en lugar de 'ResponderTextoFalso'
        const { args, responderTexto, config, reaccionarMensaje } = ctx;

        try {
            if (!args || args.length === 0) {
                // ➡️ USANDO responderTexto
                await responderTexto(`❌ Debes proporcionar un término de búsqueda.\n\nEjemplo: ${config.prefijo}yts un chico bailando`);
                return;
            }

            const searchTerm = args.join(' ');
            
            // Mostrar mensaje de búsqueda
            // ➡️ USANDO responderTexto
            await reaccionarMensaje('🔍');

            // Buscar en YouTube usando yt-search
            const searchResults = await yts(searchTerm);

            if (!searchResults.videos || searchResults.videos.length === 0) {
                // ➡️ USANDO responderTexto
                await responderTexto('❌ No se encontraron videos para tu búsqueda.');
                return;
            }

            let response = `🎥 *Resultados de YouTube para:* "${searchTerm}"\n\n`;
            
            // Mostrar hasta 6 videos
            const videos = searchResults.videos.slice(0, 6);
            
            videos.forEach((video, index) => {
                const number = index + 1;
                // Usamos un límite de 60 caracteres y un trim final para evitar líneas vacías
                const title = video.title.length > 60 ? video.title.substring(0, 60).trim() + '...' : video.title.trim();
                const duration = video.duration.timestamp || 'N/A';
                const views = video.views.toLocaleString() || 'N/A';
                const author = video.author.name || 'Desconocido';
                
                response += `${number}. *${title}*\n`;
                response += `   👤 ${author}\n`;
                response += `   ⏱️ ${duration} | 👀 ${views} vistas\n`;
                response += `   🔗 ${video.url}\n\n`;
            });

            response += '📱 Toca el enlace para ver el video';

            // ➡️ USANDO responderTexto
            await responderTexto(response);

        } catch (error) {
            console.error('Error en comando ytsearch:', error);
            
            let errorMessage = '❌ Error al buscar videos.';
            
            if (error.message.includes('timeout') || error.code === 'ETIMEDOUT') {
                errorMessage = '⏱️ Tiempo de espera agotado. Intenta con otra búsqueda.';
            } else if (error.message.includes('ENOTFOUND') || error.message.includes('network')) {
                errorMessage = '🌐 Error de conexión. Verifica tu internet.';
            } else if (error.message.includes('No results')) {
                errorMessage = '❌ No se encontraron resultados para tu búsqueda.';
            }
            
            // ➡️ USANDO responderTexto
            await responderTexto(errorMessage);
        }
    }
};
