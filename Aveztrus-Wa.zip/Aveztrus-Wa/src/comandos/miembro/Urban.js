const axios = require('axios');

module.exports = {
  nombre: 'urban',
  descripcion: 'Busca una definición en Urban Dictionary.',
  comando: ['urban', 'urbandictionary'],
  ejecutar: async (ctx) => {
    const { args, ResponderTextoFalso, config } = ctx;

    if (!args || args.length === 0) {
      await ResponderTextoFalso(`❌ Debes proporcionar una palabra o frase para buscar.\n\nEjemplo: ${config.prefijo}urban lol`);
      return;
    }

    const searchTerm = args.join(' ');

    try {
      const url = `http://api.urbandictionary.com/v0/define?term=${encodeURIComponent(searchTerm)}`;
      const response = await axios.get(url);
      const { list } = response.data;

      if (!list || list.length === 0) {
        await ResponderTextoFalso(`❌ No se encontró ninguna definición para "${searchTerm}".`);
        return;
      }

      const topDefinition = list[0];
      const { word, definition, example } = topDefinition;

      let message = `📚 *Urban Dictionary - ${word}*\n\n`;
      message += `*Definición:*\n${definition}\n\n`;
      message += `*Ejemplo:*\n${example}`;

      await ResponderTextoFalso(message);

    } catch (error) {
      console.error('Error al buscar en Urban Dictionary:', error);
      await ResponderTextoFalso('❌ Hubo un error al buscar en el diccionario.');
    }
  }
};

