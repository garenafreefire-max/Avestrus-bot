const path = require('path');

module.exports = {
    nombre: 'medir',
    descripcion: 'Mide un porcentaje aleatorio de lo que es un usuario, hasta un 200%.',
    comando: ['medir'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, reaccionarMensaje, args, menciones, config } = ctx;

        // Obtener el nombre del usuario y el texto
        let nombreUsuario;
        let textoArgumento;
        let mencionesParaRespuesta = [];

        // Si se menciona a un usuario, lo obtenemos de las menciones
        if (menciones && menciones.length > 0) {
            nombreUsuario = `@${menciones[0].split('@')[0]}`;
            mencionesParaRespuesta = [menciones[0]];
            // Removemos la mención de los argumentos para que el texto sea el resto
            const textoRestante = args.filter(arg => !arg.includes('@'));
            textoArgumento = textoRestante.join(' ') || 'genial';
        } else {
            // Si no hay menciones, el primer argumento es el nombre
            if (args.length === 0) {
                await ResponderTextoFalso(`❌ Debes especificar un usuario (mención o nombre) y un texto.\n\nEjemplo: *${config.prefijo}medir @usuario [texto]* o *${config.prefijo}medir Nombre [texto]*`);
                await reaccionarMensaje('❌');
                return;
            }
            nombreUsuario = args.shift();
            textoArgumento = args.join(' ') || 'genial';
        }

        // Generar un número aleatorio entre 1 y 200 (máximo 200%)
        const numeroAleatorio = Math.floor(Math.random() * 200) + 1;

        // Construir la respuesta con formato
        const mensajeRespuesta = `
🌟 ¡El análisis ha sido completado! 🌟

${nombreUsuario} es *${textoArgumento}* un *${numeroAleatorio}%*.

🚀 ¡Increíble! 🚀
        `.trim();

        // Enviar el mensaje con la mención (si existe)
        await ResponderTextoFalso(mensajeRespuesta, mencionesParaRespuesta);

        // Reaccionar al mensaje con un emoji
        await reaccionarMensaje('💯');
    }
};
