const OpenAI = require("openai");

/*
PROMPT PERSONALIZADO PARA EL MODELO:
Eres un asistente divertido y útil llamado ${ctx.config.nombrebot}. 
Responde de manera concisa y amigable, usando emojis cuando sea apropiado. 
Si no sabes algo, admítelo con humor. 
¡Evita respuestas demasiado largas!
*/

module.exports = {
    comando: ['gpt'],
    descripcion: 'Interactúa con OpenRouter para obtener respuestas a tus preguntas.',
    async ejecutar(ctx) {
        const { m, args, ResponderTextoFalso, config } = ctx;

        if (args.length === 0) {
            return ResponderTextoFalso('❌ Por favor, haz una pregunta. Ejemplo: .gpt cómo estás');
        }

        const pregunta = args.join(' ');

        // API Key real de OpenRouter
        const apiKey = `${config.GPT_API_KEY}`;
        const model = `${config.GPT_MODEL}`;

        const openai = new OpenAI({
            apiKey: apiKey,
            baseURL: `${config.GPT_API_URL}`
        });

        try {
            // Crear el prompt personalizado con instrucciones
            const systemPrompt = `eres una IA divertida con humor y diversión diviertes alos usuarios y le das unos insultos bien fuertes pero es humor porque alos usuarios le divierten y estas en la app de WhatsApp si alguien que insulta lo que harás es papearlo y trolearlo y humillarlo`.trim();

            const completion = await openai.chat.completions.create({
                model: model,
                messages: [
                    { role: "system", content: systemPrompt },
                    { role: "user", content: pregunta }
                ],
                stream: false
            });

            const respuesta = completion.choices?.[0]?.message?.content || 'No obtuve respuesta 😅';
            await ResponderTextoFalso(respuesta);

        } catch (error) {
            console.error('Error en OpenRouter:', error);

            let mensajeError = '❌ Error temporal, intenta nuevamente';
            if (error.response) {
                if (error.response.status === 401) {
                    mensajeError = '❌ Key API inválida';
                } else if (error.response.status === 429) {
                    mensajeError = '❌ Límite de solicitudes alcanzado';
                }
            } else if (error.request) {
                mensajeError = '❌ Sin conexión a la API';
            }

            await ResponderTextoFalso(mensajeError);
        }
    }
};