module.exports = {
    nombre: 'ids',
    descripcion: 'Obtiene el ID de WhatsApp de un usuario mencionado.',
    comando: ['ids'],
    ejecutar: async (ctx) => {
        const { responderTexto, jid, args, sock, m } = ctx;

        // Verificar si se mencionó a alguien
        const menciones = m.message.extendedTextMessage?.contextInfo?.mentionedJid;
        
        if (!menciones || menciones.length === 0) {
            return responderTexto('❌ Debes mencionar a un usuario para obtener su ID. Ejemplo: ,ids @nombre');
        }

        // Si se mencionó a un usuario, su ID estará en el array 'menciones'
        const idDelUsuario = menciones[0];
        
        // El ID de un usuario de WhatsApp es su número seguido de "@s.whatsapp.net"
        await responderTexto(`El ID de WhatsApp del usuario es: \n\n\`${idDelUsuario}\``);
    }
};
