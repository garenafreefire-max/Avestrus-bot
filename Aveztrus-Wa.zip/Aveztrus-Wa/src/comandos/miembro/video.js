const yts = require('yt-search');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

// Función de retraso para esperar a que el archivo se guarde completamente
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Función para validar URLs de YouTube
function esUrlYoutube(url) {
    const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/(watch\?v=|shorts\/|embed\/|v\/|.+\?v=)?([^&=%\?]{11})/;
    return youtubeRegex.test(url);
}

module.exports = {
    nombre: 'video',
    descripcion: 'Descarga videos de YouTube y Shorts',
    comando: ['video', 'v'],
    ejecutar: async (ctx) => {
        const { args, EnviarRespuestaFalsa, EnviarFotoFalsa, EnviarVideoFalsa, config } = ctx;
        let videoPath = null;
        let thumbnailPath = null;
        let finalFormat = 'mp4';

        try {
            if (!args[0]) {
                return EnviarRespuestaFalsa(`⚠️ *Uso correcto:* \n\n*${config.prefijo}video* <nombre del video o enlace de YouTube>`);
            }

            const query = args.join(' ');
            let video;

            if (query.startsWith('http')) {
                if (!esUrlYoutube(query)) {
                    return EnviarRespuestaFalsa('❌ Solo se permiten enlaces de YouTube.\nEjemplos válidos:\n• https://youtu.be/abcdef\n• https://www.youtube.com/watch?v=abcdef\n• https://www.youtube.com/shorts/abcdef');
                }

                const ytDlpProcessInfo = spawn('yt-dlp', [
                    '--dump-json',
                    '--force-ipv4',
                    '--geo-bypass',
                    '--no-check-certificates',
                    '--no-playlist',
                    query
                ]);

                let rawData = '';
                let errorData = '';

                ytDlpProcessInfo.stdout.on('data', (data) => {
                    rawData += data;
                });

                ytDlpProcessInfo.stderr.on('data', (data) => {
                    errorData += data.toString();
                });

                await new Promise((resolve, reject) => {
                    ytDlpProcessInfo.on('close', (code) => {
                        if (code === 0 && rawData) {
                            try {
                                const videoData = JSON.parse(rawData);
                                video = {
                                    title: videoData.title,
                                    author: { name: videoData.uploader },
                                    timestamp: new Date(videoData.duration * 1000).toISOString().substr(11, 8),
                                    views: videoData.view_count,
                                    url: videoData.webpage_url,
                                    thumbnail: videoData.thumbnail,
                                };
                                resolve();
                            } catch (parseError) {
                                console.error('Error al procesar la información del video:', parseError);
                                reject(new Error('❌ Error al procesar la información del video.'));
                            }
                        } else {
                            console.error('yt-dlp info error:', errorData);
                            reject(new Error('❌ No se pudo obtener la información del video.'));
                        }
                    });
                    ytDlpProcessInfo.on('error', (err) => reject(err));
                });
            } else {
                const searchResults = await yts(query);
                if (!searchResults?.videos?.length) {
                    return EnviarRespuestaFalsa('❌ No se encontró ningún video con ese nombre.');
                }
                video = searchResults.videos[0];
            }

            const caption = `🎥 *${video.title}*\n` +
                `• *Canal:* ${video.author.name}\n` +
                `• *Duración:* ${video.timestamp}\n` +
                `• *Vistas:* ${video.views?.toLocaleString?.() || 'N/A'}\n` +
                `• *Enlace:* ${video.url}\n\n` +
                `▶️ Descargando el video...`;

            const miniaturasDir = path.join(__dirname, '../../media/temp/imagenes');
            if (!fs.existsSync(miniaturasDir)) {
                fs.mkdirSync(miniaturasDir, { recursive: true });
            }

            thumbnailPath = path.join(miniaturasDir, `${Date.now()}_${Math.random().toString(36).substring(2, 7)}.jpg`);

            try {
                const response = await axios.get(video.thumbnail, {
                    responseType: 'arraybuffer'
                });
                fs.writeFileSync(thumbnailPath, response.data);
                await EnviarFotoFalsa(thumbnailPath, caption);
            } catch (thumbnailError) {
                console.error('Error al descargar la miniatura:', thumbnailError);
                await EnviarRespuestaFalsa(caption);
            }

            const videosDir = path.join(__dirname, '../../media/temp/video');
            if (!fs.existsSync(videosDir)) {
                fs.mkdirSync(videosDir, { recursive: true });
            }

            const videoFilename = `${Date.now()}_${Math.random().toString(36).substring(2, 7)}.${finalFormat}`;
            videoPath = path.join(videosDir, videoFilename);

            const ytDlpArgs = [
                '--force-ipv4',
                '--geo-bypass',
                '--no-check-certificates',
                // 🔹 Ahora le decimos a yt-dlp que elija el mejor formato MP4 que ya contenga video y audio
                '-f', `best[ext=${finalFormat}]`,
                '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36',
                '-o', videoPath,
                video.url
            ];

            const ytDlpProcess = spawn('yt-dlp', ytDlpArgs);

            await new Promise((resolve, reject) => {
                ytDlpProcess.on('close', (code) => {
                    if (code !== 0) {
                        return reject(new Error(`Error en yt-dlp (código ${code})`));
                    }
                    resolve();
                });

                ytDlpProcess.on('error', (err) => {
                    return reject(new Error('Error al iniciar el proceso de descarga: ' + err.message));
                });
            });

            console.log(`✅ Descarga completada. Esperando 5 segundos para asegurar la escritura del archivo...`);
            await delay(5000);

            if (fs.existsSync(videoPath)) {
                await EnviarVideoFalsa(videoPath, `${video.title}`);
                console.log(`✅ Video enviado exitosamente.`);
            } else {
                console.error('❌ El archivo de video no se encontró en la ruta esperada.');
                return EnviarRespuestaFalsa('❌ El video no se pudo descargar correctamente. Intenta de nuevo más tarde.');
            }

        } catch (error) {
            console.error('Error en comando video:', error);
            ctx.EnviarRespuestaFalsa('❌ Ocurrió un error inesperado al procesar tu solicitud.');
        } finally {
            if (videoPath && fs.existsSync(videoPath)) {
                fs.unlinkSync(videoPath);
            }
            if (thumbnailPath && fs.existsSync(thumbnailPath)) {
                fs.unlinkSync(thumbnailPath);
            }
        }
    }
};
