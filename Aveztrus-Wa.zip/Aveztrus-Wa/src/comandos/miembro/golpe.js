const path = require('path');
const fs = require('fs').promises;
const { exec } = require('child_process');

module.exports = {
    nombre: 'golpe',
    descripcion: 'Le da un golpe virtual a un usuario mencionado.',
    comando: ['golpe', 'pegar'],
    ejecutar: async (ctx) => {
        const { m, userJid, ResponderTextoFalso, ResponderGifFalso, config, menciones, delay } = ctx;

        // Validar si hay una mención
        if (!menciones || menciones.length === 0) {
            await ResponderTextoFalso(`❌ Debes mencionar a un usuario. Ejemplo: *${config.prefijo}golpe @usuario*`);
            return;
        }

        const victimaJid = menciones[0];

        // Evitar que el usuario se golpee a sí mismo
        if (victimaJid === userJid) {
            await ResponderTextoFalso('🤦‍♂️ No puedes golpearte a ti mismo.');
            return;
        }

        const gifPath = path.join(__dirname, '..', '..', 'media', 'gifs', 'golpe.gif');
        const mp4Path = path.join(__dirname, '..', '..', 'media', 'gifs', 'golpe_animado.mp4');

        try {
            if (!await fs.access(mp4Path).then(() => true).catch(() => false)) {
                await new Promise((resolve, reject) => {
                    const ffmpegCmd = `ffmpeg -i "${gifPath}" -movflags faststart -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" "${mp4Path}"`;
                    exec(ffmpegCmd, (error) => {
                        if (error) {
                            return reject(new Error('Error al convertir el GIF.'));
                        }
                        resolve();
                    });
                });
                await delay(`${config.messageDelayMs}`); 
            }

            const victimaNumero = victimaJid.split('@')[0];
            
            const mensaje = `\n╭━━━〔 🥊 *Golpe de Gracia* 〕━━━╮
┃
┃💥 ¡Le has dado un furioso golpe
┃ a *@${victimaNumero}*!
┃
╰━━━━━━━━━━━━━━━━━━╯
`;
            
            // Solo mencionar a la víctima, no al atacante
            const mencionesFinales = [victimaJid];

            if (await fs.access(mp4Path).then(() => true).catch(() => false)) {
                await ResponderGifFalso(mp4Path, mensaje, mencionesFinales);
            } else {
                await ResponderTextoFalso('❌ No se encontró el archivo de animación. Intenta de nuevo.');
            }

        } catch (error) {
            console.error('Error en el comando golpe:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al intentar enviar el golpe. Asegúrate de que el archivo GIF exists en la ruta especificada.');
        }
    }
};