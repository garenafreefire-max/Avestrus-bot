const axios = require('axios');

module.exports = {
    nombre: 'wikipedia',
    descripcion: 'Busca información en Wikipedia y devuelve un resumen',
    comando: ['wiki', 'wikipedia'],
    ejecutar: async (ctx) => {
        // Desestructuración de las propiedades del contexto.
        const { args, responderTexto, EnviarFotoFalsa, config, reaccionarMensaje } = ctx;

        try {
            // Validación inicial: verificar si se proporcionó un término de búsqueda.
            if (!args || args.length === 0) {
                await responderTexto(`❌ Debes proporcionar un término de búsqueda.\n\nEjemplo: ${config.prefijo}wiki Albert Einstein`);
                return;
            }

            const searchTerm = args.join(' ');
            
            await reaccionarMensaje('🔍'); // Inicia la reacción y simulación de escritura

            // Se utiliza una función auxiliar para encapsular la lógica de búsqueda.
            const result = await buscarEnWikipedia(searchTerm);

            if (result) {
                // 🚨 CAMBIO: Se pasa responderTexto a la función auxiliar
                await enviarResultadoWiki(result, responderTexto); 
            } else {
                await responderTexto(`❌ No se encontró información para "${searchTerm}".\n\nIntenta con otros términos o en español.`);
            }

        } catch (error) {
            console.error('Error en comando wikipedia:', error);
            
            let errorMessage = '❌ Error al buscar en Wikipedia.';
            
            if (axios.isAxiosError(error)) {
                if (error.response && error.response.status === 404) {
                    errorMessage = `❌ No se encontró "${args.join(' ')}" en Wikipedia.\n\nIntenta con otros términos de búsqueda.`;
                } else if (error.response && error.response.status === 403) {
                    errorMessage = `❌ La búsqueda para "${args.join(' ')}" fue rechazada por Wikipedia. Intenta con un término más apropiado.`;
                } else if (error.code === 'ETIMEDOUT' || error.message.includes('timeout')) {
                    errorMessage = '⏱️ Tiempo de espera agotado. Intenta nuevamente.';
                } else if (error.code === 'ENOTFOUND') {
                    errorMessage = '🌐 Error de conexión. Verifica tu internet.';
                } else {
                    errorMessage = `❌ Error de red o en la API de Wikipedia: ${error.message}`;
                }
            }
            
            await responderTexto(errorMessage);
        }
    }
};

// --- Funciones auxiliares para mejorar la modularidad y reusabilidad ---

/**
 * Busca un término en la API de Wikipedia y maneja la lógica de desambiguación.
 * @param {string} searchTerm El término a buscar.
 * @returns {Promise<object|null>} Los datos del resumen de la página o null si no se encuentra.
 */
async function buscarEnWikipedia(searchTerm) {
    const searchUrl = `https://es.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(searchTerm)}`;
    const headers = { 'User-Agent': 'WhatsApp-Bot/1.0' };

    try {
        // Se mantiene un timeout de 15s para la API de resumen
        const response = await axios.get(searchUrl, { timeout: 15000, headers });
        const data = response.data;

        if (data.type === 'disambiguation' || !data.extract) {
            const altResponse = await axios.get(`https://es.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(searchTerm)}&limit=1&namespace=0&format=json`, { timeout: 10000, headers });

            if (altResponse.data && altResponse.data[1] && altResponse.data[1].length > 0) {
                const altTitle = altResponse.data[1][0];
                const finalResponse = await axios.get(`https://es.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(altTitle)}`, { timeout: 10000, headers });
                return finalResponse.data.extract ? finalResponse.data : null;
            }
        }
        
        return data.extract ? data : null;

    } catch (error) {
        if (error.response && error.response.status === 404) {
            return null; 
        }
        throw error;
    }
}

/**
 * Formatea y envía el resultado de la búsqueda de Wikipedia.
 * 🚨 Actualizado para usar el nuevo responderTexto.
 * @param {object} data El objeto de datos de la API de Wikipedia.
 * @param {function} responderTexto La función para responder con texto/imagen.
 */
async function enviarResultadoWiki(data, responderTexto) {
    const title = data.title || 'Sin título';
    let extract = data.extract || 'Sin descripción disponible';
    const url = data.content_urls?.desktop?.page || `https://es.wikipedia.org/wiki/${encodeURIComponent(title)}`;
    const imageUrl = data.thumbnail?.source; // URL de la imagen

    if (extract.length > 800) {
        extract = extract.substring(0, 800) + '...';
    }
    
    let message = `📚 *Wikipedia - ${title}*\n\n`;
    message += `${extract}\n\n`;
    
    if (data.coordinates) message += `📍 Coordenadas: ${data.coordinates.lat}, ${data.coordinates.lon}\n`;
    if (data.birth_date) message += `🎂 Nacimiento: ${data.birth_date}\n`;
    if (data.death_date) message += `⚰️ Fallecimiento: ${data.death_date}\n`;
    
    message += `\n🔗 Leer más: ${url}`;
    
    // 🚀 CAMBIO CLAVE: Usa el nuevo formato responderTexto(imagen, caption)
    if (imageUrl) {
        // Si hay URL de imagen, el bot intentará descargarla. Si falla (ETIMEDOUT), 
        // responderTexto automáticamente enviará solo el mensaje de texto.
        await responderTexto(imageUrl, message);
    } else {
        // Si no hay imagen, envía solo el texto.
        await responderTexto(message);
    }
}
