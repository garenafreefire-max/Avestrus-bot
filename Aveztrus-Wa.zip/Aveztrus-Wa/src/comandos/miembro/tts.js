const axios = require('axios');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

module.exports = {
  nombre: 'tts',
  descripcion: 'Convierte texto a audio.',
  comando: ['tts'],
  ejecutar: async (ctx) => {
    const { args, ResponderTextoFalso, sock, jid, config, delay } = ctx;

    if (!args || args.length === 0) {
      await ResponderTextoFalso(`❌ Debes proporcionar un texto para convertir a audio.\n\nEjemplo: ${config.prefijo}tts Hola, soy un bot de WhatsApp.`);
      return;
    }

    const texto = args.join(' ');
    if (texto.length > 200) {
      await ResponderTextoFalso('❌ El texto es demasiado largo. Por favor, usa un texto de 200 caracteres o menos.');
      return;
    }

    try {
      await ResponderTextoFalso('🎙️ Convirtiendo texto a voz... Esto puede tardar un momento.');

      const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(texto)}&tl=es&client=tw-ob`;

      const response = await axios({
        method: 'GET',
        url: url,
        responseType: 'arraybuffer',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Referer': 'https://translate.google.com/',
        }
      });
      
      const audioBuffer = Buffer.from(response.data);

      await delay(config.messageDelayMs);
      
      // Enviar el audio directamente, especificando el MIME type correcto
      await sock.sendMessage(jid, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg' // Tipo de archivo correcto para un MP3
      });
      
    } catch (error) {
      console.error('Error al convertir texto a voz:', error);
      await ResponderTextoFalso('❌ Hubo un error al procesar tu solicitud. Asegúrate de que el texto no sea demasiado largo.');
    }
  },
};