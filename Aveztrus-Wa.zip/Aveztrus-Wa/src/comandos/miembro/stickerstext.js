const path = require('path');
const fs = require('fs');
const fetch = require('node-fetch');
const { execSync } = require('child_process');

module.exports = {
  nombre: 'sticker-text',
  descripcion: 'Crea un sticker con la foto de perfil del usuario y un texto.',
  comando: ['st', 'stickertext'],
  ejecutar: async (ctx) => {
    const { sock, userJid, args, m, responderTexto, EnviarStickerFalso, config } = ctx;

    try {
      // 1. OBTENER EL TEXTO
      let texto = '';
      const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

      if (quoted && (quoted.conversation || quoted.extendedTextMessage?.text)) {
        texto = quoted.conversation || quoted.extendedTextMessage?.text;
      } else if (args.length > 0) {
        texto = args.join(' ');
      } else {
        return responderTexto(`⚠️ *Uso incorrecto:*\n\n ${config.prefijo}st [texto] o cita un mensaje con texto`);
      }

      if (texto.length > 50) {
        texto = texto.substring(0, 50) + '...';
      }

      // 2. OBTENER LA FOTO DE PERFIL
      let pfpBuffer;
      try {
        const pfpUrl = await sock.profilePictureUrl(userJid, 'image');
        const pfpResponse = await fetch(pfpUrl);
        pfpBuffer = await pfpResponse.buffer();
      } catch (error) {
        const defaultImagePath = path.join(__dirname, '../../media/imagenes/defecto.jpg');
        if (fs.existsSync(defaultImagePath)) {
          pfpBuffer = fs.readFileSync(defaultImagePath);
        } else {
          return responderTexto('❌ No se encontró la imagen por defecto.');
        }
      }

      const pfpBase64 = `data:image/png;base64,${pfpBuffer.toString('base64')}`;

      // 3. CREAR DIRECTORIOS TEMPORALES
      const tempDir = path.join(__dirname, '../../media/temp/stickers');
      if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

      const timestamp = Date.now();
      const svgPath = path.join(tempDir, `temp_${timestamp}.svg`);
      const pngPath = path.join(tempDir, `temp_${timestamp}.png`);
      const stickerPath = path.join(tempDir, `sticker_${timestamp}.webp`);

      // 4. GENERAR SVG A PARTIR DE LA PLANTILLA
      const xmlFilePath = path.join(__dirname, '../../media/imagenes/xml/stickertext.xml');
      if (!fs.existsSync(xmlFilePath)) {
        return responderTexto('❌ Archivo de plantilla (codigo.xml) no encontrado.');
      }

      const xmlTemplate = fs.readFileSync(xmlFilePath, 'utf8');
      const svgCode = xmlTemplate
        .replace(/{{USER_PFP}}/g, pfpBase64)
        .replace(/{{TEXT}}/g, texto);

      fs.writeFileSync(svgPath, svgCode);

      // 5. CONVERTIR SVG → PNG con librsvg
      execSync(`rsvg-convert -w 512 -h 512 "${svgPath}" -o "${pngPath}"`);

      // 6. CONVERTIR PNG → WEBP (formato sticker válido) con ffmpeg
      execSync(
        `ffmpeg -y -i "${pngPath}" -vf "scale=512:512:force_original_aspect_ratio=increase,crop=512:512" -vcodec libwebp -lossless 1 -preset picture -an -vsync 0 -metadata:s:v:0 alpha_mode=1 "${stickerPath}"`
      );

      // 7. ENVIAR EL STICKER USANDO TU FUNCIÓN
      await EnviarStickerFalso(m, stickerPath, false);

      // 8. LIMPIAR ARCHIVOS TEMPORALES
      setTimeout(() => {
        try {
          if (fs.existsSync(svgPath)) fs.unlinkSync(svgPath);
          if (fs.existsSync(pngPath)) fs.unlinkSync(pngPath);
          if (fs.existsSync(stickerPath)) fs.unlinkSync(stickerPath);
        } catch (cleanError) {
          console.error('Error limpiando archivos temporales:', cleanError);
        }
      }, 30000);

    } catch (error) {
      console.error('Error en sti.js:', error);
      await responderTexto('❌ Ocurrió un error general al crear el sticker.');
    }
  }
};