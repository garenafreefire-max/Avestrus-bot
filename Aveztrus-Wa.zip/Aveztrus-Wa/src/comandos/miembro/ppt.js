module.exports = {
    nombre: 'ppt',
    descripcion: 'Juega Piedra, Papel o Tijeras contra el bot con respuestas que parecen de canal.',
    comando: ['ppt', 'piedrapapeltijeras', 'piedra', 'papel', 'tijeras'],
    ejecutar: async (ctx) => {
        const { m, ResponderTextoFalso, reaccionarMensaje, args, config } = ctx;
        
        // Detectar si se usó comando directo (ej: .piedra)
        let eleccionUsuario = ctx.nombreComando === 'ppt' ? args[0]?.toLowerCase() : ctx.nombreComando;
        
        // Asignar emojis para el texto y la reacción del bot
        const emojis = {
            piedra: '🪨',
            papel: '📄',
            tijeras: '✂️'
        };

        // Si no se especificó elección, mostrar ayuda
        if (!eleccionUsuario) {
            await ResponderTextoFalso(
                `🎮 *¡Vamos a jugar Piedra, Papel o Tijeras!* 🎮\n\n` +
                `Usa:\n` +
                `• *${config.prefijo}ppt [piedra | papel | tijeras]*\n` +
                `• O usa comandos directos: *${config.prefijo}piedra*, *${config.prefijo}papel*, *${config.prefijo}tijeras*\n\n` +
                `Ejemplo: *${config.prefijo}ppt papel*`
            );
            await reaccionarMensaje('❌');
            return;
        }

        const opciones = ['piedra', 'papel', 'tijeras'];

        // Verificar si la elección es válida
        if (!opciones.includes(eleccionUsuario)) {
            await ResponderTextoFalso(
                `❌ *¡Elección inválida!* ❌\n` +
                `Debes elegir entre:\n` +
                `• 🪨 *Piedra*\n` +
                `• 📄 *Papel*\n` +
                `• ✂️ *Tijeras*\n\n` +
                `Usa *${config.prefijo}ppt* para ver instrucciones.`
            );
            await reaccionarMensaje('❌');
            return;
        }

        // Detectar intentos de trampa
        const esTrampa = eleccionUsuario.includes('trampa') || eleccionUsuario.includes('hack');
        if (esTrampa) {
            await ResponderTextoFalso(
                '🚫 *¡Alto ahí!* 🚫\n\n' +
                'He detectado un intento de trampa...\n' +
                '¿Acaso quieres que el juego sea injusto?\n\n' +
                '¡Juega limpio! 😤'
            );
            await reaccionarMensaje('❌');
            return;
        }

        // Elección del bot (con posibilidad de hacer "trampa" amigable)
        let eleccionBot = opciones[Math.floor(Math.random() * opciones.length)];
        const haceTrampa = Math.random() < 0.2; // 20% de probabilidad de "trampa"

        if (haceTrampa) {
            // Elegir lo que vence al usuario
            if (eleccionUsuario === 'piedra') eleccionBot = 'papel';
            else if (eleccionUsuario === 'papel') eleccionBot = 'tijeras';
            else if (eleccionUsuario === 'tijeras') eleccionBot = 'piedra';
        }

        // Frases divertidas para cada situación
        const frases = {
            ganaUsuario: [
                '¡Increíble! 🎉 ¡Eres imparable!',
                '¡Ganaste! 😱 ¿Eres adivino o qué?',
                '¡Victoria! 🥳 Celebra con estilo.',
                '¡Eres un maestro! 🔥 Sigue así.'
            ],
            ganaBot: [
                '¡Ja! 🤖 La máquina triunfa.',
                '¡Gané! 😎 Mejor suerte la próxima.',
                '¡Victoria robótica! ⚡ Así se hace.',
                '¡Lo siento humano! 😜 Intenta de nuevo.'
            ],
            empate: [
                '¡Empate! 🤝 Mentes gemelas.',
                '¡Igualados! 🫱🏻‍🫲🏼 Nadie gana... por ahora.',
                '¡Sincronizados! ✨ Elegimos lo mismo.',
                '¡Espejos! 👯‍♂️ Mismo pensamiento.'
            ]
        };

        // Determinar el resultado
        let resultado = '';
        let mensajeFinal = '';
        let fraseAleatoria = '';

        if (eleccionUsuario === eleccionBot) {
            resultado = 'EMPATE';
            fraseAleatoria = frases.empate[Math.floor(Math.random() * frases.empate.length)];
            mensajeFinal = `⭐️ ${fraseAleatoria}`;
        } else if (
            (eleccionUsuario === 'piedra' && eleccionBot === 'tijeras') ||
            (eleccionUsuario === 'papel' && eleccionBot === 'piedra') ||
            (eleccionUsuario === 'tijeras' && eleccionBot === 'papel')
        ) {
            resultado = 'GANAS TÚ';
            fraseAleatoria = frases.ganaUsuario[Math.floor(Math.random() * frases.ganaUsuario.length)];
            mensajeFinal = `🏆 ${fraseAleatoria}`;
        } else {
            resultado = 'GANO YO';
            fraseAleatoria = frases.ganaBot[Math.floor(Math.random() * frases.ganaBot.length)];
            mensajeFinal = `🤖 ${fraseAleatoria}`;
            
            // Mensaje adicional si hizo "trampa"
            if (haceTrampa) {
                mensajeFinal += '\n\n😏 *¡Psst!* Esta vez hice un poquito de trampa... ¡Pero no se lo digas a nadie!';
            }
        }

        // Construir respuesta con formato mejorado
        const respuesta = `
🎮 *PIEDRA, PAPEL O TIJERAS* 🎮

👤 *Tú elegiste:* ${emojis[eleccionUsuario]} ${eleccionUsuario.toUpperCase()}
🤖 *Yo elegí:* ${emojis[eleccionBot]} ${eleccionBot.toUpperCase()}

🔥 *RESULTADO:* ${resultado}

${mensajeFinal}
        `.trim();

        await ResponderTextoFalso(respuesta);
        await reaccionarMensaje(emojis[eleccionBot]);
    }
};
