const path = require('path');
const fs = require('fs');

module.exports = {
    nombre: 'meme',
    descripcion: 'Envía memes aleatorios para alegrar el día',
    comando: ['meme', 'momo', 'gracioso'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, EnviarFotoFalsa } = ctx;

        try {
            const memePath = path.join(__dirname, '..', '..', 'media', 'imagenes', 'memes');
            
            // Verificar si la carpeta existe
            if (!fs.existsSync(memePath)) {
                await ResponderTextoFalso('❌ La carpeta de memes no existe. Contacta al desarrollador.');
                return;
            }

            // Obtener todos los archivos de imagen de la carpeta
            const archivos = fs.readdirSync(memePath).filter(archivo => {
                const extension = path.extname(archivo).toLowerCase();
                return ['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(extension);
            });

            // Verificar si hay memes disponibles
            if (archivos.length === 0) {
                await ResponderTextoFalso('❌ No hay memes disponibles en la carpeta.');
                return;
            }

            // Seleccionar un meme aleatorio
            const memeAleatorio = archivos[Math.floor(Math.random() * archivos.length)];
            const rutaMeme = path.join(memePath, memeAleatorio);

            // Verificar que el meme existe antes de enviarlo
            if (!fs.existsSync(rutaMeme)) {
                await ResponderTextoFalso('❌ Error al acceder al meme seleccionado.');
                return;
            }

            // Mensajes aleatorios para acompañar el meme
            const mensajes = [
                '😂 Aquí tienes tu dosis diaria de risa',
                '🤣 Un meme fresco recién salido del horno',
                '😆 Este meme está dedicado especialmente para ti',
                '🎭 Prepárate para reír con este meme',
                '😹 Un meme de calidad premium ha aparecido',
                '🃏 Tu meme de la suerte está aquí',
                '🎪 El show de memes continúa',
                '🎯 Meme directo al corazón',
                '🔥 Este meme está en tendencia',
                '⚡ Cargando risas... Meme enviado'
            ];

            const mensajeAleatorio = mensajes[Math.floor(Math.random() * mensajes.length)];

            // Enviar el meme con mensaje aleatorio
            await EnviarFotoFalsa(rutaMeme, mensajeAleatorio);

        } catch (error) {
            console.error('Error en comando meme:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al buscar el meme. Intenta nuevamente.');
        }
    }
};