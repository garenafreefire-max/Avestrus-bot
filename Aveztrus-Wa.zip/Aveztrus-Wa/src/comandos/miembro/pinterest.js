const pinterestScraper = require('pinterest-scraper-api');

module.exports = {
    nombre: 'pin',
    descripcion: 'Descarga imágenes de Pinterest por búsqueda.',
    comando: ['pin'],
    ejecutar: async (ctx) => {
        const { EnviarRespuestaFalsa, EnviarFotoFalsa, args, config } = ctx;

        if (args.length === 0) {
            await EnviarRespuestaFalsa(`❌ Uso incorrecto. Sintaxis:\n\n*${config.prefijo}pin <búsqueda>*`);
            return;
        }

        const query = args.join(' ');
        let pinUrl = null;
        let mensaje = '';

        try {
            // Modo: Descargar por búsqueda
            await EnviarRespuestaFalsa(`🔎 Buscando imágenes para "${query}"...`);
            const results = await pinterestScraper.searchPinterest(query);

            if (!results || results.length === 0) {
                await EnviarRespuestaFalsa('❌ No se encontraron resultados para esa búsqueda.');
                return;
            }

            // Elegir una imagen aleatoria de los resultados
            const randomIndex = Math.floor(Math.random() * results.length);
            const pin = results[randomIndex];
            pinUrl = pin.imageUrl;
            mensaje = `✅ Imagen de Pinterest para "${query}" encontrada.`;
            
            // Enviar la imagen usando la URL directamente
            if (pinUrl) {
                await EnviarFotoFalsa(pinUrl, mensaje);
            }

        } catch (error) {
            console.error('Error en el comando pin:', error);
            await EnviarRespuestaFalsa('❌ Ocurrió un error al intentar obtener la imagen de Pinterest. Inténtalo de nuevo más tarde.');
        }
    }
};