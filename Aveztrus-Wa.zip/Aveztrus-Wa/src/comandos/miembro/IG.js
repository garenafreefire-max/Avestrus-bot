const axios = require('axios');
const { InstagramScrapper } = require('instagram-scrapper'); // Usamos la librería instalada

// Inicializa el scrapper. No se requieren credenciales para contenido público.
const scrapper = new InstagramScrapper();

module.exports = {
    nombre: 'igdl',
    descripcion: 'Descarga fotos, videos o reels de Instagram usando una URL (Modo Stream con Librería).',
    comando: ['igdl', 'instagram'],
    ejecutar: async (ctx) => {
        const { responderTexto, m, args } = ctx;

        if (args.length === 0) {
            return responderTexto('❌ Por favor, proporciona un enlace de Instagram (post, reel o carrusel).');
        }

        const url = args[0];

        if (!url.includes('instagram.com')) {
            return responderTexto('❌ El enlace debe ser de Instagram. Por favor, verifica la URL.');
        }

        await responderTexto('⏳ Iniciando descarga con librería dedicada. Por favor, espera...');

        try {
            // 1. Usar la librería para obtener los metadatos del post
            const postData = await scrapper.getPost(url);

            if (!postData || postData.length === 0) {
                 return responderTexto('❌ No se encontró el post o el contenido no es público.');
            }

            // La librería devuelve un array, incluso si es un solo item.
            const mediaItems = Array.isArray(postData) ? postData : [postData];

            for (const item of mediaItems) {
                const downloadUrl = item.download_url || item.url;
                const type = item.type; // 'image' o 'video'
                
                if (!downloadUrl) continue; // Saltar si no hay URL

                const caption = `✅ Descarga de Instagram:\nTipo: ${type.toUpperCase()}`;
                
                // 2. Descargar el contenido usando streams
                const mediaResponse = await axios.get(downloadUrl, {
                    responseType: 'stream', 
                    timeout: 60000 
                });

                const stream = mediaResponse.data;
                const headers = mediaResponse.headers;
                
                const mimeType = headers['content-type'] || (type === 'video' ? 'video/mp4' : 'image/jpeg');

                // 3. Enviar el stream directamente a WhatsApp
                const message = { 
                    caption: caption,
                    mimetype: mimeType 
                };
                
                if (type === 'video') {
                    message.video = stream;
                } else if (type === 'image') {
                    message.image = stream;
                }

                if (message.video || message.image) {
                    await ctx.conn.sendMessage(m.key.remoteJid, message, { quoted: m });
                } else {
                    await responderTexto(`⚠️ Tipo de medio desconocido (${type}).`);
                }
                
                // Pequeña pausa para no saturar si es un carrusel
                await new Promise(resolve => setTimeout(resolve, 500));
            }

        } catch (error) {
            console.error('Error en el comando igdl (scrapper):', error.message);
            if (error.response && error.response.status === 404) {
                await responderTexto('❌ Error 404: No se encontró el contenido o el post fue eliminado/privado.');
            } else {
                await responderTexto(`❌ Ocurrió un error al intentar descargar de Instagram: ${error.message}`);
            }
        }
    }
};