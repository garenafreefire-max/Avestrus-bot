const fs = require('fs').promises;
const path = require('path');

module.exports = {
  nombre: 'menu',
  descripcion: 'Muestra la lista de comandos disponibles con diseño decorado.',
  comando: ['menu', 'help', 'comandos'],

  ejecutar: async (ctx) => {
    const {
      enviarImagen,
      comandosMap,
      permisoUsuario,
      responderTexto,
      config,
      esDueñoBot,
      esDueñoGrupo,
      esAdmin,
    } = ctx;

    // 🔹 Permisos visuales
    const nombresPermisos = {
      miembro: '👤 Miembro',
      admin: '🛡️ Admin',
      dueño_grupo: '👑 Dueño del Grupo',
      dueño_bot: '🤖 Dueño del Bot',
    };

    // 🔹 Categorías legibles
    const nombresCategorias = {
      miembro: 'COMANDOS DE MIEMBRO',
      admin: 'COMANDOS DE ADMINISTRADOR',
      dueño_grupo: 'COMANDOS DE DUEÑO GRUPO',
      dueño_bot: 'COMANDOS DE DUEÑO BOT',
      privado: 'COMANDOS PRIVADOS',
      regComan: 'COMANDOS DE REGISTRO',
    };

    const comandosPorCategoria = {};
    let totalComandos = 0;
    let hayComandosNeedAdmin = false;
    let hayComandosRequireRegistro = false;

    // 📦 Procesar comandos
    for (const [alias, cmd] of comandosMap.entries()) {
      if (cmd.comando && cmd.comando[0] === alias) {
        const categoria = cmd.categoria || 'miembro';
        let tienePermiso = false;

        switch (categoria) {
          case 'dueño_bot':
            tienePermiso = esDueñoBot;
            break;
          case 'dueño_grupo':
            tienePermiso = esDueñoGrupo || esDueñoBot;
            break;
          case 'admin':
            tienePermiso = esAdmin || esDueñoGrupo || esDueñoBot;
            break;
          default:
            tienePermiso = true;
        }

        if (tienePermiso) {
          if (!comandosPorCategoria[categoria]) comandosPorCategoria[categoria] = [];
          if (!comandosPorCategoria[categoria].some((c) => c.nombre === cmd.nombre)) {
            comandosPorCategoria[categoria].push(cmd);
            totalComandos++;
            if (cmd.needAdminBot) hayComandosNeedAdmin = true;
            if (cmd.requiereRegistro) hayComandosRequireRegistro = true;
          }
        }
      }
    }

    // 🌟 Encabezado decorado
    let mensaje = `╭━━━❰  ${config.NombreBot.toUpperCase()} ❱━━━╮\n`;
    mensaje += `╰━━━━━✦━━━━━✦━━━━━╯\n\n`;
    mensaje += `╭━〔 *${config.NombreBot} | MENÚ PRINCIPAL* 〕━╮\n\n`;
    mensaje += `📊 *Comandos Disponibles:* ${totalComandos}\n`;
    mensaje += `👑 *Tu Nivel:* ${nombresPermisos[permisoUsuario] || 'Desconocido'}\n`;
    mensaje += `⚡ *Prefijo:* \`${config.prefijo}\`\n`;
    mensaje += `💻 *Creador:* ${config.NombreCreador}\n`;
    mensaje += `🧩 *Versión:* ${config.version}\n\n`;
    mensaje += `╰━━━━━━━━━━━━━━━━━━━━╯\n\n`;

    // 🧠 Estado de Gemini
    let estadoPrivados = '❌ Desactivado';
    let estadoGrupos = '✅ Activo (mención)';

    if (config.geminiGroup === true) estadoPrivados = '✅ Activado';
    else if (config.geminiGroup === 'apagado') {
      estadoPrivados = '❌ Apagado';
      estadoGrupos = '❌ Apagado';
    }

    mensaje += `╭━━〔 *🧠 IA Gemini* 〕━━╮\n`;
    mensaje += `┃ *Grupos:* ${estadoGrupos}\n`;
    mensaje += `┃ *Privado:* ${estadoPrivados}\n`;
    if (config.GeminiMention?.length > 0)
      mensaje += `┃ *Mención:* ${config.GeminiMention.join(', ')}\n`;
    mensaje += `╰━━━━━━━━━━━━━━━╯\n\n`;

    // 📢 Canal oficial
    mensaje += `╭━━〔 *📢 Canal Oficial* 〕━━╮\n`;
    mensaje += `┃ *Canal:* https://whatsapp.com/channel/0029Vb6o2K57YSd5yDEp7g1E\n`;
    mensaje += `┃ *Grupo:* https://chat.whatsapp.com/E8yeGU2lsLnLe1gkO7hOeM?mode=wwt\n`;
    mensaje += `┃ *Contenido:* Novedades y actualizaciones del bot.\n`;
    mensaje += `╰━━━━━━━━━━━━━━━━╯\n\n`;

    // ⚙️ Categorías
    const categoriasOrdenadas = ['miembro', 'regComan', 'admin', 'dueño_grupo', 'dueño_bot', 'privado'];

    for (const categoria of categoriasOrdenadas) {
      const comandos = comandosPorCategoria[categoria];
      if (comandos?.length > 0) {
        const nombreCategoria = nombresCategorias[categoria] || categoria;
        mensaje += `╭━━━〔 *${nombreCategoria}* 〕━━━╮\n`;

        comandos.sort((a, b) =>
          (a.comando[0] || '').localeCompare(b.comando[0] || '')
        );

        comandos.forEach((cmd, i) => {
          const aliases = cmd.comando.map((c) => `\`${config.prefijo}${c}\``).join(', ');
          const descripcion = cmd.descripcion || 'Sin descripción';
          const requiereRegistro = cmd.requiereRegistro ? ' 📝' : '';
          const needAdminBot = cmd.needAdminBot ? ' ⚠️' : '';
          mensaje += `┃ *Comando:* ${aliases}${requiereRegistro}${needAdminBot}\n`;
          mensaje += `┃ *Descripción:* ${descripcion}\n`;
          if (i < comandos.length - 1) mensaje += `┃ ──────────────\n`;
        });

        mensaje += `╰━〔 ⚙️ Total: ${comandos.length} 〕━╯\n\n`;
      }
    }

    // 📌 Notas finales
    if (hayComandosNeedAdmin || hayComandosRequireRegistro) {
      mensaje += `╭━〔 *ℹ️ Notas Importantes* 〕━╮\n`;
      if (hayComandosNeedAdmin)
        mensaje += `┃ ⚠️ *Admin Bot:* Algunos comandos requieren que el bot sea administrador.\n`;
      if (hayComandosRequireRegistro)
        mensaje += `┃ 📝 *Registro:* Algunos comandos requieren registrarte (${config.prefijo}reg).\n`;
      mensaje += `╰━━━━━━━━━━━━━━━━━╯\n`;
    }

    // 🖼️ Imagen de menú
    const rutaImagen = path.join(__dirname, '..', '..', 'media', 'menu.jpg');
    try {
      await enviarImagen(rutaImagen, mensaje);
    } catch (error) {
      console.error('Error al enviar el menú con imagen:', error);
      try {
        await responderTexto(mensaje);
      } catch (err2) {
        console.error('Error al enviar el menú como texto:', err2);
      }
    }
  },
};