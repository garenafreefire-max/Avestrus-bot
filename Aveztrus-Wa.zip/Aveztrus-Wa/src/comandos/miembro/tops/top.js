module.exports = {
    nombre: 'top',
    descripcion: 'Menciona a 10 usuarios del grupo con estilo',
    comando: ['top'],
    ejecutar: async (ctx) => {
        // 1. Desestructuramos responderTexto en lugar de ResponderTextoFalso y quitamos 'm'
        const { responderTexto, sock, jid, args } = ctx;
        
        try {
            // Unir argumentos para el título, o usar el predeterminado
            const titulo = args.join(' ') || 'usuarios destacados';
            const metadata = await sock.groupMetadata(jid);
            const participantes = metadata.participants.map(p => p.id);

            // Validar número de participantes
            if (participantes.length < 10) {
                // ⬅️ Usamos responderTexto sin 'm'
                return responderTexto(`⚠️ Necesito al menos 10 usuarios para hacer un top (${participantes.length}/10)`);
            }

            const seleccionados = [];
            const copiaParticipantes = [...participantes];
            
            // Seleccionar 10 usuarios al azar
            for (let i = 0; i < 10; i++) {
                const randomIndex = Math.floor(Math.random() * copiaParticipantes.length);
                seleccionados.push(copiaParticipantes.splice(randomIndex, 1)[0]);
            }

            const menciones = [];
            const numeros = [];
            
            // Preparar menciones y nombres de usuario
            for (const user of seleccionados) {
                // Obtener JID para la mención
                menciones.push(user);
                
                // Obtener número sin @ para el cuerpo del mensaje
                numeros.push(user.split('@')[0]);
                
                // Nota: El bloque try/catch para obtener el pushName fue simplificado,
                // ya que solo necesitas el JID para la mención final.
            }

            let mensaje = `🏆 *Top 10 ${titulo}*\n\n`;
            
            // Construir el mensaje con emojis y menciones
            seleccionados.forEach((user, index) => {
                let emoji = '🎖️';
                if (index === 0) emoji = '🥇';
                else if (index === 1) emoji = '🥈';
                else if (index === 2) emoji = '🥉';
                
                // Línea del top
                mensaje += `${index + 1}${emoji} @${numeros[index]}\n`; // Se usa @ para forzar la mención
            });

            mensaje += `\n🎉 ¡Felicidades a l@s mejores del grupo 💥🎉!`;
            
            // 2. Envío final: Usamos responderTexto(mensaje, menciones)
            await responderTexto(mensaje, menciones);
            
        } catch (error) {
            console.error('Error en comando top:', error);
            // ⬅️ Usamos responderTexto para el manejo de errores
            await responderTexto('❌ Ocurrió un error al crear el top');
        }
    }
};
