const path = require('path');
const fs = require('fs');

module.exports = {
    nombre: 'topgays',
    descripcion: 'menciona a 10 inteligentes del grupo',
    comando: ['topinteligente', 'topiq'],
    needAdminBot: true, 
    ejecutar: async (ctx) => {
        // Desestructuramos solo las funciones y variables necesarias del contexto (ctx)
        const { 
            jid, 
            sock, 
            responderTexto, // Función que maneja el 'm' internamente
            ResponderTextoFalso, // Usaremos este como fallback si es necesario
            enviarImagen, 
            cargarArchivoLocal, 
            config 
        } = ctx; 

        // 1. Ruta de la imagen ajustada: desde '.../comandos/miembro/tops/' hasta '.../media/imagenes/'
        const RUTA_IMAGEN = path.join(__dirname, '..', '..', '..', 'media', 'imagenes', 'topinteligente.jpg');

        try {
            // Solo funciona en grupos
            if (!jid.endsWith('@g.us')) {
                // Usamos ResponderTextoFalso para mantener el estilo de "mensaje falso/citado"
                return ResponderTextoFalso('⚠️ Este comando solo puede usarse en un grupo.');
            }
            
            // 2. Cargamos el buffer de la imagen
            const imageBuffer = cargarArchivoLocal(RUTA_IMAGEN);
            if (!imageBuffer) {
                // Si la imagen no existe, detenemos la ejecución y notificamos.
                return ResponderTextoFalso(`❌ Error: No se encontró la imagen en: ${RUTA_IMAGEN}.\nAsegúrate de que la ruta '${RUTA_IMAGEN}' sea correcta.`);
            }

            const metadata = await sock.groupMetadata(jid);
            const participantes = metadata.participants;

            // JID del bot (usamos la información del socket si está disponible)
            const botJid = sock.user?.id || `${config.Botnumero}@s.whatsapp.net`;
            
            const usuariosActivos = participantes
                .filter(p => p.id !== botJid) 
                .map(p => p.id);

            // Valida que haya al menos 10 usuarios para el top
            if (usuariosActivos.length < 10) {
                return enviarImagen(imageBuffer, 
                    `⚠️ Necesito al menos *10 usuarios* en el grupo para crear el top. (Actualmente: ${usuariosActivos.length})`
                );
            }

            const topData = [];
            const copiaParticipantes = [...usuariosActivos];
            
            // Seleccionar 10 usuarios al azar sin repetir
            for (let i = 0; i < 10 && copiaParticipantes.length > 0; i++) {
                const randomIndex = Math.floor(Math.random() * copiaParticipantes.length);
                const userJid = copiaParticipantes.splice(randomIndex, 1)[0]; 
                const porcentaje = Math.floor(Math.random() * 100) + 1; 
                
                topData.push({
                    jid: userJid,
                    porcentaje: porcentaje
                });
            }

            // Ordenar de mayor a menor porcentaje
            topData.sort((a, b) => b.porcentaje - a.porcentaje);
            
            let caption = '🏆 *top 10 cabezones del grupo*\n\n';
            const menciones = [];
            
            // Construcción del mensaje
            topData.forEach((item, index) => {
                let emoji = '🎖️';
                if (index === 0) emoji = '🧠';
                else if (index === 1) emoji = '🤓';
                else if (index === 2) emoji = '🗿';
                
                // Formato con mención (@número)
                caption += `${index + 1}${emoji} @${item.jid.split('@')[0]} - ${item.porcentaje}%\n`;
                
                menciones.push(item.jid); // JID completo para la función de mención
            });

            caption += `\n🎉 *¡que inteligente!* 💥\n`;

            // 3. Envío final: Usamos enviarImagen con el Buffer, el caption y las menciones.
            await enviarImagen(imageBuffer, caption, menciones);
            
        } catch (error) {
            console.error('Error en comando topgays:', error);
            // Usamos ResponderTextoFalso para citar el error
            await ResponderTextoFalso('❌ Ocurrió un error al crear el top de gays.');
        }
    }
};
