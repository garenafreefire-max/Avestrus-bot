module.exports = {
    nombre: 'abrazar',
    descripcion: 'Abraza a otro usuario del grupo.',
    comando: ['abrazar', 'hug'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, menciones, userJid } = ctx;
        
        if (menciones.length === 0) {
            return ResponderTextoFalso(`❌ Debes mencionar a alguien para abrazarlo. Ejemplo: *${ctx.config.prefijo}abrazar @usuario*`);
        }

        const usuarioAbrazado = menciones[0];
        const abrazos = [
            "🤗 ¡Un abrazo cálido!",
            "🫂 ¡Abrazo de oso!",
            "💕 ¡Abrazo lleno de cariño!",
            "✨ ¡Abrazo mágico!",
            "🌻 ¡Abrazo que alegra el día!"
        ];

        const abrazoAleatorio = abrazos[Math.floor(Math.random() * abrazos.length)];
        
        await ResponderTextoFalso(`${abrazoAleatorio} @${userJid.split('@')[0]} abrazó a @${usuarioAbrazado.split('@')[0]}`, [usuarioAbrazado]);
    }
};