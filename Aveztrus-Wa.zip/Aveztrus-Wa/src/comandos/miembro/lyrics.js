const Genius = require("genius-lyrics");

module.exports = {
  nombre: "song",
  descripcion: "Busca y muestra la letra de una canción en Genius.",
  comando: ["song", "lyrics", "ly",],
  ejecutar: async (ctx) => {
    const { args, ResponderTextoFalso, config } = ctx;

    const GENIUS_ACCESS_TOKEN = config.GENIUS_ACCESS_TOKEN;
    if (!GENIUS_ACCESS_TOKEN) {
      await ResponderTextoFalso(
        "❌ No has configurado el token de Genius. Agrégalo en tu archivo de configuración."
      );
      return;
    }

    const query = args.join(" ");
    if (!query.includes("|")) {
      await ResponderTextoFalso(
        `❌ Debes proporcionar el título y el artista separados por "|".\n\nEjemplo:\n${config.prefijo}song Wake Me Up Before You Go-Go | Wham!`
      );
      return;
    }

    const [title, artist] = query.split("|").map((x) => x.trim());

    try {
      await ResponderTextoFalso(`🔎 Buscando letra de "${title}" por ${artist}...`);

      const Client = new Genius.Client(GENIUS_ACCESS_TOKEN);
      const results = await Client.songs.search(`${title} ${artist}`);

      if (!results || results.length === 0) {
        await ResponderTextoFalso("❌ No encontré resultados en Genius.");
        return;
      }

      const song = results[0];
      const lyrics = await song.lyrics();

      const mensaje = `
*🎶 Letra de "${song.title}" de ${song.artist.name}*
--------------------
${lyrics.slice(0, 3000)} 
--------------------
🔗 *Enlace:* ${song.url}`;

      await ResponderTextoFalso(mensaje);
    } catch (error) {
      console.error("Error en el comando song:", error);
      await ResponderTextoFalso("❌ Ocurrió un error al buscar la letra.");
    }
  },
};