const yts = require('yt-search');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

module.exports = {
  nombre: 'play',
  descripcion: 'descarga una música de Youtube poniendo el enlace o nombre',
  comando: ['play', 'ytmp3'],
  ejecutar: async (ctx) => {
    try {
      const { m, args, enviarAudio, EnviarRespuestaFalsa, EnviarFotoFalsa, config } = ctx;

      if (!args[0]) {
        return EnviarRespuestaFalsa(`⚠️ *Uso correcto:* \n\n*${config.prefijo}play* <nombre de la canción o enlace>`);
      }

      const query = args.join(' ');
      let video;

      if (query.startsWith('http')) {
        // Validar que es YouTube solamente
        if (!query.includes('youtube.com') && !query.includes('youtu.be')) {
          return EnviarRespuestaFalsa('❌ Solo se permiten enlaces de YouTube.');
        }

        // Usar yt-dlp para obtener información del video
        const ytDlpProcessInfo = spawn('yt-dlp', [
          '--dump-json',
          '--force-ipv4',
          '--geo-bypass',
          '--no-check-certificates',
          '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          query
        ]);
        
        let rawData = '';
        let errorData = '';

        ytDlpProcessInfo.stdout.on('data', (data) => {
          rawData += data;
        });

        ytDlpProcessInfo.stderr.on('data', (data) => {
          errorData += data.toString();
        });

        await new Promise((resolve, reject) => {
          ytDlpProcessInfo.on('close', (code) => {
            if (code === 0 && rawData) {
              try {
                const videoData = JSON.parse(rawData);

                // Validar que no sea live
                if (videoData.is_live) {
                  return reject(new Error('❌ No se permiten videos en vivo (lives).'));
                }

                // Validar que la plataforma sea YouTube
                if (!videoData.extractor || !videoData.extractor.toLowerCase().includes('youtube')) {
                  return reject(new Error('❌ Solo se permiten videos de YouTube.'));
                }

                video = {
                  title: videoData.title,
                  author: { name: videoData.uploader },
                  timestamp: new Date(videoData.duration * 1000).toISOString().substr(11, 8),
                  views: videoData.view_count,
                  url: videoData.webpage_url,
                  thumbnail: videoData.thumbnail,
                };
                resolve();
              } catch (parseError) {
                console.error('Error parsing video data:', parseError);
                reject(new Error('❌ Error al procesar la información del video.'));
              }
            } else {
              console.error('yt-dlp info error:', errorData);
              reject(new Error('❌ No se pudo obtener la información del video.'));
            }
          });
          ytDlpProcessInfo.on('error', (err) => reject(err));
        });
        
      } else {
        // Búsqueda por texto
        const searchResults = await yts(query);
        if (!searchResults?.videos?.length) {
          return EnviarRespuestaFalsa('❌ No se encontró ningún video con ese nombre.');
        }
        video = searchResults.videos[0];

        // Validar que no sea live
        if (video.live) {
          return EnviarRespuestaFalsa('❌ No se permiten videos en vivo (lives).');
        }

        // Validar que el enlace sea de YouTube (esto es redundante aquí, pero para seguridad)
        if (!video.url.includes('youtube.com') && !video.url.includes('youtu.be')) {
          return EnviarRespuestaFalsa('❌ Solo se permiten videos de YouTube.');
        }
      }
      
      const caption = `🎵 *${video.title}*\n` +
                      `• *Canal:* ${video.author.name}\n` +
                      `• *Duración:* ${video.timestamp}\n` +
                      `• *Vistas:* ${video.views?.toLocaleString?.() || 'N/A'}\n` +
                      `• *Enlace:* ${video.url}\n\n` +
                      `▶️ Descargando el audio...`;
      
      const miniaturasDir = path.join(__dirname, '../../media/temp/imagenes');
      if (!fs.existsSync(miniaturasDir)) {
        fs.mkdirSync(miniaturasDir, { recursive: true });
      }

      const thumbnailPath = path.join(miniaturasDir, `${Date.now()}_${Math.random().toString(36).substring(2, 7)}.jpg`);
      
      try {
        const response = await axios.get(video.thumbnail, { 
          responseType: 'arraybuffer',
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
          }
        });
        fs.writeFileSync(thumbnailPath, response.data);
        await EnviarFotoFalsa(thumbnailPath, caption);
        fs.unlinkSync(thumbnailPath);
      } catch (thumbnailError) {
        console.error('Error downloading thumbnail:', thumbnailError);
        await EnviarRespuestaFalsa(caption);
      }

      const audioDir = path.join(__dirname, '../../media/temp/audios');
      if (!fs.existsSync(audioDir)) {
          fs.mkdirSync(audioDir, { recursive: true });
      }

      const audioFilename = `${Date.now()}_${Math.random().toString(36).substring(2, 7)}.mp3`;
      const audioPath = path.join(audioDir, audioFilename);

      const ytDlpArgs = [
        '--force-ipv4',
        '--geo-bypass',
        '--no-check-certificates',
        '--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        '-f', 'bestaudio/best',
        '--extract-audio',
        '--audio-format', 'mp3',
        '--audio-quality', '0',
        '--concurrent-fragments', '5',
        '--retries', '10',
        '--fragment-retries', '10',
        '--buffer-size', '16K',
        '--no-cache-dir',
        '-o', audioPath,
        video.url
      ];

      const ytDlpProcess = spawn('yt-dlp', ytDlpArgs);

      let downloadError = null;

      ytDlpProcess.stderr.on('data', (data) => {
        console.error('yt-dlp stderr:', data.toString());
      });

      await new Promise((resolve) => {
        ytDlpProcess.on('close', (code) => {
          if (code !== 0) {
            downloadError = `Error en yt-dlp (código ${code})`;
          }
          resolve();
        });
        
        ytDlpProcess.on('error', (err) => {
          console.error('Error al iniciar yt-dlp:', err);
          downloadError = 'Error al iniciar el proceso de descarga';
          resolve();
        });
      });

      if (downloadError || !fs.existsSync(audioPath)) {
        return EnviarRespuestaFalsa('❌ Error al descargar el audio. Intenta con otro video.');
      }

      await enviarAudio(audioPath);
      fs.unlinkSync(audioPath);

    } catch (error) {
      console.error('Error en comando play:', error);
      ctx.EnviarRespuestaFalsa('❌ Ocurrió un error inesperado al procesar tu solicitud.');
    }
  }
};