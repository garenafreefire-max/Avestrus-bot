const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

module.exports = {
  nombre: 'speed',
  descripcion: 'Convierte el audio en versión rápida con voz más aguda.',
  comando: ['speed'],
  ejecutar: async (ctx) => {
    const { m, sock, responderTexto, config } = ctx;

    try {
      const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!quoted || !quoted.audioMessage) {
        return responderTexto(`❌ Responde a un *audio* con ${config.prefijo}speed`);
      }

      // Descargar audio
      const stream = await downloadContentFromMessage(quoted.audioMessage, 'audio');
      let buffer = Buffer.from([]);
      for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

      const tempDir = path.join(__dirname, '../../media/temp/audios');
      if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

      const timestamp = Date.now();
      const inputPath = path.join(tempDir, `speed_in_${timestamp}.mp3`);
      const outputPath = path.join(tempDir, `speed_out_${timestamp}.mp3`);
      fs.writeFileSync(inputPath, buffer);

      // Verificar duración (máx 5 min)
      const duration = parseFloat(execSync(
        `ffprobe -i "${inputPath}" -show_entries format=duration -v quiet -of csv="p=0"`
      ).toString().trim());
      if (duration > 300) {
        fs.unlinkSync(inputPath);
        return responderTexto('❌ El audio no puede durar más de 5 minutos.');
      }

      // 🔹 Filtro speed + voz más aguda
      execSync(`ffmpeg -y -i "${inputPath}" -filter:a "atempo=1.25,asetrate=44100*1.1,aresample=44100" "${outputPath}"`);

      await sock.sendMessage(m.key.remoteJid, { 
        audio: { url: outputPath }, 
        mimetype: 'audio/mp4', 
        ptt: true 
      }, { quoted: m });

      setTimeout(() => {
        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
      }, 20000);

    } catch (err) {
      console.error('Error en speed.js:', err);
      responderTexto('❌ Ocurrió un error al procesar el audio.');
    }
  }
};