const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

module.exports = {
    nombre: 'ss',
    descripcion: 'Convierte stickers estáticos en imágenes.',
    comando: ['ss'],
    ejecutar: async (ctx) => {
        const { m, EnviarRespuestaFalsa, EnviarFotoFalsa, config } = ctx;
        
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted || !quoted.stickerMessage) {
            return EnviarRespuestaFalsa(`❌ Responde a un sticker con ${config.prefijo}ss para convertirlo.`);
        }

        const stickerMsg = quoted.stickerMessage;
        const isAnimated = stickerMsg.isAnimated;

        // Si el sticker es animado, no hace nada y avisa al usuario
        if (isAnimated) {
            return EnviarRespuestaFalsa('❌ Este comando solo puede convertir stickers estáticos (no animados).');
        }

        try {
            await EnviarRespuestaFalsa('🖼️ Convirtiendo sticker a imagen...');
            
            const tempDir = path.join(__dirname, '../../media/temp/stickers');
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }
            
            const stream = await downloadContentFromMessage(stickerMsg, 'sticker');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            
            const timestamp = Date.now();
            const tempPath = path.join(tempDir, `sticker_${timestamp}.webp`);
            let outputPath = path.join(tempDir, `image_${timestamp}.png`);
            
            fs.writeFileSync(tempPath, buffer);

            let caption;
            let finalOutputBuffer;
            
            try {
                execSync(`ffmpeg -i "${tempPath}" "${outputPath}"`);
                caption = '✅ Sticker convertido a imagen';
                finalOutputBuffer = fs.readFileSync(outputPath);
                await EnviarFotoFalsa(finalOutputBuffer, caption);
            } catch (error) {
                console.error('Error FFmpeg:', error);
                outputPath = tempPath;
                caption = '✅ Sticker convertido (formato original .webp)';
                finalOutputBuffer = fs.readFileSync(outputPath);
                await EnviarFotoFalsa(finalOutputBuffer, caption);
            }

            setTimeout(() => {
                try {
                    if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
                    if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
                } catch (error) {
                    console.error('Error eliminando temporales:', error);
                }
            }, 30000);
            
        } catch (error) {
            console.error('Error en ss.js:', error);
            await EnviarRespuestaFalsa('❌ Error: No se pudo procesar el sticker. Intenta con otro.');
        }
    }
};
