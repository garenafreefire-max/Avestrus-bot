const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'cancelarmarry',
    descripcion: 'Cancela tu solicitud de matrimonio pendiente.',
    comando: ['cancelarmarry', 'rechamatri'],
    requiereRegistro: true,
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', 'database', 'UserReg.json');
        
        try {
            // Leer la base de datos de usuarios
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (error) {
                return ResponderTextoFalso('❌ No se pudo acceder a la base de datos de usuarios.');
            }

            // Buscar al usuario actual
            const usuarioActual = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (!usuarioActual) {
                return ResponderTextoFalso('❌ No estás registrado en el sistema.');
            }

            // Verificar si tiene una solicitud pendiente
            if (!usuarioActual.SolicitudMatrimonio) {
                return ResponderTextoFalso('❌ No tienes ninguna solicitud de matrimonio pendiente.');
            }

            // Buscar a la pareja para notificarle (opcional)
            const parejaJid = usuarioActual.SolicitudMatrimonio;
            const pareja = usuariosRegistrados.find(u => u.Usuario === parejaJid);
            
            // Eliminar la solicitud
            delete usuarioActual.SolicitudMatrimonio;

            // Actualizar la lista de usuarios
            usuariosRegistrados = usuariosRegistrados.map(u => 
                u.Usuario === userJid ? usuarioActual : u
            );

            // Guardar los cambios
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2), 'utf8');

            await ResponderTextoFalso(
                `❌ Has cancelado tu solicitud de matrimonio` +
                (pareja ? ` hacia *${pareja.Nombre}*` : '') + 
                `.`
            );

        } catch (error) {
            console.error('Error en comando cancelarmarry:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al cancelar la solicitud.');
        }
    }
};