const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'divorciarse',
    descripcion: 'Divórciate de tu pareja actual.',
    comando: ['divorciarse', 'divorce', 'separarse'],
    requiereRegistro: true,
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', 'database', 'UserReg.json');
        
        try {
            // Leer la base de datos de usuarios
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (error) {
                return ResponderTextoFalso('❌ No se pudo acceder a la base de datos de usuarios.');
            }

            // Buscar al usuario actual
            const usuarioActual = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (!usuarioActual) {
                return ResponderTextoFalso('❌ No estás registrado en el sistema.');
            }

            // Verificar si está casado
            if (!usuarioActual.Relacion || usuarioActual.Relacion.estado !== 'casado') {
                return ResponderTextoFalso('❌ No estás casado, no puedes divorciarte.');
            }

            const infoRelacion = usuarioActual.Relacion;
            const parejaJid = infoRelacion.pareja;

            // Buscar a la pareja
            const pareja = usuariosRegistrados.find(u => u.Usuario === parejaJid);
            
            // Eliminar la relación de ambos usuarios
            delete usuarioActual.Relacion;
            if (pareja) {
                delete pareja.Relacion;
                
                // Actualizar la pareja en la lista
                usuariosRegistrados = usuariosRegistrados.map(u => 
                    u.Usuario === parejaJid ? pareja : u
                );
            }

            // Actualizar el usuario actual en la lista
            usuariosRegistrados = usuariosRegistrados.map(u => 
                u.Usuario === userJid ? usuarioActual : u
            );

            // Guardar los cambios
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2), 'utf8');

            await ResponderTextoFalso(
                `💔 Te has divorciado de *${infoRelacion.nombrePareja}*.\n` +
                `📅 Relación terminada: *${new Date().toLocaleDateString('es-ES')}*\n\n` +
                `Esperamos que encuentres la felicidad nuevamente. 🌈`
            );

        } catch (error) {
            console.error('Error en comando divorciarse:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al procesar el divorcio.');
        }
    }
};