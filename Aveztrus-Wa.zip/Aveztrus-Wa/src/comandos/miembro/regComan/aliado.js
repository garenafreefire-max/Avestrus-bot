const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'aliado',
    descripcion: 'Forma una alianza con otro usuario registrado.',
    comando: ['aliado', 'ally'],
    requiereRegistro: true,
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, args, userJid, menciones, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', 'database', 'UserReg.json');
        
        if (menciones.length === 0) {
            return ResponderTextoFalso(`❌ Debes mencionar a un usuario para formar alianza. Ejemplo: *${config.prefijo}aliado @usuario*`);
        }

        const aliadoJid = menciones[0];
        
        if (aliadoJid === userJid) {
            return ResponderTextoFalso('❌ No puedes formar alianza contigo mismo.');
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (error) {
                return ResponderTextoFalso('❌ Error al leer la base de datos.');
            }

            const usuarioActual = usuariosRegistrados.find(u => u.Usuario === userJid);
            const usuarioAliado = usuariosRegistrados.find(u => u.Usuario === aliadoJid);

            if (!usuarioActual || !usuarioAliado) {
                return ResponderTextoFalso('❌ Ambos usuarios deben estar registrados.');
            }

            // Crear alianza
            const fecha = new Date().toLocaleDateString('es-ES');
            
            usuarioActual.Aliado = {
                jid: aliadoJid,
                nombre: usuarioAliado.Nombre,
                desde: fecha
            };
            
            usuarioAliado.Aliado = {
                jid: userJid,
                nombre: usuarioActual.Nombre,
                desde: fecha
            };

            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2), 'utf8');

            await ResponderTextoFalso(
                `🤝 ¡Alianza formada! *${usuarioActual.Nombre}* y *${usuarioAliado.Nombre}* son ahora aliados.\n` +
                `📅 Alianza desde: *${fecha}*`
            );

        } catch (error) {
            console.error('Error en comando aliado:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al formar la alianza.');
        }
    }
};