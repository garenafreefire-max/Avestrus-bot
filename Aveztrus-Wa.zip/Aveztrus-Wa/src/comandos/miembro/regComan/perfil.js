const fs = require('fs').promises;
const path = require('path');
const axios = require('axios');

module.exports = {
    nombre: 'perfil',
    descripcion: 'Muestra tu perfil de usuario, incluyendo tu foto, nombre, dinero y relación.',
    comando: ['perfil', 'miperfil', 'profile'],
    ejecutar: async (ctx) => {
        const { m, userJid, sock, ResponderTextoFalso, ResponderFotoFalsa } = ctx;

        try {
            const dbPath = path.join(__dirname, '..', '..', '..', 'database', 'UserReg.json');
            
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                await ResponderTextoFalso('❌ No hay usuarios registrados en la base de datos.');
                return;
            }

            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);

            if (!usuario) {
                await ResponderTextoFalso(`❌ No estás registrado. Usa el comando *${ctx.config.prefijo}reg Nombre | edad | país* para crear un perfil.`);
                return;
            }

            // Obtener la foto de perfil del usuario
            let fotoPerfilBuffer;
            try {
                const fotoPerfilUrl = await sock.profilePictureUrl(userJid, 'image');
                const response = await axios.get(fotoPerfilUrl, { responseType: 'arraybuffer' });
                fotoPerfilBuffer = Buffer.from(response.data);
            } catch (e) {
                // Si hay un error, usa la imagen por defecto.
                fotoPerfilBuffer = path.join(__dirname, '..', '..', 'media', 'fotos', 'defecto.jpg');
            }

            // Mapear los datos del usuario
            const { 
                Nombre, 
                Edad, 
                País, 
                Moneda = 0, 
                Diamante = 0, 
                Banco = 0, 
                regFecha = 'N/A', 
                regHora = 'N/A',
                Relacion = null,
                SolicitudMatrimonio = null
            } = usuario;

            // Calcular días desde el registro
            let diasRegistrado = 0;
            if (regFecha !== 'N/A') {
                try {
                    const fechaRegistro = new Date(regFecha.split('/').reverse().join('/'));
                    const hoy = new Date();
                    const diffTime = Math.abs(hoy - fechaRegistro);
                    diasRegistrado = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                } catch (e) {
                    console.error('Error calculando días de registro:', e);
                }
            }

            // Preparar información de relación
            let infoRelacion = '';
            if (Relacion && Relacion.estado === 'casado') {
                try {
                    const fechaInicio = new Date(Relacion.desde.split('/').reverse().join('/'));
                    const hoy = new Date();
                    const diffTime = Math.abs(hoy - fechaInicio);
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    infoRelacion = `
┃ *💍 Estado:* Casado/a con ${Relacion.nombrePareja}
┃ *📅 Desde:* ${Relacion.desde}
┃ *⏰ Tiempo juntos:* ${diffDays} días
┃`;
                } catch (e) {
                    infoRelacion = `
┃ *💍 Estado:* Casado/a con ${Relacion.nombrePareja}
┃ *📅 Desde:* ${Relacion.desde}
┃`;
                }
            } else if (SolicitudMatrimonio) {
                // Buscar información de la solicitud pendiente
                const parejaSolicitud = usuariosRegistrados.find(u => u.Usuario === SolicitudMatrimonio);
                if (parejaSolicitud) {
                    infoRelacion = `
┃ *💌 Solicitud pendiente:* ${parejaSolicitud.Nombre}
┃`;
                }
            } else {
                infoRelacion = `
┃ *💔 Estado:* Soltero/a
┃`;
            }

            let mensaje = `
╭━━━〔 *👤 Perfil de ${Nombre}* 〕━━━╮
┃
┃ *📛 Nombre:* ${Nombre}
┃ *🎂 Edad:* ${Edad}
┃ *🇺🇳 País:* ${País}
${infoRelacion}
┃ *💰 Monedas:* ${Moneda}
┃ *💎 Diamantes:* ${Diamante}
┃ *🏦 Banco:* ${Banco}
┃ *📅 Registrado:* ${regFecha}
┃ *⏰ Hace:* ${diasRegistrado} días
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`;
            
            await ResponderFotoFalsa(fotoPerfilBuffer, mensaje);

        } catch (error) {
            console.error('❌ Error al ejecutar el comando de perfil:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al cargar tu perfil. Inténtalo de nuevo más tarde.');
        }
    }
};