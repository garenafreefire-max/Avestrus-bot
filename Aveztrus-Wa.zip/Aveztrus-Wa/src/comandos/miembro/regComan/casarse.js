const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'casarse',
    descripcion: 'Envía o acepta una solicitud de matrimonio. Ejemplo: $marry @usuario',
    comando: ['marry', 'casarse', 'matrimonio', 'novios'],
    requiereRegistro: true,
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, args, userJid, menciones, sock, m, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', 'database', 'UserReg.json');
        
        // Verificar si se mencionó a alguien
        if (menciones.length === 0) {
            return ResponderTextoFalso(`💍 Debes mencionar a la persona con quien quieres casarte.\nEjemplo: *${config.prefijo}marry @usuario*`);
        }
        
        const parejaJid = menciones[0];
        
        // No se puede uno casar consigo mismo
        if (parejaJid === userJid) {
            return ResponderTextoFalso('❌ No puedes casarte contigo mismo, eso sería extraño.');
        }

        try {
            // Leer la base de datos de usuarios
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (error) {
                return ResponderTextoFalso('❌ No se pudo acceder a la base de datos de usuarios.');
            }

            // Buscar al usuario actual
            const usuarioActual = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (!usuarioActual) {
                return ResponderTextoFalso('❌ Primero debes registrarte para usar este comando.');
            }

            // Buscar a la pareja
            const pareja = usuariosRegistrados.find(u => u.Usuario === parejaJid);
            if (!pareja) {
                return ResponderTextoFalso('❌ La persona mencionada no está registrada en el sistema.');
            }

            // Verificar si ya está casado el usuario actual
            if (usuarioActual.Relacion && usuarioActual.Relacion.estado === 'casado') {
                return ResponderTextoFalso('❌ Ya estás casado. Debes divorciarte antes de casarte de nuevo.');
            }

            // Verificar si la pareja ya está casada
            if (pareja.Relacion && pareja.Relacion.estado === 'casado') {
                return ResponderTextoFalso(`❌ ${pareja.Nombre} ya está casad@ con alguien más.`);
            }

            // Verificar si ya existe una solicitud del usuario actual hacia la pareja
            if (usuarioActual.SolicitudMatrimonio === parejaJid) {
                return ResponderTextoFalso(`⏳ Ya le has enviado una solicitud de matrimonio a ${pareja.Nombre}. Espera a que la acepte.`);
            }

            // Verificar si la pareja ya tiene una solicitud del usuario actual
            if (pareja.SolicitudMatrimonio === userJid) {
                // ACEPTAR SOLICITUD - Ambos se casan
                const fecha = new Date().toLocaleDateString('es-ES');
                
                // Actualizar usuario actual
                usuarioActual.Relacion = {
                    pareja: parejaJid,
                    estado: 'casado',
                    desde: fecha,
                    nombrePareja: pareja.Nombre
                };
                
                // Actualizar pareja
                pareja.Relacion = {
                    pareja: userJid,
                    estado: 'casado',
                    desde: fecha,
                    nombrePareja: usuarioActual.Nombre
                };

                // Eliminar las solicitudes
                delete usuarioActual.SolicitudMatrimonio;
                delete pareja.SolicitudMatrimonio;

                // Actualizar la lista de usuarios
                usuariosRegistrados = usuariosRegistrados.map(u => {
                    if (u.Usuario === userJid) return usuarioActual;
                    if (u.Usuario === parejaJid) return pareja;
                    return u;
                });

                // Guardar los cambios
                await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2), 'utf8');

                return ResponderTextoFalso(
                    `💍 ¡Felicidades! *${usuarioActual.Nombre}* y *${pareja.Nombre}* ahora están casados. 💕\n` +
                    `📅 Fecha de la boda: *${fecha}*\n\n` +
                    `¡Que su unión sea eterna! 💖`
                );
            }

            // Verificar si la pareja ya tiene una solicitud de otra persona
            if (pareja.SolicitudMatrimonio && pareja.SolicitudMatrimonio !== userJid) {
                return ResponderTextoFalso(`❌ ${pareja.Nombre} ya tiene una solicitud de matrimonio pendiente de otra persona.`);
            }

            // ENVIAR SOLICITUD - Crear una nueva solicitud
            usuarioActual.SolicitudMatrimonio = parejaJid;

            // Actualizar la lista de usuarios
            usuariosRegistrados = usuariosRegistrados.map(u => 
                u.Usuario === userJid ? usuarioActual : u
            );

            // Guardar los cambios
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2), 'utf8');

            // Obtener el nombre del usuario actual
            const nombreUsuarioActual = usuarioActual.Nombre;

            // Enviar mensaje de éxito al usuario actual
            await ResponderTextoFalso(
                `💍 Le has enviado una solicitud de matrimonio a *${pareja.Nombre}*.\n\n` +
                `Para que sean novios, *${pareja.Nombre}* debe usar el comando:\n` +
                `*${config.prefijo}marry @${nombreUsuarioActual}*`
            );

        } catch (error) {
            console.error('Error en comando casarse:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al procesar la solicitud de matrimonio.');
        }
    }
};