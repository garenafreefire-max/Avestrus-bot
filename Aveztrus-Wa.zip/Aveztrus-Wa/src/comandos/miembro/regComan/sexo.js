const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'sexo',
    descripcion: 'Establece tu género. Opciones: hombre/masculino o mujer/femenino',
    comando: ['sexo', 'genero', 'gender'],
    requiereRegistro: true,
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, ResponderFotoFalsa, args, userJid, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', 'database', 'UserReg.json');
        const mediaPath = path.join(__dirname, '..', '..', '..', 'media', 'imagenes');

        if (args.length === 0) {
            return ResponderTextoFalso(`❌ Debes especificar tu género. Ejemplo: ${cofig.prefijo}sexo hombre o $sexo mujer`);
        }

        const generoInput = args.join(' ').toLowerCase();

        // Validar y normalizar el género (aceptando diferentes formas de escribirlo)
        let generoNormalizado;
        if (generoInput.includes('hombre') || generoInput.includes('masculino') || generoInput.includes('macho') || generoInput.includes('varon')) {
            generoNormalizado = 'Hombre';
        } else if (generoInput.includes('mujer') || generoInput.includes('femenino') || generoInput.includes('hembra') || generoInput.includes('chica')) {
            generoNormalizado = 'Mujer';
        } else {
            return ResponderTextoFalso('❌ Género no válido. Usa: hombre/masculino o mujer/femenino');
        }

        try {
            // Leer la base de datos
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (error) {
                return ResponderTextoFalso('❌ Error al leer la base de datos de usuarios.');
            }

            // Buscar al usuario
            const usuarioIndex = usuariosRegistrados.findIndex(u => u.Usuario === userJid);
            if (usuarioIndex === -1) {
                return ResponderTextoFalso('❌ No estás registrado. Regístrate primero con $reg');
            }

            // Actualizar el género del usuario
            usuariosRegistrados[usuarioIndex].Genero = generoNormalizado;

            // Guardar los cambios
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2), 'utf8');

            // Determinar la ruta de la imagen según el género
            const imagenPath = path.join(mediaPath, `${generoNormalizado.toLowerCase()}.jpg`);
            
            // Verificar si la imagen existe
            try {
                await fs.access(imagenPath);
            } catch (error) {
                // Si la imagen no existe, usar una por defecto o enviar solo texto
                return ResponderTextoFalso(`✅ Tu género se ha establecido como: *${generoNormalizado}*\n\n💡 Nota: La imagen para este género no está configurada.`);
            }

            // Enviar la imagen con el mensaje
            await ResponderFotoFalsa(
                imagenPath, 
                `✅ Tu género se ha establecido como: *${generoNormalizado}*`
            );

        } catch (error) {
            console.error('Error en comando sexo:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al establecer tu género.');
        }
    }
};