const fs = require('fs').promises;
const path = require('path');

module.exports = {
    nombre: 'cazar',
    descripcion: 'Ve a cazar y gana monedas.',
    comando: ['cazar'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid, myCache, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        // Cooldown de 10 minutos (600 segundos)
        const cooldownKey = `cazar_${userJid}`;
        const cooldownTime = 600; 
        
        const lastUsed = myCache.get(cooldownKey);
        if (lastUsed) {
            const timeLeft = cooldownTime - (Date.now() - lastUsed) / 1000;
            const minutos = Math.floor(timeLeft / 60);
            const segundos = Math.floor(timeLeft % 60);
            return ResponderTextoFalso(`⏳ Aún no hay presas. Vuelve a cazar en *${minutos}m ${segundos}s*.`);
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return ResponderTextoFalso('❌ No hay usuarios registrados.');
            }
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);

            if (!usuario) {
                return ResponderTextoFalso(`❌ No estás registrado. Usa el comando *${config.prefijo}reg* para crear un perfil.`);
            }

            // Probabilidades de caza
            const resultados = [
                { nombre: 'ciervo', emoji: '🦌', ganancia: 200, probabilidad: 0.4 }, // 40%
                { nombre: 'jabalí', emoji: '🐗', ganancia: 400, probabilidad: 0.2 }, // 20%
                { nombre: 'zorro', emoji: '🦊', ganancia: 100, probabilidad: 0.3 }, // 30%
                { nombre: 'nada', emoji: '🌲', ganancia: 0, probabilidad: 0.1 } // 10%
            ];

            let resultadoFinal = null;
            let random = Math.random();
            let acumulado = 0;

            for (const resultado of resultados) {
                acumulado += resultado.probabilidad;
                if (random < acumulado) {
                    resultadoFinal = resultado;
                    break;
                }
            }
            
            usuario.Moneda += resultadoFinal.ganancia;
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
            myCache.set(cooldownKey, Date.now(), cooldownTime);

            let mensaje = `🏹 ¡Saliste a cazar!\n\n`;
            if (resultadoFinal.ganancia > 0) {
                mensaje += `¡Has cazado un *${resultadoFinal.nombre}* ${resultadoFinal.emoji} y ganaste *${resultadoFinal.ganancia}* monedas!`;
            } else {
                mensaje += `¡No encontraste nada! ${resultadoFinal.emoji}`;
            }

            mensaje += `\n\n*Monedas actuales:* ${usuario.Moneda}`;
            await ResponderTextoFalso(mensaje);

        } catch (error) {
            console.error('Error en el comando cazar:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al intentar cazar.');
        }
    }
};
