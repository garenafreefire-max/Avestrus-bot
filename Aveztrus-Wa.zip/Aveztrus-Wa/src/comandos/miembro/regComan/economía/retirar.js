const fs = require('fs').promises;
const path = require('path');

module.exports = {
    nombre: 'retirar',
    descripcion: 'Retira monedas de tu banco para usarlas en otros comandos.',
    comando: ['retirar', 'retire'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid, args, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');

        if (!args[0]) {
            return ResponderTextoFalso(`❌ Debes especificar la cantidad de monedas a retirar. Ejemplo: *${config.prefijo}retirar 100*`);
        }

        const cantidad = parseInt(args[0]);

        if (isNaN(cantidad) || cantidad <= 0) {
            return ResponderTextoFalso('❌ La cantidad debe ser un número válido y mayor que cero.');
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return ResponderTextoFalso('❌ No hay usuarios registrados.');
            }
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);

            if (!usuario) {
                return ResponderTextoFalso(`❌ No estás registrado. Usa el comando *${config.prefijo}reg* para crear un perfil.`);
            }
            
            if (usuario.Banco < cantidad) {
                return ResponderTextoFalso(`❌ No tienes suficientes monedas en el banco para retirar. Tienes *${usuario.Banco}* monedas.`);
            }

            // Realizar el retiro
            usuario.Banco -= cantidad;
            usuario.Moneda += cantidad;

            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));

            await ResponderTextoFalso(`✅ Has retirado *${cantidad}* monedas del banco.\n\n*Monedas actuales:* ${usuario.Moneda}\n*Saldo en el banco:* ${usuario.Banco}`);

        } catch (error) {
            console.error('Error en el comando retirar:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al procesar el retiro. Inténtalo de nuevo más tarde.');
        }
    }
};
