const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'cofre',
    descripcion: 'Abre un cofre para obtener recompensas aleatorias de monedas y diamantes.',
    comando: ['cofre', 'chest'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid, myCache, config} = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        const cooldownKey = `cofre_${userJid}`;
        const cooldownTime = 3600; // 1 hora en segundos
        
        const lastUsed = myCache.get(cooldownKey);
        if (lastUsed) {
            const timeLeft = cooldownTime - (Date.now() - lastUsed) / 1000;
            const horas = Math.floor(timeLeft / 3600);
            const minutos = Math.floor((timeLeft % 3600) / 60);
            return ResponderTextoFalso(`⏳ Tienes que esperar *${horas}h ${minutos}m* para abrir otro cofre.`);
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return ResponderTextoFalso(`❌ No hay usuarios registrados. Usa ${config.prefijo}reg para registrarte.`);
            }
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (!usuario) {
                return ResponderTextoFalso(`❌ Debes estar registrado para abrir cofres. Usa *${config.prefijo}reg* para registrarte.`);
            }

            // Generar recompensas aleatorias
            const monedas = Math.floor(Math.random() * 6001); // 0 a 6000
            const diamantes = Math.floor(Math.random() * 101); // 0 a 100

            usuario.Moneda += monedas;
            usuario.Diamante += diamantes;

            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
            myCache.set(cooldownKey, Date.now(), cooldownTime);

            let mensaje = `🎁 ¡Has abierto un cofre y encontrado:\n`;
            mensaje += `💰 *${monedas}* monedas\n`;
            mensaje += `💎 *${diamantes}* diamantes\n`;
            mensaje += `¡Disfruta de tu botín!`;

            await ResponderTextoFalso(mensaje);

        } catch (error) {
            console.error('Error en el comando cofre:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al abrir el cofre.');
        }
    }
};