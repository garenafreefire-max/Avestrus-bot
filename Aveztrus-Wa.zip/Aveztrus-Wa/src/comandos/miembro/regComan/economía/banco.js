const fs = require('fs').promises;
const path = require('path');

module.exports = {
    nombre: 'banco',
    descripcion: 'Deposita monedas en el banco para guardarlas de forma segura.',
    comando: ['banco', 'deposito'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid, args, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');

        if (!args[0]) {
            return ResponderTextoFalso(`❌ Debes especificar la cantidad de monedas a depositar. Ejemplo: *${config.prefijo}banco 100*`);
        }

        const cantidad = parseInt(args[0]);

        if (isNaN(cantidad) || cantidad <= 0) {
            return ResponderTextoFalso('❌ La cantidad debe ser un número válido y mayor que cero.');
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return ResponderTextoFalso('❌ No hay usuarios registrados.');
            }
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);

            if (!usuario) {
                return ResponderTextoFalso(`❌ No estás registrado. Usa el comando *${config.prefijo}reg* para crear un perfil.`);
            }

            if (usuario.Moneda < cantidad) {
                return ResponderTextoFalso(`❌ No tienes suficientes monedas para depositar. Tienes *${usuario.Moneda}* monedas.`);
            }

            // Realizar el depósito
            usuario.Moneda -= cantidad;
            usuario.Banco += cantidad;

            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));

            await ResponderTextoFalso(`✅ Has depositado *${cantidad}* monedas en el banco.\n\n*Monedas actuales:* ${usuario.Moneda}\n*Saldo en el banco:* ${usuario.Banco}\n para retirar del banco usa ${config.prefijo}retirar`);

        } catch (error) {
            console.error('Error en el comando banco:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al procesar el depósito. Inténtalo de nuevo más tarde.');
        }
    }
};
