const path = require('path');
const fs = require('fs').promises;

// Función para seleccionar un símbolo basado en su peso (probabilidad)
const seleccionarSimbolo = (simbolos) => {
    let totalPeso = 0;
    for (const s of simbolos) {
        totalPeso += s.peso;
    }
    
    let random = Math.random() * totalPeso;
    
    for (const s of simbolos) {
        if (random < s.peso) {
            return s.emoji;
        }
        random -= s.peso;
    }
    // En caso de que falle, devuelve el último
    return simbolos[simbolos.length - 1].emoji;
};

module.exports = {
    nombre: 'slot',
    descripcion: 'Apuesta en la máquina tragamonedas 777. ¡La dificultad es más alta!',
    comando: ['slot', 'slots'],
    ejecutar: async (ctx) => {
        // 🚨 CAMBIO: Se usa responderTexto en lugar de ResponderTextoFalso
        const { responderTexto, reaccionarMensaje, userJid, myCache, args } = ctx; 
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        // Cooldown de 30 segundos
        const cooldownKey = `slot_${userJid}`;
        const cooldownTime = 30;
        
        const lastUsed = myCache.get(cooldownKey);
        if (lastUsed) {
            const timeLeft = cooldownTime - (Date.now() - lastUsed) / 1000;
            return responderTexto(`⏳ Tienes que esperar *${timeLeft.toFixed(0)} segundos* para volver a jugar.`);
        }

        if (args.length === 0) {
            return responderTexto(`❌ Debes especificar la cantidad de monedas a apostar. Ejemplo: *${ctx.config.prefijo}slot 100*`);
        }
        
        const apuesta = parseInt(args[0]);
        if (isNaN(apuesta) || apuesta <= 0) {
            return responderTexto('❌ La cantidad a apostar debe ser un número válido y mayor que cero.');
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return responderTexto('❌ No hay usuarios registrados. Usa $reg para registrarte.');
            }
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (!usuario) {
                return responderTexto('❌ Debes estar registrado para jugar. Usa *$reg* para registrarte.');
            }
            
            if (usuario.Moneda < apuesta) {
                return responderTexto(`❌ No tienes suficientes monedas para apostar *${apuesta}*. Tienes *${usuario.Moneda}* monedas.`);
            }

            // Lógica del juego de tragamonedas con pesos ajustados
            const simbolosConPeso = [
                { emoji: '🍒', peso: 50 }, // Muy probable
                { emoji: '🍋', peso: 40 },
                { emoji: '🍇', peso: 30 },
                { emoji: '🔔', peso: 20 },
                { emoji: '🍀', peso: 15 },
                { emoji: '💎', peso: 10 },
                { emoji: '💰', peso: 5 },
                { emoji: '👑', peso: 1 },  // Muy improbable
            ];
            
            // Rodillos de la máquina tragamonedas (se escogen 3 símbolos al azar según el peso)
            const rodillo1 = seleccionarSimbolo(simbolosConPeso);
            const rodillo2 = seleccionarSimbolo(simbolosConPeso);
            const rodillo3 = seleccionarSimbolo(simbolosConPeso);

            const resultadoRodillos = `${rodillo1} | ${rodillo2} | ${rodillo3}`;

            let mensaje = `🎰 ¡Girando los rodillos de Slotoland! 🎰\n\n[ *${resultadoRodillos}* ]\n\n`;
            let ganancia = 0;
            let emojiReaccion = '🎰';

            if (rodillo1 === rodillo2 && rodillo2 === rodillo3) {
                // Tres símbolos iguales
                switch (rodillo1) {
                    case '🍒':
                        ganancia = apuesta * 2;
                        mensaje += `🍒🍒🍒 ¡Premio! Tres cerezas. Ganaste *${ganancia}* monedas.`;
                        emojiReaccion = '🥳';
                        break;
                    case '🍋':
                        ganancia = apuesta * 3;
                        mensaje += `🍋🍋🍋 ¡Genial! Tres limones. Ganaste *${ganancia}* monedas.`;
                        emojiReaccion = '🥳';
                        break;
                    case '🍇':
                        ganancia = apuesta * 4;
                        mensaje += `🍇🍇🍇 ¡Increíble! Tres uvas. Ganaste *${ganancia}* monedas.`;
                        emojiReaccion = '🥳';
                        break;
                    case '🔔':
                        ganancia = apuesta * 5;
                        mensaje += `🔔🔔🔔 ¡Fantástico! Tres campanas. Ganaste *${ganancia}* monedas.`;
                        emojiReaccion = '🎉';
                        break;
                    case '🍀':
                        ganancia = apuesta * 8;
                        mensaje += `🍀🍀🍀 ¡Qué suerte! Tres tréboles. Ganaste *${ganancia}* monedas.`;
                        emojiReaccion = '🍀';
                        break;
                    case '💎':
                        ganancia = apuesta * 10;
                        mensaje += `💎💎💎 ¡Jackpot! Tres diamantes. Ganaste *${ganancia}* monedas.`;
                        emojiReaccion = '💎';
                        break;
                    case '💰':
                        ganancia = apuesta * 20;
                        mensaje += `💰💰💰 ¡Megapremio! Tres bolsas de dinero. Ganaste *${ganancia}* monedas.`;
                        emojiReaccion = '🤑';
                        break;
                    case '👑':
                        ganancia = apuesta * 50;
                        mensaje += `👑👑👑 ¡Premio Máximo! Tres coronas. Ganaste *${ganancia}* monedas.`;
                        emojiReaccion = '👑';
                        break;
                }
            } else if (rodillo1 === rodillo2 || rodillo2 === rodillo3 || rodillo1 === rodillo3) {
                // Dos símbolos iguales
                ganancia = apuesta * 1.5;
                mensaje += `💰 ¡Casi! Dos símbolos iguales. Ganaste *${ganancia.toFixed(0)}* monedas.`;
                emojiReaccion = '🙌';
            } else {
                // Ninguna coincidencia
                ganancia = -apuesta;
                mensaje += `💔 Ninguna coincidencia. Has perdido tus *${apuesta}* monedas.`;
                emojiReaccion = '😭';
            }
            
            // Actualizar el saldo
            usuario.Moneda += ganancia;
            mensaje += `\n\nTu nuevo total es de *${usuario.Moneda.toFixed(0)}* monedas.`;
            
            // Guardar el historial actualizado y el cooldown
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
            myCache.set(cooldownKey, Date.now(), cooldownTime);

            // 🚨 CAMBIO
            await responderTexto(mensaje);
            await reaccionarMensaje(emojiReaccion);

        } catch (error) {
            console.error('Error en el comando slot:', error);
            // 🚨 CAMBIO
            await responderTexto('❌ Ocurrió un error al intentar jugar al slot.');
        }
    }
};
