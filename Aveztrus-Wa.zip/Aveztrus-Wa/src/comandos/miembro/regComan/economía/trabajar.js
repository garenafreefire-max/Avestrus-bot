// /src/comandos/regComan/trabajar.js
const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'trabajar',
    descripcion: 'Gana monedas con diferentes resultados y probabilidades.',
    comando: ['trabajar', 'chamba', 'work'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid, myCache } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        // Cooldown de 18 minutos (18 * 60 = 1080 segundos)
        const cooldownKey = `trabajar_${userJid}`;
        const cooldownTime = 1080; 
        
        // Verificar si el usuario está en cooldown
        const lastUsed = myCache.get(cooldownKey);
        if (lastUsed) {
            const timeLeft = cooldownTime - (Date.now() - lastUsed) / 1000;
            const minutos = Math.floor(timeLeft / 60);
            const segundos = Math.floor(timeLeft % 60);
            return ResponderTextoFalso(`⏳ Tienes que esperar *${minutos}m ${segundos}s* para volver a trabajar.`);
        }

        try {
            // Leer el archivo de registro
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return ResponderTextoFalso('❌ No hay usuarios registrados. Usa $reg para registrarte.');
            }

            // Buscar al usuario actual
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (!usuario) {
                return ResponderTextoFalso('❌ Debes estar registrado para trabajar. Usa *$reg* para registrarte.');
            }

            // Probabilidad de éxito (70%)
            const probabilidadExito = 0.7;
            const exito = Math.random() < probabilidadExito;

            if (exito) {
                const monedasGanadas = Math.floor(Math.random() * 200) + 1;
                usuario.Moneda += monedasGanadas;
                
                const frasesExito = [
                    `✅ ¡Buen trabajo, ${usuario.Nombre}! Has encontrado una veta de oro de la que has sacado *${monedasGanadas}* monedas.`,
                    `✅ Como repartidor, ${usuario.Nombre}, has entregado un pedido importante. ¡El cliente te ha dado una propina de *${monedasGanadas}* monedas!`,
                    `✅ ¡Qué gran actuación! Tu concierto ha sido un éxito y los fans te han lanzado *${monedasGanadas}* monedas.`,
                    `✅ ¡Eres un genio del trading! Has hecho una jugada maestra que te ha generado *${monedasGanadas}* monedas.`,
                    `✅ ¡Alerta! Eres policía, ${usuario.Nombre}, y has capturado a un criminal. ¡Gracias por tu trabajo! Has ganado *${monedasGanadas}* monedas.`,
                    `✅ Has terminado de construir una gran casa, ${usuario.Nombre}, el dueño está muy contento y te dió *${monedasGanadas}* monedas.`,
                    `✅ Eres un doctor, ${usuario.Nombre}, salvaste una vida en peligro de extinción y te dieron *${monedasGanadas}* monedas como agradecimiento.`,
                    `✅ Eres un gran abogado, ${usuario.Nombre}, ganaste el caso y tu cliente te dió *${monedasGanadas}* monedas.`,
                    `✅ Has hecho un gran servicio militar, ${usuario.Nombre}, el comandante te felicita y te dió *${monedasGanadas}* monedas.`,
                    `✅ Eres un mecánico, ${usuario.Nombre}, y has arreglado un auto de lujo. El cliente te dió *${monedasGanadas}* monedas por tu trabajo.`,
                    `✅ Como pescador, ${usuario.Nombre}, atrapaste un pez muy grande y lo vendiste por *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran artista, ${usuario.Nombre}, vendiste tu obra maestra por *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran chef, ${usuario.Nombre}, tu plato ha sido el mejor del mes y te han dado un bono de *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran programador, ${usuario.Nombre}, has creado una aplicación que se ha vuelto viral y has ganado *${monedasGanadas}* monedas.`,
                    `✅ Como granjero, ${usuario.Nombre}, has tenido una gran cosecha de la que has obtenido *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran escritor, ${usuario.Nombre}, tu nuevo libro ha sido un éxito y has ganado *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran youtuber, ${usuario.Nombre}, has superado el millón de suscriptores y has ganado *${monedasGanadas}* monedas.`,
                    `✅ Como astronauta, ${usuario.Nombre}, has descubierto un nuevo planeta y te han dado una recompensa de *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran atleta, ${usuario.Nombre}, ganaste la medalla de oro y has ganado *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran arquitecto, ${usuario.Nombre}, has diseñado un edificio espectacular y has ganado *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran diseñador de moda, ${usuario.Nombre}, tu nueva colección ha sido un éxito y has ganado *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran fotógrafo, ${usuario.Nombre}, vendiste una foto única por *${monedasGanadas}* monedas.`,
                    `✅ Eres un gran actor, ${usuario.Nombre}, tu película ha sido un éxito y has ganado *${monedasGanadas}* monedas.`
                ];
                const fraseAleatoria = frasesExito[Math.floor(Math.random() * frasesExito.length)];
                
                await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
                myCache.set(cooldownKey, Date.now(), cooldownTime); // <--- Se establece el cooldown
                await ResponderTextoFalso(`${fraseAleatoria}\n\n🎉 ¡Tu nuevo total es de *${usuario.Moneda}* monedas!`);

            } else {
                const frasesFracaso = [
                    "❌ Te quedaste dormido en tu turno y te descontaron el día.",
                    "❌ Tu jefe se molestó porque perdiste el inventario.",
                    "❌ Te han despedido por irresponsable, no ganaste nada.",
                    "❌ Te robaron tu herramienta de trabajo.",
                    "❌ Te rompiste una pierna en el trabajo, no puedes trabajar.",
                    "❌ Perdistes todo el dinero en el mercado de valores.",
                    "❌ Se te quemó el puesto de comida.",
                    "❌ Fallaste al encontrar un tesoro, vuelvelo a intentar más tarde.",
                    "❌ Un maleante te asaltó y se llevó tu dinero.",
                    "❌ Te has quedado sin gasolina en el camino, perdiste el pedido.",
                    "❌ Eres un médico y perdiste a tu paciente. No recibiste paga.",
                    "❌ Te han rechazado la demanda, no has recibido dinero.",
                    "❌ Tu equipo perdió la final, no ganaste nada.",
                    "❌ Un virus afectó a tu sistema, no recibiste paga.",
                    "❌ No has vendido nada hoy.",
                    "❌ Tu casa de apuestas se derrumbó.",
                    "❌ Tu jefe no te pagó hoy.",
                    "❌ Tuviste un accidente de auto en el camino al trabajo.",
                    "❌ Tu cliente te canceló el pedido.",
                    "❌ Te quedaste sin clientes en tu negocio.",
                    "❌ No has podido encontrar el trabajo perfecto para ti.",
                    "❌ Tu jefe te regañó y te hizo trabajar gratis.",
                    "❌ Te asaltaron y te quitaron el dinero."
                ];
                const fraseAleatoria = frasesFracaso[Math.floor(Math.random() * frasesFracaso.length)];
                myCache.set(cooldownKey, Date.now(), cooldownTime); // <--- Se establece el cooldown
                await ResponderTextoFalso(fraseAleatoria);
            }
        } catch (error) {
            console.error('Error en el comando trabajar:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al intentar trabajar.');
        }
    }
};
