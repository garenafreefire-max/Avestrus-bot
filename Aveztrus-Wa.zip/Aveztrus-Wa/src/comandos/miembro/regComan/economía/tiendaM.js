const fs = require('fs/promises');
const path = require('path');

// Mapeo de precios: cuántos diamantes se necesitan para cada cantidad de monedas.
const PRECIOS_INVERSOS = {
    348: 3,
    583: 6,
    769: 8,
    1338: 10,
    2000: 15,
    3000: 27
};

// 🔹 Ruta corregida a la base de datos de usuarios (asumiendo 4 niveles de subida desde /economía)
const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');

module.exports = {
    comando: ['tiendam'], // Renombrado para no usar 'tienda'
    descripcion: 'Compra monedas con diamantes.',
    ejecutar: async (ctx) => {
        // Usaremos responderTexto, pero mantengo ResponderTextoFalso para compatibilidad si ctx no lo trae
        const { args, userJid, ResponderTextoFalso, responderTexto, config } = ctx; 
        const responder = responderTexto || ResponderTextoFalso;

        try {
            const data = await fs.readFile(dbPath, 'utf8');
            const usuariosRegistrados = JSON.parse(data);
            const usuarioIndex = usuariosRegistrados.findIndex(u => u.Usuario === userJid);

            if (usuarioIndex === -1) {
                await responder(`❌ No estás registrado. Usa *${config.prefijo}reg* para registrarte.`);
                return;
            }

            const usuario = usuariosRegistrados[usuarioIndex];
            const cantidadMonedas = parseInt(args[0]);

            if (!args[0] || isNaN(cantidadMonedas) || cantidadMonedas <= 0) {
                let textoTienda = `
🛍️ *Tienda de Monedas (Diamantes ➡️ Monedas)*
Para comprar, usa: *${config.prefijo}tiendam <cantidad_monedas>*
`;
                for (const monedas in PRECIOS_INVERSOS) {
                    const diamantes = PRECIOS_INVERSOS[monedas];
                    textoTienda += `💎 *${diamantes}* =  *${monedas}* 🪙\\n`;
                }

                await responder(textoTienda);
                return;
            }

            const diamantesRequeridos = PRECIOS_INVERSOS[cantidadMonedas];

            if (!diamantesRequeridos) {
                await responder(`❌ La cantidad de monedas *${cantidadMonedas}* no es una opción válida en la tienda.`);
                return;
            }

            if (usuario.Diamante < diamantesRequeridos) {
                await responder(`😥 No tienes suficientes diamantes. Te faltan *${diamantesRequeridos - usuario.Diamante}* 💎 para comprar este paquete.`);
                return;
            }

            // Realizar la transacción
            usuario.Diamante -= diamantesRequeridos;
            usuario.Moneda += cantidadMonedas;

            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));

            await responder(`✅ ¡Compra exitosa!\nSe te han quitado *${diamantesRequeridos}* 💎 y se te han añadido *${cantidadMonedas}* 🪙.\n*Monedas actuales:* ${usuario.Moneda} 🪙\n*Diamantes actuales:* ${usuario.Diamante} 💎`);

        } catch (error) {
            console.error('Error en el comando tiendaMonedas:', error);
            await responder('❌ Ocurrió un error al procesar tu compra. Inténtalo de nuevo más tarde.');
        }
    }
};
