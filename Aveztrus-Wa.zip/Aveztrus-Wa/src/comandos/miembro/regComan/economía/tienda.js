const path = require('path');
const fs = require('fs').promises;

// --- CONFIGURACIÓN DE PRECIOS ACTUALIZADA ---
// 🚨 CAMBIO: El escudo ahora es un item de usos, no de tiempo.
const PRECIO_ESCUDO_DIAMANTES = 70; 
const USOS_ESCUDO = 1; // Usos por compra
const PRECIO_HACKER_KIT_DIAMANTES = 230; 

module.exports = {
    nombre: 'tienda',
    descripcion: 'Compra items de protección (Escudo) y de ataque (Hacker Kit).',
    comando: ['tienda', 'shop', 'tiendaitem'],
    requiereRegistro: true,
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, responderTexto, args, userJid, config } = ctx; 
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        const responder = responderTexto || ResponderTextoFalso;
        
        const argumento = args[0] ? args[0].toLowerCase() : '';

        if (args.length === 0) {
            return responder(`
🛍️ *Tienda de Items*

*1. Escudo Antirrobo (🛡️)*
  Precio: *${PRECIO_ESCUDO_DIAMANTES}* 💎 (Diamantes)
  Efecto: Bloquea *${USOS_ESCUDO}* intentos de robo.
  Uso: *${config.prefijo}tienda escudo*

*2. Kit Hacker (💻)*
  Precio: *${PRECIO_HACKER_KIT_DIAMANTES}* 💎 (Diamantes)
  Efecto: Roba dinero del banco (1 uso).
  Uso: *${config.prefijo}tienda kit*
`);
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (error) {
                return responder('❌ Error al leer la base de datos.');
            }

            const usuarioIndex = usuariosRegistrados.findIndex(u => u.Usuario === userJid);
            if (usuarioIndex === -1) {
                return responder(`❌ No estás registrado. Usa *${config.prefijo}reg* para registrarte.`);
            }

            const usuario = usuariosRegistrados[usuarioIndex];
            
            // Asegurar que el objeto Inventario existe
            if (!usuario.Inventario) usuario.Inventario = {};


            // --- LÓGICA DE COMPRA DE ESCUDO ---
            if (argumento === 'escudo') {
                
                // 1. Verificar diamantes
                if ((usuario.Diamante || 0) < PRECIO_ESCUDO_DIAMANTES) {
                    return responder(`❌ No tienes suficientes diamantes para comprar el Escudo. Necesitas: *${PRECIO_ESCUDO_DIAMANTES}* 💎.`);
                }
                
                // 2. Realizar la compra
                usuario.Diamante = (usuario.Diamante || 0) - PRECIO_ESCUDO_DIAMANTES;
                // 🚨 CAMBIO: Añadir 1 al inventario
                usuario.Inventario.Escudo = (usuario.Inventario.Escudo || 0) + USOS_ESCUDO;

                await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));

                return responder(
                    `🛡️ ¡Has comprado un *Escudo Antirrobo* por *${PRECIO_ESCUDO_DIAMANTES}* 💎!\n` +
                    `✨ Has añadido *${USOS_ESCUDO} usos* de protección contra robos.\n` +
                    `*Usos totales de escudo:* ${usuario.Inventario.Escudo}`
                );
            }

            // --- LÓGICA DE COMPRA DE KIT HACKER ---
            else if (argumento === 'kit' || argumento === 'hacker') {
                if ((usuario.Diamante || 0) < PRECIO_HACKER_KIT_DIAMANTES) {
                    return responder(`❌ No tienes suficientes diamantes para comprar el Kit Hacker. Necesitas: *${PRECIO_HACKER_KIT_DIAMANTES}* 💎.`);
                }

                usuario.Diamante = (usuario.Diamante || 0) - PRECIO_HACKER_KIT_DIAMANTES;
                usuario.Inventario.HackerKit = (usuario.Inventario.HackerKit || 0) + 1;

                await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));

                return responder(
                    `💻 ¡Has comprado un *Kit Hacker* por *${PRECIO_HACKER_KIT_DIAMANTES}* 💎!\n` +
                    `✨ Ahora puedes robar dinero del banco de una víctima (1 uso).\n` +
                    `*Kits totales:* ${usuario.Inventario.HackerKit}`
                );
            }
            
            // --- ITEM NO VÁLIDO ---\n
            else {
                return responder(`❌ Item no disponible. Opciones: *escudo* o *kit*`);
            }


        } catch (error) {
            console.error('Error en comando tienda:', error);
            await responder('❌ Ocurrió un error al procesar tu compra. Inténtalo de nuevo más tarde.');
        }
    }
};
