const path = require('path');
const fs = require('fs').promises;
const { exec } = require('child_process');

module.exports = {
    nombre: 'minar',
    descripcion: 'Mina diamantes con un tiempo de espera. Ejemplo: $minar',
    comando: ['minar', 'mine'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, ResponderGifFalso, userJid, myCache, delay } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        const cooldownKey = `minar_${userJid}`;
        const cooldownTime = 12; // 12 segundos
        
        const lastUsed = myCache.get(cooldownKey);
        if (lastUsed) {
            const timeLeft = cooldownTime - (Date.now() - lastUsed) / 1000;
            return ResponderTextoFalso(`⏳ Tienes que esperar *${timeLeft.toFixed(0)} segundos* para volver a minar.`);
        }

        const gifPath = path.join(__dirname, '..', '..', '..', '..', 'media', 'gifs', 'minar.gif');
        const mp4Path = path.join(__dirname, '..', '..', '..', '..', 'media', 'gifs', 'minar_animado.mp4');

        try {
            // 🔹 Paso 1: Convertir el GIF a MP4 con FFmpeg para asegurar la compatibilidad
            if (!await fs.access(mp4Path).then(() => true).catch(() => false)) {
                console.log('🔄 Convirtiendo GIF a MP4 para una reproducción fluida...');
                await new Promise((resolve, reject) => {
                    const ffmpegCmd = `ffmpeg -i "${gifPath}" -movflags faststart -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" "${mp4Path}"`;
                    exec(ffmpegCmd, (error) => {
                        if (error) {
                            console.error('❌ Error en FFmpeg:', error);
                            return reject(new Error('Error al convertir el GIF.'));
                        }
                        resolve();
                    });
                });
                await delay(2000); // Pequeño retraso para asegurar que el archivo se guarde
            }

            // 🔹 Paso 2: El resto de la lógica del comando se mantiene igual
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return ResponderTextoFalso('❌ No hay usuarios registrados. Usa $reg para registrarte.');
            }
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (!usuario) {
                return ResponderTextoFalso('❌ No estás registrado. Usa $reg para registrarte.');
            }

            const diamantesMinados = Math.floor(Math.random() * 5) + 1;
            usuario.Diamante += diamantesMinados;
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
            myCache.set(cooldownKey, Date.now(), cooldownTime);

            const caption = `⛏️ ¡Felicidades, ${usuario.Nombre}!\nHas minado *${diamantesMinados}* diamantes.\nTu nuevo total es de *${usuario.Diamante}* diamantes.`;
            
            // 🔹 Paso 3: Enviar el archivo MP4 recién creado
            if (await fs.access(mp4Path).then(() => true).catch(() => false)) {
                await ResponderGifFalso(mp4Path, caption);
                console.log('✅ Animación de minado enviada exitosamente.');
            } else {
                await ResponderTextoFalso('❌ No se encontró el archivo de animación. Intenta de nuevo.');
            }

        } catch (error) {
            console.error('Error en el comando minar:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al intentar minar.');
        }
    }
};

