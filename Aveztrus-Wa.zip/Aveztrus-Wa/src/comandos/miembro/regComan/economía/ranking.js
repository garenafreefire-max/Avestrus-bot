const fs = require('fs').promises;
const path = require('path');

module.exports = {
    nombre: 'top',
    descripcion: 'Muestra el top 10 de los usuarios con más monedas y diamantes.',
    comando: ['ranking'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');

        try {
            const data = await fs.readFile(dbPath, 'utf8');
            const usuarios = JSON.parse(data);

            if (usuarios.length === 0) {
                await ResponderTextoFalso('❌ No hay usuarios registrados para mostrar en el top.');
                return;
            }

            // Mapear y calcular el puntaje total (monedas + diamantes)
            const usuariosConPuntaje = usuarios.map(usuario => {
                const monedas = usuario.Moneda || 0;
                const diamantes = usuario.Diamante || 0;
                return {
                    Nombre: usuario.Nombre,
                    Moneda: monedas,
                    Diamante: diamantes,
                    PuntuacionTotal: monedas + diamantes
                };
            });

            // Ordenar los usuarios de mayor a menor puntaje
            usuariosConPuntaje.sort((a, b) => b.PuntuacionTotal - a.PuntuacionTotal);

            // Tomar solo el top 10 (o menos si no hay suficientes)
            const top10 = usuariosConPuntaje.slice(0, 10);
            
            // Construir el mensaje de respuesta con decoración
            let mensajeTop = `
╭━━━〔 🏆 *Ranking de Usuarios* 〕━━━╮
`;

            top10.forEach((usuario, index) => {
                mensajeTop += `
┃ *${index + 1}.* *${usuario.Nombre}*
┃    • 🪙 Monedas: *${usuario.Moneda}*
┃    • 💎 Diamantes: *${usuario.Diamante}*
`;
            });

            mensajeTop += `
╰━━━━━━━━━━━━━━━━━━╯
`;

            await ResponderTextoFalso(mensajeTop);

        } catch (error) {
            console.error('Error al ejecutar el comando top:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al intentar mostrar el top de usuarios.');
        }
    }
};
