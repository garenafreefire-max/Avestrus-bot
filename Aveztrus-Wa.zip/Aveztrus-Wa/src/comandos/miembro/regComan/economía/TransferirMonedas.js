const fs = require('fs');
const path = require('path');

module.exports = {
    nombre: 'tran',
    descripcion: 'Transfiere una cantidad de monedas a otro usuario registrado.',
    comando: ['tranm'],
    ejecutar: async (ctx) => {
        const { m, userJid, args, EnviarRespuestaFalsa, config } = ctx;


        if (args.length < 2) {
            await EnviarRespuestaFalsa(`❌ Uso incorrecto. Sintaxis: *${config.prefijo}tranm <cantidad> <numero_destino>*`, m);
            return;
        }

        const cantidad = parseInt(args[0]);
        const numeroDestino = args[1].replace(/@/g, ''); 
        
        if (isNaN(cantidad) || cantidad <= 0) {
            await EnviarRespuestaFalsa('❌ La cantidad a transferir debe ser un número entero y positivo.', m);
            return;
        }
        
        const remitenteNumero = userJid.split('@')[0];
        
        if (numeroDestino === remitenteNumero) {
            await EnviarRespuestaFalsa('❌ No puedes transferirte monedas a ti mismo.', m);
            return;
        }

        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        try {
            const data = fs.readFileSync(dbPath, 'utf8');
            const usuarios = JSON.parse(data);

            const remitente = usuarios.find(u => u.Usuario.includes(remitenteNumero));
            const destinatario = usuarios.find(u => u.Usuario.includes(numeroDestino));

            if (!remitente) {
                 await EnviarRespuestaFalsa('❌ No estás registrado en el bot.', m);
                 return;
            }

            if (!destinatario) {
                await EnviarRespuestaFalsa('❌ El usuario no está registrado en el bot.', m);
                return;
            }

            if (remitente.Moneda < cantidad) {
                await EnviarRespuestaFalsa(`❌ No tienes suficientes monedas para hacer esta transferencia. Tienes: ${remitente.Moneda} monedas.`, m);
                return;
            }

            remitente.Moneda -= cantidad;
            destinatario.Moneda += cantidad;

            fs.writeFileSync(dbPath, JSON.stringify(usuarios, null, 2));

            await EnviarRespuestaFalsa(`✅ Transferencia exitosa.\n\nSe han transferido *${cantidad} monedas*.\n\nTu nuevo saldo es: *${remitente.Moneda} monedas*.`, m);

        } catch (error) {
            console.error('Error al ejecutar el comando de transferencia de monedas:', error);
            await EnviarRespuestaFalsa('❌ Ocurrió un error al procesar la transferencia. Inténtalo de nuevo más tarde.', m);
        }
    }
};
