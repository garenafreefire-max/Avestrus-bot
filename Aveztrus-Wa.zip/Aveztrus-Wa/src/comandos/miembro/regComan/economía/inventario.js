const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'inventario',
    descripcion: 'Muestra tu saldo actual de monedas, diamantes y tus ítems activos.',
    comando: ['inventario', 'items', 'inv', 'saldo', 'balance', 'bal'],
    ejecutar: async (ctx) => {
        const { responderTexto, userJid, config } = ctx; 
        
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');

        try {
            const data = await fs.readFile(dbPath, 'utf8');
            const usuariosRegistrados = JSON.parse(data);
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);

            if (!usuario) {
                return responderTexto(`❌ No estás registrado. Usa el comando *${config.prefijo}reg* para crear un perfil.`);
            }

            // Asegurar que los campos existen
            const monedas = usuario.Moneda || 0;
            const banco = usuario.Banco || 0;
            const diamantes = usuario.Diamante || 0;
            
            // Asegurar que Inventario existe
            if (!usuario.Inventario) usuario.Inventario = {}; 

            // --- Estado del Escudo (Protección por USOS) ---
            const usosEscudo = usuario.Inventario.Escudo || 0;
            let escudoInfo = usosEscudo > 0 ? 
                             `✅ Posees *${usosEscudo}* usos restantes.` : 
                             '❌ No posees';

            // --- Estado del HackerKit (Ataque) ---
            const tieneHackerKit = usuario.Inventario.HackerKit > 0;
            const hackerKitInfo = tieneHackerKit ? `✅ Posees *${usuario.Inventario.HackerKit}* kits.` : '❌ No posees';
            
            let mensaje = `\n╭━━━〔 🎒 *Tu Inventario* 〕━━━╮\n┃\n┃ *💰 Saldo y Dinero*\n┃ 🪙 En Mano: *${monedas}* monedas\n┃ 🏦 En Banco: *${banco}* monedas\n┃ 💎 Diamantes: *${diamantes}*\n┃\n┃ *🛡️ Items de Protección*\n┃ Escudo Antirrobo: *${escudoInfo}*\n┃\n┃ *💻 Items de Ataque*\n┃ Kit Hacker: *${hackerKitInfo}*\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n`;
            
            await responderTexto(mensaje);

        } catch (error) {
            console.error('Error en comando inventario:', error);
            await responderTexto('❌ Ocurrió un error al mostrar el inventario.');
        }
    }
};
