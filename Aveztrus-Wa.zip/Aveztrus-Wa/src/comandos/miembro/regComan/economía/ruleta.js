const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'ruleta',
    descripcion: 'Apuesta tus monedas en la ruleta. Gana hasta x4 o pierde todo.',
    comando: ['ruleta'],
    ejecutar: async (ctx) => {
        // 🚨 CAMBIO: Se usa 'responderTexto' en lugar de 'ResponderTextoFalso'
        const { responderTexto, reaccionarMensaje, userJid, myCache, args, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        const cooldownKey = `ruleta_${userJid}`;
        const cooldownTime = 30;
        
        const lastUsed = myCache.get(cooldownKey);
        if (lastUsed) {
            const timeLeft = cooldownTime - (Date.now() - lastUsed) / 1000;
            // 🚨 CAMBIO
            return responderTexto(`⏳ Tienes que esperar *${timeLeft.toFixed(0)} segundos* para volver a apostar.`);
        }

        if (args.length === 0) {
            // 🚨 CAMBIO
            return responderTexto(`❌ Debes especificar la cantidad de monedas a apostar. Ejemplo: *${config.prefijo}ruleta 100*`);
        }
        
        const apuesta = parseInt(args[0]);
        if (isNaN(apuesta) || apuesta <= 0) {
            // 🚨 CAMBIO
            return responderTexto('❌ La cantidad a apostar debe ser un número válido y mayor que cero.');
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                // 🚨 CAMBIO
                return responderTexto('❌ No hay usuarios registrados. Usa $reg para registrarte.');
            }
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);
            if (!usuario) {
                // 🚨 CAMBIO
                return responderTexto('❌ Debes estar registrado para apostar. Usa *$reg* para registrarte.');
            }
            
            if (usuario.Moneda < apuesta) {
                // 🚨 CAMBIO
                return responderTexto(`❌ No tienes suficientes monedas para apostar *${apuesta}*. Tienes *${usuario.Moneda}* monedas.`);
            }

            let probX4 = 0.05;
            let probX3 = 0.25;
            let probX2 = 0.30;
            let probX1 = 0.20;
            let probX0 = 0.20;

            const factorDificultad = Math.min(apuesta / 5000, 1);
            
            const reduccionGanancia = 0.50 * factorDificultad;
            const aumentoPerdida = 0.50 * factorDificultad;
            
            probX4 = Math.max(0, probX4 - (0.02 * factorDificultad));
            probX3 = Math.max(0, probX3 - (0.10 * factorDificultad));
            probX2 = Math.max(0, probX2 - (0.15 * factorDificultad));
            probX1 = Math.max(0, probX1 - (0.10 * factorDificultad));
            probX0 = probX0 + aumentoPerdida;

            const sumaProb = probX4 + probX3 + probX2 + probX1 + probX0;
            probX0 += 1 - sumaProb;

            const resultado = Math.random();
            let mensaje = '';
            let emoji = '';
            let ganancia = 0;
            
            if (resultado < probX0) {
                // Verificar si tiene escudo activo
                if (usuario.Escudo && usuario.Escudo.activo && Date.now() < usuario.Escudo.fin) {
                    // 70% de probabilidad de que el escudo funcione
                    if (Math.random() < 0.7) {
                        mensaje = `🛡️ ¡Escudo activo! Perdiste pero te salvaste gracias a tu escudo.\nHas perdido *0* monedas de tu apuesta.`;
                        emoji = '🛡️';
                    } else {
                        ganancia = -apuesta;
                        usuario.Moneda += ganancia;
                        mensaje = `💔 ¡Perdiste! La ruleta cayó en *x0*\nHas perdido *${apuesta}* monedas.\n💡 Tu escudo no funcionó esta vez.`;
                        emoji = '💔';
                    }
                } else {
                    ganancia = -apuesta;
                    usuario.Moneda += ganancia;
                    mensaje = `💔 ¡Perdiste! La ruleta cayó en *x0*\nHas perdido *${apuesta}* monedas.`;
                    emoji = '💔';
                }
            } else if (resultado < probX0 + probX1) {
                ganancia = 0;
                mensaje = `🤝 ¡Casi! La ruleta cayó en *x1* 🤝\nHas recuperado tu apuesta, no ganas ni pierdes.\nTu total es de *${usuario.Moneda}* monedas.`;
                emoji = '🤝';
            } else if (resultado < probX0 + probX1 + probX2) {
                ganancia = apuesta * 2;
                usuario.Moneda += ganancia;
                mensaje = `💰 ¡Bien hecho! La ruleta cayó en *x2* 💰\nHas ganado *${ganancia}* monedas.\nTu nuevo total es de *${usuario.Moneda}* monedas.`;
                emoji = '💰';
            } else if (resultado < probX0 + probX1 + probX2 + probX3) {

                ganancia = apuesta * 3;
                usuario.Moneda += ganancia;
                mensaje = `🥳 ¡Suerte! La ruleta cayó en *x3* 🥳\nHas ganado *${ganancia}* monedas.\nTu nuevo total es de *${usuario.Moneda}* monedas.`;
                emoji = '🥳';
            } else {
                ganancia = apuesta * 4;
                usuario.Moneda += ganancia;
                mensaje = `🎉 ¡Increíble! La ruleta cayó en *x4* 🎉\nHas ganado *${ganancia}* monedas.\nTu nuevo total es de *${usuario.Moneda}* monedas.`;
                emoji = '🎉';
            }
            
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
            myCache.set(cooldownKey, Date.now(), cooldownTime);

            // 🚨 CAMBIO
            await responderTexto(mensaje);
            await reaccionarMensaje(emoji);

        } catch (error) {
            console.error('Error en el comando ruleta:', error);
            // 🚨 CAMBIO
            await responderTexto('❌ Ocurrió un error al intentar jugar a la ruleta.');
        }
    }
};
