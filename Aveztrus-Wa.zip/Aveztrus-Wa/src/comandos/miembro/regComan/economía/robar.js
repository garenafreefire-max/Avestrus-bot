const path = require('path');
const fs = require('fs').promises;

const mensajes = {
    exito: [
        '¡Le has robado *{cantidad}* monedas a *@{victima}*!',
        'Lograste escapar de la policía con *{cantidad}* monedas de *@{victima}*.',
        '¡Golpe de suerte! Le quitaste *{cantidad}* monedas a *@{victima}*.'
    ],
    atrapado: [
        '🚓 ¡La policía te atrapó! Pagaste una multa de *{cantidad}* monedas y *@{victima}* se fue a salvo.',
        '😭 Fuiste descubierto robando a *@{victima}* y pagaste *{cantidad}* monedas de multa.',
        '❌ El intento de robo a *@{victima}* falló. Tuviste que pagar *{cantidad}* monedas.'
    ],
    // 🚨 NUEVO: Mensajes para el escudo
    escudo: [
        '🛡️ ¡Robo fallido! El escudo de *@{victima}* se activó.',
        '🚔 El sistema de seguridad de *@{victima}* detectó el intento. ¡Era el escudo!',
        '🚨 ¡Alto! *@{victima}* fue protegido por su Escudo Antirrobo.'
    ]
};

const obtenerMensajeAleatorio = (lista, cantidad, victimaJid) => {
    const victimaNumero = victimaJid.split('@')[0];
    let mensaje = lista[Math.floor(Math.random() * lista.length)];
    return mensaje.replace('{cantidad}', cantidad).replace('{victima}', victimaNumero);
};


module.exports = {
    nombre: 'robar',
    descripcion: 'Roba monedas de un usuario, ten cuidado o serás multado. Ejemplo: $robar @usuario',
    comando: ['robar', 'atraco'],
    ejecutar: async (ctx) => {
        const { responderTexto, userJid, myCache, args, menciones, config, quotedMsg } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        const cooldownKey = `robar_${userJid}`;
        const cooldownTime = 27; // Tiempo de espera en segundos
        
        const lastUsed = myCache.get(cooldownKey);
        if (lastUsed) {
            const timeLeft = cooldownTime - (Date.now() - lastUsed) / 1000;
            return responderTexto(`😴 ¡Estás agotado! Tienes que esperar *${timeLeft.toFixed(0)} segundos* para recuperar energías y volver a robar.`);
        }

        let victimaJid;
        if (menciones && menciones.length > 0) {
            victimaJid = menciones[0];
        } else if (quotedMsg) {
            victimaJid = quotedMsg.participant;
        }

        if (!victimaJid) {
            return responderTexto(`❌ Debes mencionar o responder al mensaje del usuario que quieres robar.`);
        }
        if (victimaJid === userJid) {
            return responderTexto('❌ No puedes robarte a ti mismo, ¿qué clase de atraco es ese?');
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return responderTexto('❌ No hay usuarios registrados.');
            }
            
            const usuarioLadron = usuariosRegistrados.find(u => u.Usuario === userJid);
            const usuarioVictima = usuariosRegistrados.find(u => u.Usuario === victimaJid);

            if (!usuarioLadron) {
                return responderTexto(`❌ No estás registrado. Usa el comando *${config.prefijo}reg* para crear un perfil.`);
            }

            if (!usuarioVictima) {
                return responderTexto(`❌ El usuario *${victimaJid.split('@')[0]}* no está registrado.`);
            }
            
            // Asegurar que el Inventario existe
            if (!usuarioVictima.Inventario) usuarioVictima.Inventario = {};

            // --- 🚨 NUEVO: Verificar si la víctima tiene usos de Escudo ---
            const usosEscudo = usuarioVictima.Inventario.Escudo || 0;
            
            if (usosEscudo > 0) {
                // 1. Consumir un uso del escudo
                usuarioVictima.Inventario.Escudo -= 1;
                
                // 2. Guardar el cambio en la base de datos
                await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
                
                // 3. Aplicar cooldown al ladrón
                myCache.set(cooldownKey, Date.now(), cooldownTime);
                
                // 4. Enviar mensaje de bloqueo y usos restantes
                const mensajeBloqueo = obtenerMensajeAleatorio(mensajes.escudo, 0, victimaJid);
                const mensajeCompleto = `${mensajeBloqueo}\n🛡️ Usos restantes: *${usuarioVictima.Inventario.Escudo}*`;
                
                return responderTexto(mensajeCompleto, [victimaJid]);
            }
            
            // --- LÓGICA DE ROBO NORMAL (continúa aquí) ---
            
            const usarHackerKit = args.length > 1 && args[1].toLowerCase() === 'kit';
            const tieneHackerKit = (usuarioLadron.Inventario && usuarioLadron.Inventario.HackerKit > 0);
            
            // ... (El resto de la lógica de robo normal y hacker kit)
            
            // Si el ladrón usa el kit, lo consume y el robo va directo al banco
            if (usarHackerKit && tieneHackerKit) {
                
                // 1. Consumir el Kit Hacker
                usuarioLadron.Inventario.HackerKit -= 1;
                
                // 2. Determinar el dinero robado del banco
                const dineroDisponibleBanco = usuarioVictima.Banco || 0;
                const porcentajeRobo = Math.random() * (0.40) + 0.10; // 10% a 50%
                let cantidadRobada = Math.floor(dineroDisponibleBanco * porcentajeRobo);
                
                cantidadRobada = Math.min(cantidadRobada, dineroDisponibleBanco);
                
                if (cantidadRobada === 0) {
                     await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
                     myCache.set(cooldownKey, Date.now(), cooldownTime);
                     return responderTexto(`💻 ¡Hackeo Exitoso, pero *${usuarioVictima.Nombre}* no tenía dinero en el banco!`);
                }
                
                // 3. Realizar la transferencia
                usuarioVictima.Banco -= cantidadRobada;
                usuarioLadron.Moneda += cantidadRobada; // El dinero robado va a la mano del ladrón
                
                await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
                myCache.set(cooldownKey, Date.now(), cooldownTime);

                return responderTexto(
                    `💻 ¡Hackeo Exitoso!\\n` +
                    `Le has robado *${cantidadRobada}* monedas del banco a *${usuarioVictima.Nombre}*.\\n\\n` +
                    `*Kits restantes:* ${usuarioLadron.Inventario.HackerKit || 0}`, 
                    [victimaJid]
                );
            }
            
            // --- LÓGICA DE ROBO NORMAL (SIN KIT HACKER) ---

            const dineroDisponibleMano = usuarioVictima.Moneda || 0;

            if (dineroDisponibleMano === 0) {
                return responderTexto(`🧐 ¡No intentes robar! *${usuarioVictima.Nombre}* no tiene monedas en la mano.`);
            }

            // Probabilidad de éxito: 40% (0.4)
            const PROBABILIDAD_EXITO = 0.4;
            const probabilidad = Math.random();

            if (probabilidad < PROBABILIDAD_EXITO) {
                // --- ÉXITO / ROBO ---
                const cantidadRobada = Math.floor(Math.random() * (dineroDisponibleMano * 0.5)) + 1; // Roba hasta el 50%
                
                const cantidadFinalRobada = Math.min(cantidadRobada, dineroDisponibleMano);

                usuarioVictima.Moneda -= cantidadFinalRobada;
                usuarioLadron.Moneda += cantidadFinalRobada;

                await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
                myCache.set(cooldownKey, Date.now(), cooldownTime);

                return responderTexto(obtenerMensajeAleatorio(mensajes.exito, cantidadFinalRobada, victimaJid), [victimaJid]);

            } else {
                // --- FRACASO / ATRAPADO ---
                const multa = Math.floor(Math.random() * 200) + 100; // Multa de 100 a 300
                const multaFinal = Math.min(multa, usuarioLadron.Moneda);

                usuarioLadron.Moneda -= multaFinal;
                if (usuarioLadron.Moneda < 0) usuarioLadron.Moneda = 0; // Asegurar que no sea negativo
                
                await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
                myCache.set(cooldownKey, Date.now(), cooldownTime);

                return responderTexto(obtenerMensajeAleatorio(mensajes.atrapado, multaFinal, victimaJid), [victimaJid]);
            }

        } catch (error) {
            console.error('Error en el comando robar:', error);
            await responderTexto('❌ Ocurrió un error inesperado al intentar robar. Inténtalo de nuevo más tarde.');
        }
    }
};
