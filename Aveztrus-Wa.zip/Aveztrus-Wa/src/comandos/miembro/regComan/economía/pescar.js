const fs = require('fs').promises;
const path = require('path');

module.exports = {
    nombre: 'pescar',
    descripcion: 'Ve a pescar y gana monedas.',
    comando: ['pescar'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid, myCache, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', '..', '..', 'database', 'UserReg.json');
        
        // Cooldown de 5 minutos (300 segundos)
        const cooldownKey = `pescar_${userJid}`;
        const cooldownTime = 300; 
        
        const lastUsed = myCache.get(cooldownKey);
        if (lastUsed) {
            const timeLeft = cooldownTime - (Date.now() - lastUsed) / 1000;
            const minutos = Math.floor(timeLeft / 60);
            const segundos = Math.floor(timeLeft % 60);
            return ResponderTextoFalso(`⏳ El mar está agitado. Vuelve a pescar en *${minutos}m ${segundos}s*.`);
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (readError) {
                return ResponderTextoFalso('❌ No hay usuarios registrados.');
            }
            
            const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);

            if (!usuario) {
                return ResponderTextoFalso(`❌ No estás registrado. Usa el comando *${config.prefijo}reg* para crear un perfil.`);
            }

            // Probabilidades de pesca
            const resultados = [
                { nombre: 'pez común', emoji: '🐟', ganancia: 50, probabilidad: 0.5 }, // 50%
                { nombre: 'pez raro', emoji: '🐠', ganancia: 150, probabilidad: 0.25 }, // 25%
                { nombre: 'pez legendario', emoji: '🐡', ganancia: 500, probabilidad: 0.05 }, // 5%
                { nombre: 'basura', emoji: '🗑️', ganancia: -25, probabilidad: 0.15 }, // 15% (pierde monedas)
                { nombre: 'nada', emoji: '🤷‍♂️', ganancia: 0, probabilidad: 0.05 } // 5%
            ];

            let resultadoFinal = null;
            let random = Math.random();
            let acumulado = 0;

            for (const resultado of resultados) {
                acumulado += resultado.probabilidad;
                if (random < acumulado) {
                    resultadoFinal = resultado;
                    break;
                }
            }
            
            usuario.Moneda += resultadoFinal.ganancia;
            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2));
            myCache.set(cooldownKey, Date.now(), cooldownTime);

            let mensaje = `🎣 ¡Lanzaste tu caña!\n\n`;
            if (resultadoFinal.ganancia > 0) {
                mensaje += `¡Has pescado un *${resultadoFinal.nombre}* ${resultadoFinal.emoji} y ganaste *${resultadoFinal.ganancia}* monedas!`;
            } else if (resultadoFinal.ganancia < 0) {
                mensaje += `¡Solo pescaste *${resultadoFinal.nombre}* ${resultadoFinal.emoji} y perdiste *${Math.abs(resultadoFinal.ganancia)}* monedas.`;
            } else {
                mensaje += `¡No pescaste nada! ${resultadoFinal.emoji}`;
            }

            mensaje += `\n\n*Monedas actuales:* ${usuario.Moneda}`;
            await ResponderTextoFalso(mensaje);

        } catch (error) {
            console.error('Error en el comando pescar:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al intentar pescar.');
        }
    }
};
