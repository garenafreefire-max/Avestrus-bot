const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

module.exports = {
  nombre: 'sticker-text2',
  descripcion: 'Crea un sticker de texto negro en cuadro blanco con ajuste automático.',
  comando: ['st2', 'stickertext2'],
  ejecutar: async (ctx) => {
    const { args, m, responderTexto, EnviarStickerFalso, config } = ctx;

    try {
      // 1. Obtener texto
      let texto = '';
      const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

      if (quoted && (quoted.conversation || quoted.extendedTextMessage?.text)) {
        texto = quoted.conversation || quoted.extendedTextMessage?.text;
      } else if (args.length > 0) {
        texto = args.join(' ');
      } else {
        return responderTexto(`⚠️ Uso incorrecto:\n\n ${config.prefijo}st2 [texto] o cita un mensaje con texto`);
      }

      if (texto.length > 300) texto = texto.substring(0, 300) + '...';

      // 2. Dividir en líneas de máx 15–20 caracteres
      const words = texto.split(' ');
      let lines = [];
      let currentLine = '';

      words.forEach(word => {
        if ((currentLine + ' ' + word).trim().length > 18) {
          lines.push(currentLine.trim());
          currentLine = word;
        } else {
          currentLine += ' ' + word;
        }
      });
      if (currentLine) lines.push(currentLine.trim());

      // 3. Ajustar tamaño de fuente según cantidad de líneas
      let fontSize = 48;
      if (lines.length > 3) fontSize = 42;
      if (lines.length > 5) fontSize = 36;
      if (lines.length > 7) fontSize = 28;
      if (lines.length > 10) fontSize = 22;

      // 4. Crear líneas SVG con <tspan>
      const textLinesSvg = lines
        .map((line, i) => `<tspan x="50%" dy="${i === 0 ? 0 : 1.2}em">${line}</tspan>`)
        .join('\n');

      // 5. Rutas
      const tempDir = path.join(__dirname, '../../media/temp/stickers');
      if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

      const timestamp = Date.now();
      const svgPath = path.join(tempDir, `st2_${timestamp}.svg`);
      const pngPath = path.join(tempDir, `st2_${timestamp}.png`);
      const stickerPath = path.join(tempDir, `st2_${timestamp}.webp`);

      // 6. Cargar plantilla
      const xmlFilePath = path.join(__dirname, '../../media/imagenes/xml/st2.xml');
      if (!fs.existsSync(xmlFilePath)) {
        return responderTexto('❌ Archivo de plantilla (st2.xml) no encontrado.');
      }

      const xmlTemplate = fs.readFileSync(xmlFilePath, 'utf8');
      const svgCode = xmlTemplate
        .replace(/{{TEXT_LINES}}/g, textLinesSvg)
        .replace(/{{FONT_SIZE}}/g, fontSize);

      fs.writeFileSync(svgPath, svgCode);

      // 7. Convertir SVG → PNG
      execSync(`rsvg-convert -w 512 -h 512 "${svgPath}" -o "${pngPath}"`);

      // 8. PNG → WEBP
      execSync(
        `ffmpeg -y -i "${pngPath}" -vf "scale=512:512:force_original_aspect_ratio=increase,crop=512:512" -vcodec libwebp -lossless 1 -preset picture -an -vsync 0 "${stickerPath}"`
      );

      // 9. Enviar
      await EnviarStickerFalso(m, stickerPath, false);

      // 10. Limpiar
      setTimeout(() => {
        [svgPath, pngPath, stickerPath].forEach(f => {
          if (fs.existsSync(f)) fs.unlinkSync(f);
        });
      }, 20000);

    } catch (error) {
      console.error('Error en st2.js:', error);
      await responderTexto('❌ Ocurrió un error al crear el sticker st2.');
    }
  }
};