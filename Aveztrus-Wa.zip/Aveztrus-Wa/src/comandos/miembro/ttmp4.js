const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

module.exports = {
    nombre: 'ttmp4',
    descripcion: 'Descarga videos de TikTok sin marca de agua',
    comando: ['tt', 'tiktok', 'ttdl'],
    ejecutar: async (ctx) => {
        const { args, responderTexto, config } = ctx;
        const url = args[0];

        // Validar que se proporcionó una URL
        if (!url) {
            return responderTexto(`❌ Por favor, envía un enlace de TikTok después del comando.\nEjemplo: ${config.prefijo}tt https://vm.tiktok.com/abcdef/`);
        }

        // Validación estricta de URLs de TikTok
        const tiktokRegex = /https?:\/\/(?:www\.|vm\.|vt\.)?tiktok\.com\/(?:@[\w.]+\/video\/\d+|\w+\/video\/\d+|t\/[\w-]+|\w+)/i;
        if (!tiktokRegex.test(url)) {
            return responderTexto('❌ Enlace inválido. Solo se permiten enlaces de TikTok.\nEjemplos válidos:\n• https://vm.tiktok.com/abcdef/\n• https://www.tiktok.com/@usuario/video/123456789');
        }

        const tempDir = path.join(__dirname, '..', '..', 'media', 'temp', 'video');
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }

        const timestamp = new Date().getTime();
        const outputPath = path.join(tempDir, `tt_${timestamp}.mp4`);

        // Comando optimizado para TikTok
        const command = `yt-dlp -f "best[ext=mp4]" -o "${outputPath}" --no-playlist --quiet "${url}"`;

        try {
            // Mostrar estado de descarga
            await responderTexto('⏳ Descargando video de TikTok...');

            // Ejecutar yt-dlp con timeout
const result = await new Promise((resolve) => {
    let stderr = '';
    const child = exec(command, { timeout: 60000 });
    
    child.stderr.on('data', (data) => {
        stderr += data.toString();
    });
    
    child.on('exit', (code) => {
        resolve({ code, stderr });
    });
    
    child.on('error', (err) => {
        console.error('Error en ejecución:', err);
        resolve({ code: 1, stderr: err.message });
    });
});

if (result.code !== 0) {
    console.error('yt-dlp stderr:', result.stderr);
    throw new Error(`yt-dlp failed: ${result.stderr}`);
}

            // Verificar si el archivo se descargó correctamente
            if (!fs.existsSync(outputPath) || fs.statSync(outputPath).size === 0) {
                throw new Error('El archivo descargado está vacío o no existe');
            }

            // Enviar el video
            await ctx.EnviarVideoFalsa(fs.readFileSync(outputPath), 'Video de TikTok - Descargado por ' + ctx.config.NombreBot);
            
            // Eliminar el archivo temporal
            fs.unlinkSync(outputPath);

        } catch (error) {
            console.error('❌ Error en comando tiktok:', error);
            
            // Manejar errores específicos
            let mensajeError = '❌ Error al descargar el video.';
            
            if (error.message.includes('timeout')) {
                mensajeError = '⌛ Tiempo de espera agotado. Intenta con otro video.';
            } else if (error.message.includes('Unsupported URL') || error.message.includes('not a valid URL')) {
                mensajeError = '⚠️ Enlace no soportado. Asegúrate que sea un video de TikTok público.';
            } else if (error.message.includes('El archivo descargado está vacío')) {
                mensajeError = '⚠️ El video se descargó vacío. Intenta con otro enlace.';
            }
            
            await responderTexto(mensajeError);
            
            // Limpiar archivo temporal si existe
            if (fs.existsSync(outputPath)) {
                fs.unlinkSync(outputPath);
            }
        }
    }
};