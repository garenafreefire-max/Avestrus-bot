module.exports = {
  nombre: 'qr',
  descripcion: 'Genera un código QR a partir de un texto o enlace o lo que tú pongas.',
  comando: ['qr', 'qrcode'],
  ejecutar: async (ctx) => {
    const { args, EnviarRespuestaFalsa, EnviarFotoFalsa } = ctx;
    try {
      if (!args[0]) {
        return await EnviarRespuestaFalsa(
          '⚠️ *Uso incorrecto:*\n\n' +
          '📌 *Ejemplo:*\n' +
          '`,qr https://ejemplo.com`\n\n' +
          '🧾 *Descripción:*\nGenera un código QR a partir del texto o URL que indiques.'
        );
      }

      const texto = encodeURIComponent(args.join(' '));
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${texto}`;

      await EnviarFotoFalsa(qrUrl, `✅ *Código QR generado para:*\n${args.join(' ')}`);

    } catch (error) {
      console.error('Error en el comando qr:', error);
      await EnviarRespuestaFalsa('❌ *Error:* No se pudo generar el código QR.');
    }
  }
};