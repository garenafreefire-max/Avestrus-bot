const path = require('path');
const fs = require('fs');

module.exports = {
    nombre: 'waifu',
    descripcion: 'Envía imágenes aleatorias de waifus',
    comando: ['waifu', 'w2d', 'animegirl'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, EnviarFotoFalsa } = ctx;

        try {
            const waifuPath = path.join(__dirname, '..', '..', 'media', 'imagenes', 'waifus');
            
            // Verificar si la carpeta existe
            if (!fs.existsSync(waifuPath)) {
                await ResponderTextoFalso('❌ La carpeta de waifus no existe. Contacta al desarrollador.');
                return;
            }

            // Obtener todos los archivos de imagen de la carpeta
            const archivos = fs.readdirSync(waifuPath).filter(archivo => {
                const extension = path.extname(archivo).toLowerCase();
                return ['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(extension);
            });

            // Verificar si hay imágenes disponibles
            if (archivos.length === 0) {
                await ResponderTextoFalso('❌ No hay imágenes de waifus disponibles en la carpeta.');
                return;
            }

            // Seleccionar una imagen aleatoria
            const imagenAleatoria = archivos[Math.floor(Math.random() * archivos.length)];
            const rutaImagen = path.join(waifuPath, imagenAleatoria);

            // Verificar que la imagen existe antes de enviarla
            if (!fs.existsSync(rutaImagen)) {
                await ResponderTextoFalso('❌ Error al acceder a la imagen seleccionada.');
                return;
            }

            // Mensajes aleatorios para acompañar la imagen
            const mensajes = [
                '🌸 Aquí tienes una waifu especial para ti',
                '✨ Una hermosa waifu apareció',
                '🎀 Tu waifu del día ha llegado',
                '💫 Disfruta de esta adorable waifu',
                '🌺 Una waifu muy kawaii para alegrar tu día',
                '🦋 Esta waifu quiere ser tu compañía',
                '🎭 Una waifu perfecta acaba de aparecer',
                '🌙 Tu waifu nocturna está aquí'
            ];

            const mensajeAleatorio = mensajes[Math.floor(Math.random() * mensajes.length)];

            // Enviar la imagen con mensaje aleatorio
            await EnviarFotoFalsa(rutaImagen, mensajeAleatorio);

        } catch (error) {
            console.error('Error en comando waifu:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al buscar la waifu. Intenta nuevamente.');
        }
    }
};