const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

module.exports = {
  nombre: 'rotate',
  descripcion: 'Rota la imagen al ángulo que le des.',
  comando: ['rotate'],
  ejecutar: async (ctx) => {
    const { m, args, ResponderTextoFalso, EnviarFotoFalsa, config } = ctx;

    const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const esRespuestaImagen = quoted?.imageMessage || quoted?.stickerMessage;

    if (!esRespuestaImagen) {
      await ResponderTextoFalso('❌ Debes responder a una imagen para usar este comando.');
      return;
    }
    
    if (!args || args.length === 0 || isNaN(parseInt(args[0]))) {
      await ResponderTextoFalso(`❌ Debes especificar un ángulo de rotación.\n\nEjemplo: ${config.prefijo}rotate 90`);
      return;
    }

    try {
      await ResponderTextoFalso('⚙️ Procesando imagen...');
      const angle = parseInt(args[0]);
      const tempDir = path.join(__dirname, '../../media/temp/imagenes');
      const inputFile = path.join(tempDir, `${uuidv4()}_input.jpg`);
      const outputFile = path.join(tempDir, `${uuidv4()}_output.jpg`);
      
      const stream = await downloadContentFromMessage(quoted.imageMessage || quoted.stickerMessage, 'image');
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
      fs.writeFileSync(inputFile, buffer);
      
      const command = `convert "${inputFile}" -rotate ${angle} "${outputFile}"`;

      exec(command, async (error) => {
        if (error) {
          console.error(`Error de ImageMagick: ${error.message}`);
          await ResponderTextoFalso('❌ Hubo un error al procesar la imagen. Asegúrate de que ImageMagick esté instalado correctamente.');
        } else {
          await EnviarFotoFalsa(outputFile, '✅ Imagen procesada con éxito.');
        }
        fs.unlinkSync(inputFile);
        if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
      });
    } catch (error) {
      console.error('Error al manipular la imagen:', error);
      await ResponderTextoFalso('❌ Hubo un error inesperado al procesar la imagen.');
    }
  }
};