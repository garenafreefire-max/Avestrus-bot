module.exports = {
    comando: ['ge'],
    descripcion: 'Controla si Géminis responde en chats privados o grupos. Usa 1 = Privados+Grupos, 0 = Solo Grupos, 2 = Apagar por completo.',
    async ejecutar(ctx) {
        const { args, responderTexto, config, guardarConfig, recargarConfig } = ctx;

        if (args.length === 0) {
            let estado = '❌ Apagado';
            if (config.geminiGroup === true) estado = '✅ Privados + Grupos';
            else if (config.geminiGroup === false) estado = '✅ Solo Grupos';
            return responderTexto(
                `*⚠️ Uso correcto:* ${config.prefijo}ge <1|0|2>\n\n` +
                `1 = Activar en privados + grupos\n` +
                `0 = Solo grupos (desactivar privados)\n` +
                `2 = Apagar completamente\n\n` +
                `*Estado actual:* ${estado}`
            );
        }

        const estado = args[0];

        if (estado === '1') {
            config.geminiGroup = true;
            if (guardarConfig(config)) {
                recargarConfig();
                await responderTexto(`✅ Géminis ahora responderá en *privados y grupos* con mención.`);
            } else {
                await responderTexto('❌ Error al guardar la configuración.');
            }
        } else if (estado === '0') {
            config.geminiGroup = false;
            if (guardarConfig(config)) {
                recargarConfig();
                await responderTexto(`❌ Géminis ahora solo responderá en *grupos con mención*. Se desactivó en privados.`);
            } else {
                await responderTexto('❌ Error al guardar la configuración.');
            }
        } else if (estado === '2') {
            config.geminiGroup = 'apagado';
            if (guardarConfig(config)) {
                recargarConfig();
                await responderTexto(`🚫 Géminis ha sido *apagado completamente*. No responderá en ningún chat.`);
            } else {
                await responderTexto('❌ Error al guardar la configuración.');
            }
        } else {
            await responderTexto(`❌ Opción inválida. Usa '1', '0' o '2'.`);
        }
    }
};