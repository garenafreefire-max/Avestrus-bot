const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

module.exports = {
  nombre: 'mixemoji',
  descripcion: 'Mezcla dos emojis.',
  comando: ['mixemoji'],
  ejecutar: async (ctx) => {
    const { m, args, ResponderTextoFalso, EnviarFotoFalsa, config } = ctx;
    
    if (args.length !== 2) {
      await ResponderTextoFalso(`❌ Debes proporcionar dos emojis para mezclar. Ejemplo: ${config.prefijo}mixemoji 😊😎`);
      return;
    }

    const emoji1 = args[0];
    const emoji2 = args[1];

    try {
      await ResponderTextoFalso('🪄 Mezclando tus emojis, por favor espera...');
      
      const API_URL = `https://emojimix.dev/api/${emoji1}/${emoji2}`;
      const response = await axios.get(API_URL, { responseType: 'arraybuffer' });
      
      const tempDir = path.join(__dirname, 'temp');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir);
      }
      const outputFilePath = path.join(tempDir, `${uuidv4()}_emoji.png`);
      fs.writeFileSync(outputFilePath, response.data);

      await EnviarFotoFalsa(outputFilePath, '✅ ¡Emojis mezclados con éxito!');
      fs.unlinkSync(outputFilePath);

    } catch (error) {
      console.error('Error al mezclar emojis:', error);
      await ResponderTextoFalso('❌ Ocurrió un error al procesar la solicitud. Asegúrate de que los emojis sean válidos.');
    }
  },
};