const { exec } = require('child_process');

module.exports = {
    nombre: 'ms',
    descripcion: 'Muestra la velocidad real de conexión del bot con Speedtest',
    comando: ['ms', 'ping', 'velocidad', 'internet'],
    ejecutar: async (ctx) => {
        const { EnviarRespuestaFalsa, responderTexto } = ctx;

        try {
            await EnviarRespuestaFalsa('📡 Ejecutando Speedtest, espera un momento...');

            exec('speedtest --secure --simple', async (error, stdout, stderr) => {
                if (error) {
                    console.error(`Error ejecutando speedtest: ${error}`);
                    return responderTexto('❌ Error al ejecutar Speedtest, verifica que esté instalado con:\n```pip install speedtest-cli```');
                }

                if (stderr) {
                    console.error(`Stderr de speedtest: ${stderr}`);
                }

                // Salida esperada:
                // Ping: 45.123 ms
                // Download: 92.56 Mbit/s
                // Upload: 10.23 Mbit/s
                const lines = stdout.trim().split('\n');
                let ping = 'Desconocido', download = 'Desconocido', upload = 'Desconocido';

                lines.forEach(line => {
                    if (line.startsWith('Ping')) ping = line.replace('Ping: ', '');
                    if (line.startsWith('Download')) download = line.replace('Download: ', '');
                    if (line.startsWith('Upload')) upload = line.replace('Upload: ', '');
                });

                const message = `
📶 *Speedtest Resultados*:

🕒 Ping: ${ping}
⬇️ Descarga: ${download}
⬆️ Subida: ${upload}

💻 Servidor: ${process.platform}
🌐 Red: ${parseFloat(download) > 20 ? 'Estable ✅' : 'Inestable ⚠️'}
                `.trim();

                await EnviarRespuestaFalsa(message);
            });

        } catch (error) {
            console.error('Error en comando ms:', error);
            await responderTexto('❌ Error al medir la velocidad de conexión');
        }
    }
};