const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'resetear',
    descripcion: 'Resetea toda la economía (solo dueño del bot)',
    comando: ['resetear', 'reseteconomia'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, userJid, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', 'database', 'UserReg.json');
        
        // Verificar si es dueño del bot
        if (!config.Dueño.includes(userJid) && !config.DueñoLid.includes(userJid)) {
            return ResponderTextoFalso('❌ Solo el dueño del bot puede usar este comando.');
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (error) {
                return ResponderTextoFalso('❌ Error al leer la base de datos.');
            }

            // Resetear economía de todos los usuarios
            usuariosRegistrados = usuariosRegistrados.map(usuario => ({
                ...usuario,
                Moneda: 0,
                Diamante: 0,
                Banco: 0,
                Escudo: { activo: false }
            }));

            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2), 'utf8');

            await ResponderTextoFalso('✅ *Economía reseteada completamente.* Todos los usuarios tienen 0 monedas, 0 diamantes y 0 en banco.');

        } catch (error) {
            console.error('Error en comando resetear:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al resetear la economía.');
        }
    }
};