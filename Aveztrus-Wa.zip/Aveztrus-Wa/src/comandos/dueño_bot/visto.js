module.exports = {
    nombre: 'visto',
    descripcion: 'Activa o desactiva el marcado de mensajes como leídos (✓✓ azules).',
    comando: ['visto'],
    async ejecutar(ctx) {
        const { args, config, guardarConfig, recargarConfig, responderTexto } = ctx;

        if (args.length === 0) {
            return responderTexto('❌ Por favor, usa `.visto 1` para activar o `.visto 0` para desactivar.');
        }

        const estado = parseInt(args[0], 10);

        if (estado === 1) {
            config.visto = true;
            if (guardarConfig(config)) {
                recargarConfig();
                await responderTexto('✅ Los mensajes ahora se marcarán como leídos.');
            } else {
                await responderTexto('❌ Hubo un error al activar el visto. Revisa la consola.');
            }
        } else if (estado === 0) {
            config.visto = false;
            if (guardarConfig(config)) {
                recargarConfig();
                await responderTexto('❌ Los mensajes ya no se marcarán como leídos.');
            } else {
                await responderTexto('❌ Hubo un error al desactivar el visto. Revisa la consola.');
            }
        } else {
            await responderTexto('❌ Opción inválida. Usa `.visto 1` para activar o `.visto 0` para desactivar.');
        }
    },
};
