// chau.js

module.exports = {
    descripcion: 'Hace que el bot abandone el grupo actual.',
    comando: ['chau', 'salir'], 
    ejecutar: async (ctx) => {
        // Obtenemos las propiedades necesarias del contexto (ctx)
        // responderTexto ahora se usa SIN 'm'
        const { responderTexto, jid, sock, permisoUsuario, delay, config } = ctx;

        // 1. Seguridad: Verificación del permiso
        // La validación principal ya está hecha por la carpeta 'dueño_bot' en bot.js.
        if (permisoUsuario !== 'dueño_bot') {
            // Usamos responderTexto(texto)
            return responderTexto('⛔ Comando restringido. Solo el dueño del bot puede usar *chau*.');
        }

        // 2. Ejecutar la acción
        try {
            // **IMPORTANTE:** Si jid no termina en '@g.us', groupLeave fallará y será capturado.
            
            // Confirmación antes de salir usando ctx.config.NombreBot
            // Usamos responderTexto(texto)
            await responderTexto(`👋 ¡Adiós! *${config.NombreBot}* abandona el chat por solicitud del dueño.`);
            
            // Un pequeño delay para asegurar que el mensaje de despedida se envíe.
            await delay(1000); 

            // Ejecutar la acción de abandono (leave).
            // Si el JID es privado, esto fallará, lo cual es manejado en el catch.
            await sock.groupLeave(jid);
            
        } catch (error) {
            
            // 3. Manejo de Errores
            const esChatPrivado = !jid.endsWith('@g.us');
            
            if (esChatPrivado) {
                // Si falla porque no es un grupo, informamos de forma más limpia.
                console.log(`[CHAU] Intento de salir en chat privado de ${jid}.`);
                return responderTexto(`❌ *${config.NombreBot}* no puede abandonar un chat privado, pero ya he tomado nota.`);
            }

            // Manejar errores de permisos o inesperados en grupos.
            console.error(`Error al intentar salir del grupo ${jid}:`, error);
            
            try {
                // Usamos responderTexto(texto) para informar del fallo.
                await responderTexto('❌ Ocurrió un error al intentar salir del grupo. Revisa si el bot es administrador.');
            } catch (e) {
                // Fallback final
            }
        }
    }
};
