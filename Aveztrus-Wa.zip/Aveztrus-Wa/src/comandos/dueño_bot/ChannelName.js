const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '..', '..', 'config.json');

module.exports = {
  comando: ['canalnombre', 'namechanel'],
  descripcion: 'Cambia el nombre del canal para los mensajes falsos.',
  ejecutar: async (ctx) => {
    const { responderTexto, args, config, guardarConfig } = ctx;

    if (args.length === 0) {
      return responderTexto(`❌ Por favor, proporciona un nuevo nombre para el canal. Uso: *${config.prefijo}canalnombre [nuevo nombre]*`);
    }

    const nuevoNombre = args.join(' ');
    const oldName = config.ChannelName;
    
    config.ChannelName = nuevoNombre;
    
    if (guardarConfig(config)) {
      responderTexto(`✅ ¡Nombre del canal cambiado!
      
      *Antiguo nombre:* _${oldName}_
      *Nuevo nombre:* _${nuevoNombre}_`);
    } else {
      responderTexto('❌ Hubo un error al guardar la nueva configuración.');
    }
  }
};
