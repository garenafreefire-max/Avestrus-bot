const fs = require('fs');
const path = require('path');

module.exports = {
    comando: ['dardueño', 'addowner'],
    ejecutar: async (ctx) => {
        const { sock, m, responderTexto } = ctx;
        const mencionado = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

        if (!mencionado) {
            return responderTexto('⚠️ Debes mencionar a un usuario. Ejemplo: .dardueño @usuario');
        }

        const esLid = mencionado.endsWith('@lid');
        const campo = esLid ? 'DueñoLid' : 'Dueño';
        const formato = esLid ? 'LID' : 'normal';

        const configPath = path.join(__dirname, '..', '..', '..', 'config.json');
        
        let config;
        try {
            config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        } catch (error) {
            console.error('Error al leer config.json:', error);
            return responderTexto('❌ Error al leer la configuración.');
        }

        // Inicializar y asegurar que sea array
        if (!config[campo]) config[campo] = [];
        if (!Array.isArray(config[campo])) config[campo] = [config[campo]];

        // Verificar duplicados
        if (config[campo].includes(mencionado)) {
            return responderTexto(`⚠️ Este usuario ya es dueño (${formato}).`);
        }

        // Agregar nuevo dueño
        config[campo].push(mencionado);

        // Guardar cambios
        try {
            fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
        } catch (error) {
            console.error('Error al escribir config.json:', error);
            return responderTexto('❌ Error al guardar la configuración.');
        }

        // Recargar configuración
        ctx.recargarConfig();

        await responderTexto(`✅ ¡Nuevo dueño agregado (${formato})!`);
        
        // Notificar al nuevo dueño
        try {
            await sock.sendMessage(
                mencionado, 
                { text: `🎉 ¡Ahora eres dueño del bot ${config.NombreBot}!` }
            );
        } catch (error) {
            console.error('Error notificando al nuevo dueño:', error);
        }
    }
};