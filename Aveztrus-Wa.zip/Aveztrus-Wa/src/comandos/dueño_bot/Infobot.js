const path = require('path');
const { cambiarDescripcion } = require('../../system/InfoPerfil');
const config = require('../../../config.json');

module.exports = {
    nombre: 'infobot',
    descripcion: 'Cambia la descripción de tu bot.',
    comando: ['infobot'],
    ejecutar: async (ctx) => {
        const { m, args, sock, enviarTexto } = ctx;

        if (args.length === 0) {
            await enviarTexto(`❌ Debes especificar la nueva descripción. Ejemplo: *${config.prefijo}infobot Soy un bot de WhatsApp*`);
            return;
        }

        const nuevaDescripcion = args.join(' ');
        const cambioExitoso = await cambiarDescripcion(sock, nuevaDescripcion);

        if (cambioExitoso) {
            await enviarTexto(`✅ La descripción del bot se ha cambiado a: *${nuevaDescripcion}*`);
        } else {
            await enviarTexto('❌ Ocurrió un error al intentar cambiar la descripción del bot.');
        }
    }
};
