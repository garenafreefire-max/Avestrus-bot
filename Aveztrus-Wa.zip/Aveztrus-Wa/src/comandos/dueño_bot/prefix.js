const fs = require('fs');
const path = require('path');

module.exports = {
    nombre: 'prefijo',
    descripcion: 'Cambia el prefijo de los comandos del bot. (Solo dueño del bot)',
    comando: ['prefijo', 'prefix'],
    ejecutar: async (ctx) => {
        const { EnviarRespuestaFalsa, args, config, recargarConfig } = ctx;
        
        // Verifica si se proporcionó un nuevo prefijo
        if (args.length === 0) {
            return EnviarRespuestaFalsa(
                `❌ *Error de Sintaxis*\n\nUso correcto:\n${config.prefijo}prefijo [nuevo_prefijo]`
            );
        }

        const nuevoPrefijo = args[0];
        // Ruta corregida para tu estructura de directorios
        const configPath = path.join(__dirname, '..', '..', '..', 'config.json');

        try {
            // Leer el archivo de configuración actual
            const rawData = fs.readFileSync(configPath, 'utf8');
            const configData = JSON.parse(rawData);

            // Actualizar el prefijo
            configData.prefijo = nuevoPrefijo;

            // Guardar los cambios en el archivo
            fs.writeFileSync(configPath, JSON.stringify(configData, null, 4), 'utf8');

            // === Llama a la función de recarga ===
            recargarConfig();

            await EnviarRespuestaFalsa(
                `✅ *¡Prefijo Actualizado!*\n\nEl prefijo del bot se ha cambiado a: *${nuevoPrefijo}*\n\n`
            );
        } catch (error) {
            console.error('Error al cambiar el prefijo:', error);
            await EnviarRespuestaFalsa('❌ Ocurrió un error al intentar cambiar el prefijo.');
        }
    }
};
