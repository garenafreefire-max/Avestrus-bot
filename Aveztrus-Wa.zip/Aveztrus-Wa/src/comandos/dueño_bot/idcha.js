// comandos/miembro/idcha.js
const { URL } = require('url'); // Importa la clase URL para parsear enlaces

module.exports = {
    nombre: 'idcha',
    descripcion: 'Obtiene el ID y nombre de un canal de WhatsApp a partir de su enlace de invitación.',
    comando: ['idcha', 'channelinfo'], // Puedes usar.idcha o.channelinfo
    ejecutar: async (ctx) => {
        const { args, responderTexto, sock } = ctx;

        // Verifica si se proporcionó un enlace
        if (args.length === 0) {
            return responderTexto('Por favor, proporciona el enlace del canal. Ejemplo:.idcha https://whatsapp.com/channel/invite/ABCDEF123');
        }

        const link = args;
        let inviteCode = null;

        try {
            // Intenta parsear la URL para asegurar que es válida
            new URL(link);

            // Expresión regular para extraer el código de invitación de enlaces de canales o grupos de WhatsApp.
            // Los enlaces de canales de WhatsApp suelen tener un formato similar a los de grupo,
            // que incluyen un código de invitación al final. [2, 3, 4, 5, 6]
            const match = link.match(/(?:whatsapp\.com\/(?:channel\/invite|chat)\/|chat\.whatsapp\.com\/)([a-zA-Z0-9_-]+)/);
            if (match && match[1]) {
                inviteCode = match[1];
            }
        } catch (e) {
            console.error("Error al parsear la URL:", e);
            return responderTexto('El enlace proporcionado no es una URL válida. Asegúrate de que empiece con http:// o https://');
        }

        // Si no se pudo extraer el código de invitación
        if (!inviteCode) {
            return responderTexto('No se pudo extraer el código de invitación del enlace. Asegúrate de que sea un enlace de invitación de canal de WhatsApp válido.');
        }

        try {
            // Baileys se refiere a los canales como "newsletters" internamente.
            // Usamos sock.newsletterMetadata con el tipo "invite" y el código extraído. [7, 8]
            const metadata = await sock.newsletterMetadata("invite", inviteCode); [7, 8]

            // Verificamos que se haya obtenido la metadata y que contenga el ID y el nombre. [9]
            if (metadata && metadata.id && metadata.name) {
                const channelId = metadata.id; // El ID del canal (JID), por ejemplo, "12345@newsletter"
                const channelName = metadata.name;

                const responseMessage = `
*Información del Canal:*
*ID del Canal:* ${channelId}
*Nombre del Canal:* ${channelName}
                `;
                await responderTexto(responseMessage);
            } else {
                // Si la metadata es nula o no contiene la información esperada
                await responderTexto('No se pudo obtener la información del canal. El enlace podría ser inválido o el canal no existe.');
            }
        } catch (error) {
            console.error('Error al obtener metadatos del canal:', error);
            await responderTexto('Ocurrió un error al intentar obtener la información del canal. Asegúrate de que el enlace sea correcto y el bot tenga acceso.');
        }
    }
};
