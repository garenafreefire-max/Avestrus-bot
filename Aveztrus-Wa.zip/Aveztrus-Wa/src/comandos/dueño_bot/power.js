module.exports = {
    nombre: 'power',
    descripcion: 'Activa o desactiva el bot globalmente.',
    comando: ['power'],
    ejecutar: async (ctx) => {
        const { setBotStatus, responderTexto, args } = ctx;

        if (args.length === 0) {
            return responderTexto('❌ Por favor, usa `.power 1` para activar o `.power 0` para desactivar.');
        }

        const estado = parseInt(args[0], 10);
        
        if (estado === 1) {
            if (setBotStatus(null, true)) {
                await responderTexto('✅ El bot ha sido activado globalmente.');
            } else {
                await responderTexto('❌ Ocurrió un error al intentar activar el bot globalmente.');
            }
        } else if (estado === 0) {
            if (setBotStatus(null, false)) {
                await responderTexto('❌ El bot ha sido apagado globalmente.');
            } else {
                await responderTexto('❌ Ocurrió un error al intentar apagar el bot globalmente.');
            }
        } else {
            await responderTexto('❌ Opción inválida. Usa `.power 1` para activar o `.power 0` para desactivar.');
        }
    }
};
