const path = require('path');
const fs = require('fs').promises;

module.exports = {
    nombre: 'add',
    descripcion: 'Añade recursos a un usuario (solo dueño). Uso: $add tipo | cantidad | @usuario',
    comando: ['add'],
    ejecutar: async (ctx) => {
        const { ResponderTextoFalso, args, menciones, userJid, config } = ctx;
        const dbPath = path.join(__dirname, '..', '..', 'database', 'UserReg.json');
        
        // Verificar si es dueño del bot
        if (!config.Dueño.includes(userJid) && !config.DueñoLid.includes(userJid)) {
            return ResponderTextoFalso('❌ Solo el dueño del bot puede usar este comando.');
        }

        if (args.length < 2 || menciones.length === 0) {
            return ResponderTextoFalso(`❌ Formato incorrecto. Usa: *${config.prefijo}add tipo | cantidad | @usuario*`);
        }

        const tipo = args[0].toLowerCase();
        const cantidad = parseInt(args[1]);
        const usuarioDestino = menciones[0];

        if (!['m', 'd', 'b'].includes(tipo)) {
            return ResponderTextoFalso('❌ Tipo no válido. Usa: m (monedas), d (diamantes), b (banco)');
        }

        if (isNaN(cantidad) || cantidad <= 0) {
            return ResponderTextoFalso('❌ La cantidad debe ser un número mayor a 0.'); // CORRECCIÓN AQUÍ
        }

        try {
            let usuariosRegistrados = [];
            try {
                const data = await fs.readFile(dbPath, 'utf8');
                usuariosRegistrados = JSON.parse(data);
            } catch (error) {
                return ResponderTextoFalso('❌ Error al leer la base de datos.');
            }

            const usuario = usuariosRegistrados.find(u => u.Usuario === usuarioDestino);
            if (!usuario) {
                return ResponderTextoFalso('❌ Usuario no encontrado en la base de datos.');
            }

            // Añadir recursos según el tipo
            switch (tipo) {
                case 'm':
                    usuario.Moneda += cantidad;
                    break;
                case 'd':
                    usuario.Diamante += cantidad;
                    break;
                case 'b':
                    usuario.Banco += cantidad;
                    break;
            }

            await fs.writeFile(dbPath, JSON.stringify(usuariosRegistrados, null, 2), 'utf8');

            const tipoNombre = tipo === 'm' ? 'monedas' : tipo === 'd' ? 'diamantes' : 'banco';
            await ResponderTextoFalso(`✅ Se añadieron *${cantidad} ${tipoNombre}* a @${usuarioDestino.split('@')[0]}`, [usuarioDestino]);

        } catch (error) {
            console.error('Error en comando add:', error);
            await ResponderTextoFalso('❌ Ocurrió un error al añadir recursos.');
        }
    }
};