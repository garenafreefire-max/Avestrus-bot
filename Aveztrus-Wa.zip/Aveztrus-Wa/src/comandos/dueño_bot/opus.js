const { downloadMediaMessage } = require('@whiskeysockets/baileys');

module.exports = {
    descripcion: 'Convierte un audio citado a nota de voz compatible con canales',
    comando: ['opus', 'notavoz', 'ptt'],
    ejecutar: async (ctx) => {
        const { m, responderTexto, sock, jid } = ctx;

        try {
            // Verificar si hay un mensaje citado
            const quotedMessage = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            
            if (!quotedMessage) {
                await responderTexto('❌ Debes citar un mensaje de audio para convertirlo a nota de voz.');
                return;
            }

            // Verificar si el mensaje citado contiene audio
            const audioMessage = quotedMessage.audioMessage;
            
            if (!audioMessage) {
                await responderTexto('❌ El mensaje citado no contiene un audio. Por favor cita un mensaje con audio.');
                return;
            }

            // Crear mensaje simulado para descargar el audio
            const quotedMsg = {
                key: {
                    remoteJid: m.key.remoteJid,
                    participant: m.message.extendedTextMessage.contextInfo.participant,
                    id: m.message.extendedTextMessage.contextInfo.stanzaId
                },
                message: quotedMessage
            };

            await responderTexto('🔄 Convirtiendo audio a nota de voz...');

            // Descargar el audio citado
            const mediaBuffer = await downloadMediaMessage(
                quotedMsg,
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );

            if (!mediaBuffer) {
                await responderTexto('❌ No se pudo descargar el audio. Inténtalo de nuevo.');
                return;
            }

            // Enviar directamente como nota de voz usando la función nativa de WhatsApp
            // Solo agregamos ptt: true para que sea tratado como nota de voz
            await sock.sendMessage(jid, {
                audio: mediaBuffer,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true
            });

            await responderTexto('✅ Audio convertido a nota de voz exitosamente. Ahora es compatible con canales.');

        } catch (error) {
            console.error('Error en comando opus:', error);
            
            if (error.message.includes('Media download failed')) {
                await responderTexto('❌ No se pudo descargar el audio. Es posible que el archivo sea muy antiguo o haya expirado.');
            } else if (error.message.includes('Invalid media message')) {
                await responderTexto('❌ El formato del audio no es válido o está dañado.');
            } else {
                await responderTexto('❌ Ocurrió un error al procesar el audio. Inténtalo de nuevo más tarde.');
            }
        }
    }
};