const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const axios = require('axios');
const { iniciarGemini, setEnviarFuncion, procesarMensaje } = require('./gemini');
const NodeCache = require('node-cache');
const { handleCommandNotFound } = require('./system/function/suggestion.js');
const myCache = new NodeCache({ stdTTL: 600 });
let config = require('../config.json');

// 🔹 Función para crear un retraso en milisegundos
async function delay(ms) {
    if (ms > 0) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    return Promise.resolve();
}

// --- Lógica del estado del bot (Integrada) ---
const statusFile = path.join(__dirname, 'database', 'bot_status.json');

// Crear archivo si no existe
if (!fs.existsSync(statusFile)) {
    fs.mkdirSync(path.dirname(statusFile), { recursive: true });
    fs.writeFileSync(statusFile, JSON.stringify({ global: true, groups: [] }, null, 2));
}

// Obtener estado
function getBotStatus(jid) {
    try {
        const data = fs.readFileSync(statusFile, 'utf8');
        const status = JSON.parse(data);

        const globalStatus = status.global === true;
        const groupStatus = jid && Array.isArray(status.groups) 
            ? !status.groups.includes(jid) // si está en la lista → apagado
            : true;

        return { global: globalStatus, group: groupStatus };
    } catch (e) {
        console.error('Error leyendo el estado del bot:', e);
        return { global: true, group: true };
    }
}

// Cambiar estado
function setBotStatus(jid, turnOn) {
    try {
        const data = fs.readFileSync(statusFile, 'utf8');
        const currentStatus = JSON.parse(data);

        if (!Array.isArray(currentStatus.groups)) {
            currentStatus.groups = [];
        }

        if (!jid) {
            currentStatus.global = turnOn;
        } else {
            if (turnOn) {
                // Encender → quitar de la lista
                currentStatus.groups = currentStatus.groups.filter(id => id !== jid);
            } else {
                // Apagar → agregar si no está
                if (!currentStatus.groups.includes(jid)) {
                    currentStatus.groups.push(jid);
                }
            }
        }

        fs.writeFileSync(statusFile, JSON.stringify(currentStatus, null, 2));
        return true;
    } catch (e) {
        console.error('Error escribiendo el estado del bot:', e);
        return false;
    }
}
// --- Fin de la lógica del estado del bot ---

// Función para cargar/recargar la configuración y comandos
function cargarModulos() {
    delete require.cache[require.resolve('../config.json')];
    
    const comandos = {};
    const basePath = path.join(__dirname, 'comandos');

    // Función auxiliar para recorrer carpetas recursivamente
    function cargarComandosDesdeRuta(ruta, categoria, requiereRegistro = false, needAdminBot = false) {
        if (!fs.existsSync(ruta)) return;
        
        const elementos = fs.readdirSync(ruta, { withFileTypes: true });

        for (const elemento of elementos) {
            const fullPath = path.join(ruta, elemento.name);
            if (elemento.isDirectory()) {
                // Si la carpeta es 'RegComan', activamos el requisito de registro
                const nuevoRequerimiento = elemento.name.toLowerCase() === 'regcoman' || requiereRegistro;
                const nuevoNeedAdminBot = elemento.name.toLowerCase() === 'needadminbot' || needAdminBot;
                cargarComandosDesdeRuta(fullPath, categoria, nuevoRequerimiento, nuevoNeedAdminBot);
            } else if (elemento.isFile() && elemento.name.endsWith('.js')) {
                const comandoPath = fullPath;
                if (require.cache[require.resolve(comandoPath)]) {
                    delete require.cache[require.resolve(comandoPath)];
                }

                try {
                    const comando = require(comandoPath);
                    if (comando && comando.comando && Array.isArray(comando.comando)) {
                        comando.categoria = categoria;
                        comando.requiereRegistro = requiereRegistro;
                        comando.needAdminBot = needAdminBot;
                        comandos[categoria] = comandos[categoria] || [];
                        comandos[categoria].push(comando);
                    } else {
                        console.error(`⚠️ Comando inválido en ${elemento.name}: No tiene una propiedad 'comando' válida.`);
                    }
                } catch (e) {
                    console.error(`❌ Error cargando comando ${elemento.name} en ${categoria}:`, e);
                }
            }
        }
    }

    const categoriasPrincipales = ['miembro', 'admin', 'dueño_grupo', 'dueño_bot', 'privado'];

    for (const categoria of categoriasPrincipales) {
        const categoriaPath = path.join(basePath, categoria);
        cargarComandosDesdeRuta(categoriaPath, categoria);
    }
    
    const comandosMap = new Map();

    for (const categoria in comandos) {
        comandos[categoria].forEach(cmd => {
            cmd.comando.forEach(alias => {
                comandosMap.set(alias, cmd);
            });
        });
    }

    return { config, comandosMap, myCache };
}

// Función para guardar la configuración actualizada
function guardarConfig(nuevaConfig) {
    try {
        const configPath = path.join(__dirname, '..', 'config.json');
        fs.writeFileSync(configPath, JSON.stringify(nuevaConfig, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('Error escribiendo la configuración:', e);
        return false;
    }
}

const mediaPath = path.join(__dirname, 'media');
const audioPath = path.join(mediaPath, 'audio');
if (!fs.existsSync(mediaPath)) fs.mkdirSync(mediaPath, { recursive: true });
if (!fs.existsSync(audioPath)) fs.mkdirSync(audioPath, { recursive: true });

function recargarConfig() {
    ({ config, comandosMap } = cargarModulos());
    console.log(`✅ Configuración y comandos recargados. Nuevo prefijo: '${config.prefijo}'`);
}

const horaInicioBot = new Date();

module.exports = function iniciarBot(sock) {
    let { comandosMap } = cargarModulos();
    iniciarGemini(sock);

    // 🔹 Función para verificar si el bot es administrador del grupo
async function esBotAdmin(jid) {
    if (!jid.endsWith('@g.us') && !jid.endsWith('@lid')) return false;
    
    try {
        const metadata = await sock.groupMetadata(jid);
        const botInfo = sock.user;
        
        if (!botInfo) return false;
        
        // Función para normalizar JIDs (remover device ID)
        const normalizeJid = (jid) => jid?.replace(/:\d+@/, '@');
        
        // JIDs normalizados del bot
        const botNormalizedJids = [
            normalizeJid(botInfo.id),
            normalizeJid(botInfo.lid)
        ].filter(Boolean);
        
        // Buscar al bot en los participantes
        const botParticipant = metadata.participants.find(participant => 
            botNormalizedJids.includes(normalizeJid(participant.id))
        );
        
        // Verificar si es admin
        return botParticipant && 
               (botParticipant.admin === 'admin' || 
                botParticipant.admin === 'superadmin');
                
    } catch {
        return false;
    }
}

    async function getPushName(jid) {
        try {
            const [contact] = await sock.onWhatsApp(jid);
            return contact?.pushName || jid.split('@')[0];
        } catch {
            return jid.split('@')[0];
        }
    }
    
    // --- LÓGICA DE BIENVENIDA Y DESPEDIDA ---
    const welcomeConfigPath = path.join(__dirname, 'database', 'welcome.json');
    
    sock.ev.on('group-participants.update', async (update) => {
        const { id, participants, action } = update;

        // 🔹 1. Verificación inicial para ver si es un grupo válido.
        if (!id.endsWith('@g.us')) return;

        // 🔹 2. Verificamos si el bot fue el que salió.
        const botJid = sock.user?.id || `${config.Botnumero}@s.whatsapp.net`;
        const botSalio = action === 'remove' && participants.includes(botJid);
        if (botSalio) {
            console.log(`[AVISO] El bot ${botJid} salió del grupo: ${id}.`);
            return; // Salimos de la función para no procesar nada más.
        }

        // 3. Cargar configuración de bienvenida.
        let welcomeConfig = {};
        if (fs.existsSync(welcomeConfigPath)) {
            try {
                welcomeConfig = JSON.parse(fs.readFileSync(welcomeConfigPath, 'utf8'));
            } catch (e) {
                console.error('Error al leer welcome.json:', e);
            }
        }
        
        // 🚨 4. NUEVA VERIFICACIÓN DE ESTADO para salir temprano si el bot está inactivo.
        const botStatus = getBotStatus(id);
        
        // La condición para *NO* continuar es:
        // (El bot está globalmente apagado) O (El bot está apagado en este grupo) O (No hay configuración de bienvenida para este grupo)
        if (!botStatus.global || !botStatus.group || !welcomeConfig[id]) {
            // Si el bot está apagado globalmente o en el grupo, y no es el bot saliendo, no procesamos.
            // Si la bienvenida no está configurada, tampoco procesamos.
            return;
        }

        // 🔹 5. Ahora que sabemos que el bot está activo Y la bienvenida está configurada,
        //      podemos obtener metadatos.
        let metadata;
        try {
            metadata = await sock.groupMetadata(id);
        } catch (error) {
            // Capturamos el error 403 por si el bot fue removido antes de que este evento se procese.
            if (error.data === 403) {
                console.log(`[AVISO] Se ignoró un error 403 en el grupo ${id}. El bot probablemente ya no está en el grupo.`);
                return;
            }
            console.error(`Error obteniendo metadatos del grupo ${id}:`, error);
            return;
        }
        const groupName = metadata.subject || "el grupo";

        
        // 6. Lógica de bienvenida/despedida.
        const rutaImagenDefecto = path.join(__dirname, 'media/imagenes/defecto.jpg');
        
        for (const participant of participants) {
            const pushName = await getPushName(participant);
            const menciones = [participant];
            
            try {
                let avatarBuffer;
                try {
                    const avatarUrl = await sock.profilePictureUrl(participant, 'image');
                    const response = await axios.get(avatarUrl, { responseType: 'arraybuffer' });
                    avatarBuffer = Buffer.from(response.data);
                } catch {
                    console.log(`[BIENVENIDA] Usuario ${pushName} no tiene foto de perfil. Usando imagen por defecto.`);
                    if (fs.existsSync(rutaImagenDefecto)) {
                        avatarBuffer = fs.readFileSync(rutaImagenDefecto);
                    } else {
                        console.error(`❌ El archivo de imagen por defecto no se encontró en: ${rutaImagenDefecto}`);
                        continue;
                    }
                }

                if (action === 'add') {
                    let caption = `
🌟 ¡*BIENVENIDO/A*! 🌟
@${participant.split('@')[0]}
Has llegado a *${groupName}* 🎉

Espero que disfrutes de tu estancia aquí.
Para ver la lista de mis comandos, usa:
➡️ *${config.prefijo}menu* ⬅️
`;
                    await delay(config.messageDelayMs);
                    await EnviarFotoFalsa(id, avatarBuffer, caption, menciones);
                    
                } else if (action === 'remove') {
                    let caption = `
👋 ¡Adiós, compañero! 👋
@${participant.split('@')[0]}
Lamentamos que te vayas de *${groupName}*.

¡Vuelve pronto! 😉
`;
                    await delay(config.messageDelayMs);
                    await EnviarFotoFalsa(id, avatarBuffer, caption, menciones);
                }
            } catch (error) {
                console.error('Error al enviar mensaje de bienvenida/despedida:', error);
                // Si el error es un 403, no hacemos nada para evitar que el bot se detenga.
                if (error.data === 403) {
                    console.log(`[AVISO] No se pudo enviar mensaje en el grupo ${id} por falta de permisos.`);
                }
            }
        }
    });


    // --- FIN DE LA LÓGICA DE BIENVENIDA Y DESPEDIDA ---

    const mensajesProcesados = new Set();
    const limpiarCache = () => {
        const tamanoOriginal = mensajesProcesados.size;
        mensajesProcesados.clear();
    };

    setInterval(limpiarCache, 5 * 60 * 1000);

    function obtenerContextInfoFalso() {
        if (!config.CHANNEL_ID) {
            console.warn('CHANNEL_ID no está configurado en config.json. El contexto falso no funcionará.');
            return {};
        }
        if (!config.ChannelName) {
            console.warn('ChannelName no está configurado en config.json. El contexto falso no funcionará.');
            return {};
        }
        
        return {
            forwardingScore: config.Renviado || 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: config.CHANNEL_ID,
                newsletterName: config.ChannelName,
                serverMessageId: config.idmecha
            }
        };
    }

    // --- FUNCIONES DE ENVÍO DE MENSAJES CORREGIDAS ---
    async function enviarTexto(jid, text, mentions = []) {
        await delay(config.messageDelayMs);
        
        const mencionesValidas = Array.isArray(mentions) ? mentions : [];
        
        if (typeof text !== 'string') {
            console.warn('¡Texto no es string! Convertido:', text);
            text = String(text);
        }
        try {
            return await sock.sendMessage(jid, { text, mentions: mencionesValidas });
        } catch (e) {
            console.error('Error en enviarTexto:', e);
        }
    }

    async function responderTexto(m, text, mentions = []) {
        await delay(config.messageDelayMs);
        
        const mencionesValidas = Array.isArray(mentions) ? mentions : [];
        
        if (!m || !m.key || !m.key.remoteJid) {
            console.error('Error: Objeto de mensaje o sus propiedades son nulas al intentar responder.');
            return enviarTexto(m.key.remoteJid || '', text, mencionesValidas);
        }
        if (typeof text !== 'string') {
            console.warn('¡Texto no es string! Convertido:', text);
            text = String(text);
        }
        
        try {
            return await sock.sendMessage(m.key.remoteJid, { text, mentions: mencionesValidas }, { quoted: m });
        } catch (error) {
            console.error('Error en responderTexto (con quoted):', error);
            return enviarTexto(m.key.remoteJid, text, mencionesValidas);
        }
    }

    setEnviarFuncion((m, text, mentions = []) => ResponderTextoFalso(m, text, mentions));

    function cargarArchivoLocal(filePath) {
        try {
            if (!fs.existsSync(filePath)) {
                console.error(`Archivo no encontrado: ${filePath}`);
                return null;
            }
            return fs.readFileSync(filePath);
        } catch (error) {
            console.error('Error cargando archivo local:', error);
            return null;
        }
    }

    async function enviarImagen(jid, image, caption = '', mentions = []) {
        await delay(config.messageDelayMs);
        try {
            let imageBuffer;
            if (typeof image === 'string') {
                if (image.startsWith('http')) {
                    const response = await axios.get(image, { responseType: 'arraybuffer' });
                    imageBuffer = Buffer.from(response.data);
                } else if (fs.existsSync(image)) {
                    imageBuffer = fs.readFileSync(image);
                } else {
                    console.error(`Ruta de imagen inválida: ${image}`);
                    throw new Error('Contenido de imagen inválido');
                }
            } else if (Buffer.isBuffer(image)) {
                imageBuffer = image;
            } else {
                throw new Error('Contenido de imagen inválido');
            }
            
            const mencionesValidas = Array.isArray(mentions) ? mentions : [];
            return await sock.sendMessage(jid, { 
                image: imageBuffer, 
                caption,
                mentions: mencionesValidas 
            });
        } catch (error) {
            console.error('Error enviando imagen:', error);
            await enviarTexto(jid, caption || '❌ Error al enviar imagen');
            return null;
        }
    }

    async function enviarVideo(jid, video, caption = '', isAnimated = false, mentions = []) {
        await delay(config.messageDelayMs);
        try {
            let videoBuffer;
            if (typeof video === 'string') {
                if (video.startsWith('http')) {
                    const response = await axios.get(video, { responseType: 'arraybuffer' });
                    videoBuffer = Buffer.from(response.data);
                } else if (fs.existsSync(video)) {
                    videoBuffer = fs.readFileSync(video);
                } else {
                    console.error(`Ruta de video inválida: ${video}`);
                    throw new Error('Contenido de video inválido');
                }
            } else if (Buffer.isBuffer(video)) {
                videoBuffer = video;
            } else {
                throw new Error('Contenido de video inválido');
            }
            
            const mencionesValidas = Array.isArray(mentions) ? mentions : [];
            return await sock.sendMessage(jid, { 
                video: videoBuffer, 
                caption, 
                gifPlayback: isAnimated,
                mentions: mencionesValidas 
            });
        } catch (error) {
            console.error('Error enviando video:', error);
            await enviarTexto(jid, caption || '❌ Error al enviar video');
            return null;
        }
    }
    
    async function enviarGif(jid, gif, caption = '', mentions = []) {
        await delay(config.messageDelayMs);
        return enviarVideo(jid, gif, caption, true, mentions);
    }
    
    async function enviarDocumento(jid, document, fileName = 'documento', caption = '') {
        await delay(config.messageDelayMs);
        try {
            let documentBuffer;
            if (typeof document === 'string') {
                if (document.startsWith('http')) {
                    const response = await axios.get(document, { responseType: 'arraybuffer' });
                    documentBuffer = Buffer.from(response.data);
                } else if (fs.existsSync(document)) {
                    documentBuffer = fs.readFileSync(document);
                } else {
                    console.error(`Ruta de documento inválida: ${document}`);
                    throw new Error('Contenido de documento inválido');
                }
            } else if (Buffer.isBuffer(document)) {
                documentBuffer = document;
            } else {
                throw new Error('Contenido de documento inválido');
            }
            if (Buffer.isBuffer(documentBuffer)) {
                return await sock.sendMessage(jid, { document: documentBuffer, fileName, caption });
            } else {
                throw new Error('Contenido de documento inválido');
            }
        } catch (error) {
            console.error('Error enviando documento:', error);
            await enviarTexto(jid, caption || '❌ Error al enviar documento');
            return null;
        }
    }

    async function enviarAudio(jid, audio) {
        await delay(config.messageDelayMs);
        try {
            let audioBuffer;
            if (typeof audio === 'string') {
                if (audio.startsWith('http')) {
                    const response = await axios.get(audio, { responseType: 'arraybuffer' });
                    audioBuffer = Buffer.from(response.data);
                } else if (fs.existsSync(audio)) {
                    audioBuffer = fs.readFileSync(audio);
                } else {
                    console.error(`Ruta de audio inválida: ${audio}`);
                    throw new Error('Contenido de audio inválido');
                }
            } else if (Buffer.isBuffer(audio)) {
                audioBuffer = audio;
            } else {
                throw new Error('Contenido de audio inválido');
            }
            if (Buffer.isBuffer(audioBuffer)) {
                return await sock.sendMessage(jid, { audio: audioBuffer, mimetype: 'audio/mp4' });
            } else {
                throw new Error('Contenido de audio inválido');
            }
        } catch (error) {
            console.error('Error enviando audio:', error);
            await enviarTexto(jid, '❌ Error al enviar audio');
            return null;
        }
    }

    async function enviarNotaVoz(jid, audio) {
        await delay(config.messageDelayMs);
        try {
            let audioBuffer;
            if (typeof audio === 'string') {
                if (audio.startsWith('http')) {
                    const response = await axios.get(audio, { responseType: 'arraybuffer' });
                    audioBuffer = Buffer.from(response.data);
                } else if (fs.existsSync(audio)) {
                    audioBuffer = fs.readFileSync(audio);
                } else {
                    console.error(`Ruta de nota de voz inválida: ${audio}`);
                    throw new Error('Contenido de nota de voz inválido');
                }
            } else if (Buffer.isBuffer(audio)) {
                audioBuffer = audio;
            } else {
                throw new Error('Contenido de nota de voz inválido');
            }
            if (Buffer.isBuffer(audioBuffer)) {
                return await sock.sendMessage(jid, { audio: audioBuffer, mimetype: 'audio/mp4', ptt: true });
            } else {
                throw new Error('Contenido de nota de voz inválido');
            }
        } catch (error) {
            console.error('Error enviando nota de voz:', error);
            await enviarTexto(jid, '❌ Error al enviar nota de voz');
            return null;
        }
    }

    async function EnviarNotaVozFalsa(jid, audio) {
        await delay(config.messageDelayMs);
        try {
            const contextInfo = obtenerContextInfoFalso();
            const messageWithContext = {
                audio,
                mimetype: 'audio/mp4',
                ptt: true,
                contextInfo
            };
            return sock.sendMessage(jid, messageWithContext);
        } catch (error) {
            console.error('Error enviando nota de voz falsa:', error);
            return sock.sendMessage(jid, { audio, mimetype: 'audio/mp4', ptt: true });
        }
    }

async function EnviarFotoFalsa(jid, image, caption = '', menciones = []) {
    await delay(config.messageDelayMs);
    try {
        // 1. Obtener el contexto base (sin menciones)
        const contextoBase = obtenerContextInfoFalso(); 
        
        // 2. Combinar el contexto base con las menciones
        const contextInfo = {
            ...contextoBase,
            // ⬇️ ¡AGREGAR mentionedJid AQUÍ!
            mentionedJid: Array.isArray(menciones) ? menciones : [], 
        };
        
        let imageBuffer;
        if (typeof image === 'string') {
            // ... (tu lógica de buffer) ...
            if (image.startsWith('http')) {
                const response = await axios.get(image, { responseType: 'arraybuffer' });
                imageBuffer = Buffer.from(response.data);
            } else if (fs.existsSync(image)) {
                imageBuffer = fs.readFileSync(image);
            } else {
                throw new Error('Contenido de imagen inválido');
            }
        } else if (Buffer.isBuffer(image)) {
            imageBuffer = image;
        } else {
            throw new Error('Contenido de imagen inválido');
        }
        
        // 3. Enviar con el contexto combinado
        return sock.sendMessage(jid, { image: imageBuffer, caption, contextInfo });
    } catch (error) {
        console.error('Error enviando foto falsa:', error);
        return enviarTexto(jid, caption || '❌ Error al enviar foto falsa');
    }
}


    async function EnviarVideoFalsa(jid, video, caption = '', isAnimated = false) {
        await delay(config.messageDelayMs);
        try {
            const contextInfo = obtenerContextInfoFalso();
            let videoBuffer;
            if (typeof video === 'string') {
                if (video.startsWith('http')) {
                    const response = await axios.get(video, { responseType: 'arraybuffer' });
                    videoBuffer = Buffer.from(response.data);
                } else if (fs.existsSync(video)) {
                    videoBuffer = fs.readFileSync(video);
                } else {
                    throw new Error('Contenido de video inválido');
                }
            } else if (Buffer.isBuffer(video)) {
                videoBuffer = video;
            } else {
                throw new Error('Contenido de video inválido');
            }
            
            return sock.sendMessage(jid, { video: videoBuffer, caption, gifPlayback: isAnimated, contextInfo });
        } catch (error) {
            console.error('Error enviando video falso:', error);
            return enviarTexto(jid, caption || '❌ Error al enviar video falso');
        }
    }

    async function EnviarGifFalsa(jid, gif, caption = '') {
        return EnviarVideoFalsa(jid, gif, caption, true);
    }
    
    async function EnviarRespuestaFalsa(jid, text) {
        await delay(config.messageDelayMs);
        try {
            const contextInfo = obtenerContextInfoFalso();
            return sock.sendMessage(jid, { text, contextInfo });
        } catch (error) {
            console.error('Error enviando respuesta falsa:', error);
            return enviarTexto(jid, text);
        }
    }
    
    async function ResponderTextoFalso(m, text, mentions = []) {
        await delay(config.messageDelayMs);
        try {
            if (typeof text !== 'string') {
                text = String(text);
            }
            
            const mencionesValidas = Array.isArray(mentions) ? mentions : [];
            const mencionesOriginales = m.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            const mencionesOriginalesValidas = Array.isArray(mencionesOriginales) ? mencionesOriginales : [];
            
            const quoteContext = {
                stanzaId: m.key.id,
                participant: m.key.participant || m.key.remoteJid,
                quotedMessage: m.message
            };

            const combinedContext = {
                ...obtenerContextInfoFalso(),
                ...quoteContext,
                mentionedJid: mencionesValidas.length > 0 ? mencionesValidas : mencionesOriginalesValidas
            };
            
            return await sock.sendMessage(m.key.remoteJid, {
                text: text,
                mentions: mencionesValidas.length > 0 ? mencionesValidas : [],
                contextInfo: combinedContext
            });
        } catch (error) {
            console.error('❌ Error en ResponderTextoFalso:', error);
            try {
                return await responderTexto(m, text, mentions);
            } catch (fallbackError) {
                console.error('❌ Fallback también falló:', fallbackError);
                return await enviarTexto(m.key.remoteJid, text, mentions);
            }
        }
    }

    async function reaccionarMensaje(m, emoji) {
        await delay(config.messageDelayMs);
        try {
            if (!m || !m.key || !m.key.remoteJid || !m.key.id) {
                throw new Error('Mensaje inválido para reaccionar');
            }
            
            await sock.sendMessage(m.key.remoteJid, {
                react: {
                    text: emoji,
                    key: m.key
                }
            });
        } catch (error) {
            console.error('Error al reaccionar:', error);
            throw error;
        }
    }

    async function ResponderFotoFalsa(m, image, caption = '', mentions = []) {
        await delay(config.messageDelayMs);
        try {
            const quoteContext = {
                stanzaId: m.key.id,
                participant: m.key.participant || m.key.remoteJid,
                quotedMessage: m.message,
            };
            
            const combinedMentions = [
                ...new Set([
                    ...(m.message?.extendedTextMessage?.contextInfo?.mentionedJid || []),
                    ...(mentions || [])
                ])
            ];

            const combinedContext = {
                ...obtenerContextInfoFalso(),
                ...quoteContext,
                mentionedJid: combinedMentions,
            };
            
            let imageBuffer;
            if (typeof image === 'string') {
                if (image.startsWith('http')) {
                    const response = await axios.get(image, { responseType: 'arraybuffer' });
                    imageBuffer = Buffer.from(response.data);
                } else if (fs.existsSync(image)) {
                    imageBuffer = fs.readFileSync(image);
                } else {
                    throw new Error('Contenido de imagen inválido');
                }
            } else if (Buffer.isBuffer(image)) {
                imageBuffer = image;
            } else {
                throw new Error('Contenido de imagen inválido');
            }
            
            return await sock.sendMessage(m.key.remoteJid, { image: imageBuffer, caption, contextInfo: combinedContext });
        } catch (error) {
            console.error('Error en ResponderFotoFalsa:', error);
            return await enviarTexto(m.key.remoteJid, caption || '❌ Error al enviar foto falsa citando');
        }
    }

    async function ResponderVideoFalsa(m, video, caption = '', isAnimated = false) {
        await delay(config.messageDelayMs);
        try {
            const quoteContext = {
                stanzaId: m.key.id,
                participant: m.key.participant || m.key.remoteJid,
                quotedMessage: m.message,
            };
            const combinedContext = {
                ...obtenerContextInfoFalso(),
                ...quoteContext,
                mentionedJid: m.message?.extendedTextMessage?.contextInfo?.mentionedJid || []
            };
            
            let videoBuffer;
            if (typeof video === 'string') {
                if (video.startsWith('http')) {
                    const response = await axios.get(video, { responseType: 'arraybuffer' });
                    videoBuffer = Buffer.from(response.data);
                } else if (fs.existsSync(video)) {
                    videoBuffer = fs.readFileSync(video);
                } else {
                    throw new Error('Contenido de video inválido');
                }
            } else if (Buffer.isBuffer(video)) {
                videoBuffer = video;
            } else {
                throw new Error('Contenido de video inválido');
            }
            
            return await sock.sendMessage(m.key.remoteJid, { video: videoBuffer, caption, gifPlayback: isAnimated, contextInfo: combinedContext });
        } catch (error) {
            console.error('Error en ResponderVideoFalsa:', error);
            return await enviarTexto(m.key.remoteJid, caption || '❌ Error al enviar video falso citando');
        }
    }

    async function ResponderGifFalso(m, gif, caption = '') {
        return ResponderVideoFalsa(m, gif, caption, true);
    }

async function EnviarStickerFalso(m, stickerPath, isAnimated = false, mentions = []) {
    await delay(config.messageDelayMs);

    try {
        if (!stickerPath || typeof stickerPath !== 'string') {
            throw new Error('Ruta inválida: ' + stickerPath);
        }

        // 1️⃣ Preparar contexto falso
        const quoteContext = {
            stanzaId: m.key.id,
            participant: m.key.participant || m.key.remoteJid,
            quotedMessage: m.message
        };

        const combinedMentions = [
            ...new Set([
                ...(m.message?.extendedTextMessage?.contextInfo?.mentionedJid || []),
                ...(Array.isArray(mentions) ? mentions : [])
            ])
        ];

        const contextInfo = {
            ...obtenerContextInfoFalso(),
            ...quoteContext,
            mentionedJid: combinedMentions
        };

        // 2️⃣ Determinar el sticker
        let stickerBuffer;
        if (stickerPath.startsWith('http')) {
            const response = await axios.get(stickerPath, { responseType: 'arraybuffer' });
            stickerBuffer = Buffer.from(response.data);
        } else if (fs.existsSync(stickerPath)) {
            stickerBuffer = fs.readFileSync(stickerPath);
        } else {
            throw new Error('Sticker no encontrado: ' + stickerPath);
        }

        // 3️⃣ Enviar sticker
        return await sock.sendMessage(m.key.remoteJid, {
            sticker: stickerBuffer,
            animated: isAnimated,
            contextInfo
        });

    } catch (error) {
        console.error('❌ Error en EnviarStickerFalso:', error);
        return await ResponderTextoFalso(m, '❌ Error al enviar sticker');
    }
}
    
    const CHANNEL_ID = config.CHANNEL_ID || '';

    async function obtenerPermisoUsuario(jid, userJid) {
        const normalizarJid = (input) => {
            if (!input) return input;
            
            const jidStr = typeof input === 'string' ? input : String(input);
            
            if (jidStr.endsWith('@s.whatsapp.net') ||
                jidStr.endsWith('@g.us') ||
                jidStr.endsWith('@newsletter') ||
                jidStr.endsWith('@lid')) {
                return jidStr;
            }
            return jidStr.includes('@') ? jidStr : `${jidStr}@s.whatsapp.net`;
        };

        const userJidNormalizado = normalizarJid(userJid);
        const botJid = normalizarJid(`${config.Botnumero}@s.whatsapp.net`);
        const botLid = config.BotLid ? normalizarJid(config.BotLid) : null;

        if (config.messageDelayMs > 0) {
            await delay(config.messageDelayMs);
        }

        const identificadoresDueño = [
            ...(Array.isArray(config.Dueño) 
                ? config.Dueño.map(normalizarJid) 
                : [normalizarJid(config.Dueño || '')]),
            
            ...(config.DueñoLid
                ? (Array.isArray(config.DueñoLid)
                    ? config.DueñoLid.map(normalizarJid)
                    : [normalizarJid(config.DueñoLid || '')])
                : [])
        ].filter(Boolean);

        // Verificar si es dueño del bot
        if (identificadoresDueño.includes(userJidNormalizado)) {
            return 'dueño_bot';
        }
        if (userJidNormalizado === botJid || (botLid && userJidNormalizado === botLid)) {
            return 'dueño_bot';
        }
        
        const jidStr = normalizarJid(jid);
        
        if (jidStr.endsWith('@g.us')) {
            try {
                const metadata = await sock.groupMetadata(jidStr);
                const ownerJid = normalizarJid(metadata.owner);
                
                if (ownerJid === userJidNormalizado) {
                    return 'dueño_grupo';
                }
                
                const participant = metadata.participants.find(p => {
                    const pJid = normalizarJid(p.id);
                    return pJid === userJidNormalizado;
                });
                
                if (participant && (participant.admin === 'admin' || participant.admin === 'superadmin')) {
                    return 'admin';
                }
                return 'miembro';
            } catch (error) {
                console.error('Error obteniendo metadatos del grupo:', error);
                return 'miembro';
            }
        } else {
            return 'miembro';
        }
    }

    sock.ev.on('messages.upsert', async ({ messages }) => {
        try {
            for (const m of messages) {
                try {
                    await delay(config.messageDelayMs);
                    const dbPath = path.join(__dirname, 'database', 'muted_users.json');
                    
                    if (!m.key.fromMe && m.key.remoteJid.endsWith('@g.us')) {
                        let mutedUsers = {};
                        try {
                            const data = await fsp.readFile(dbPath, 'utf8');
                            mutedUsers = JSON.parse(data);
                        } catch (readError) {
                            // Ignorar si el archivo no existe
                        }
                        
                        const groupJid = m.key.remoteJid;
                        const senderJid = m.key.participant;

                        if (mutedUsers[groupJid] && mutedUsers[groupJid][senderJid]) {
                            const keyToDelete = {
                                remoteJid: groupJid,
                                fromMe: false,
                                id: m.key.id,
                                participant: senderJid
                            };
                            await delay(config.messageDelayMs);
                            await sock.sendMessage(groupJid, { delete: keyToDelete });
                            continue; 
                        }
                    }
                    
                    const messageDate = new Date(m.messageTimestamp * 1000);
                    if (messageDate < horaInicioBot) {
                        continue;
                    }
                    
                    if (!m || !m.message || m.key.fromMe || m.message.protocolMessage || m.message.reactionMessage) {
                        continue;
                    }
                    
                    const mensajeID = m.key.id;
                    if (mensajesProcesados.has(mensajeID)) {
                        continue;
                    }
                    mensajesProcesados.add(mensajeID);
                    
                    const jid = m.key.remoteJid;
                    const userJid = m.key.participant || jid;
                    
                    if (config.visto) {
                        try {
                            await delay(config.messageDelayMs);
                            await sock.sendPresenceUpdate('composing', jid);
                            await sock.readMessages([m.key]);
                            await sock.sendPresenceUpdate('paused', jid);
                        } catch (e) {
                            // Si el "visto" falla, el bot no se detiene.
                        }
                    }
                    
                    const botStatus = getBotStatus(jid);
                    const textoCompleto = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
                    const [cmdNombre] = textoCompleto.startsWith(config.prefijo) ? textoCompleto.slice(config.prefijo.length).trim().split(/\s+/) : [''];

                    const esComandoEsencial = ['power', 'on', 'off', 'w', 'visto'].includes(cmdNombre);
                    
                    if (!botStatus.global && !esComandoEsencial) {
                        continue;
                    }
                    
                    const botEstaActivo = botStatus.global && (jid.endsWith('@g.us') ? botStatus.group : true);
                    const esComando = textoCompleto.startsWith(config.prefijo);
                    
                    const esComandoDeGrupo = ['on', 'off', 'w'].includes(cmdNombre);
                    if (jid.endsWith('@g.us') && !botStatus.group && !esComandoDeGrupo && !esComandoEsencial) {
                        continue;
                    }

                    if (esComando) {
                        let comando;
                        try {
                            if (jid.endsWith('@g.us')) {
                                try {
                                    await delay(config.messageDelayMs);
                                    await sock.groupMetadata(jid);
                                } catch (error) {
                                    if (error.output?.statusCode === 403 || error?.data === 403) {
                                        continue;
                                    }
                                }
                            }
                            
                            if (m.message.groupSettingChangeMessage) {
                                continue;
                            }
                            // CÓDIGO MODIFICADO PARA SOPORTE UNIVERSAL (Case-Insensitive y Accent-Agnostic)

                            const textoSinPrefijo = textoCompleto.slice(config.prefijo.length).trim();
                            const [cmdNombreEjecutar, ...args] = textoSinPrefijo.split(/\s+/);
                            
                            if (!cmdNombreEjecutar) continue;

                            // 1. Convertir a minúsculas para manejar Menu, MENU, menu, etc.
                            // 2. Normalizar ('NFD') y eliminar acentos y diacríticos para manejar menú, menú, etc.
                            const comandoNormalizado = cmdNombreEjecutar
                                .toLowerCase()
                                .normalize("NFD")
                                .replace(/[\u0300-\u036f]/g, ""); 
                                
                            comando = comandoNormalizado; // Usaremos la versión normalizada para buscar en el mapa
                            
                            // AHORA EL COMANDO BUSCADO SIEMPRE ESTARÁ EN MINÚSCULAS Y SIN ACENTOS
                            
// ...
// Si miras más abajo en el código, notarás que la variable `comando` es la que se usa para buscar el objeto:
// const cmdObj = comandosMap.get(comando); 

const cmdObj = comandosMap.get(comando);

// 🔹 LÓGICA DE SUGERENCIA MOVIDA AL ARCHIVO DE FUNCIÓN
if (!cmdObj) {
    // Prepara el objeto de contexto para la función externa
    const ctx = {
        m,
        responderTexto,
        comandosMap,
        config,
        comando
    };
    await handleCommandNotFound(ctx);
    continue; // Detiene la ejecución si el comando no existe
}
// 🔹 FIN DE LA LÓGICA MOVIDA

// ... (el resto del código para ejecutar el comando)


                            const dbPathReg = path.join(__dirname, 'database', 'UserReg.json');
                            if (cmdObj.requiereRegistro && comando !== 'reg') {
                                try {
                                    const data = await fsp.readFile(dbPathReg, 'utf8');
                                    const usuariosRegistrados = JSON.parse(data);
                                    const usuario = usuariosRegistrados.find(u => u.Usuario === userJid);

                                    if (!usuario) {
                                        await responderTexto(m, `❌ No puedes usar este comando porque no estás registrado.\nRegístrate así: *${config.prefijo}reg Nombre | edad | país*`);
                                        continue;
                                    }
                                } catch (error) {
                                    await responderTexto(m, `❌ No puedes usar este comando porque no estás registrado.\nRegístrate así: *${config.prefijo}reg Nombre | edad | país*`);
                                    continue;
                                }
                            }

                            const esChatPrivado = !jid.endsWith('@g.us');
                            const esComandoPrivado = cmdObj.categoria === 'privado';
                            const esComandoEspecial = ['on', 'off', 'w', 'power', 'visto'].includes(comando);
                            
                            if (esChatPrivado && !esComandoPrivado && !esComandoEspecial) {
                                continue;
                            }
                            
                            if (!esChatPrivado && esComandoPrivado) {
                                continue;
                            }

                            let menciones = [];
                            if (m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
                                menciones = m.message.extendedTextMessage.contextInfo.mentionedJid.map(jid => jid.includes('@') ? jid : `${jid}@s.whatsapp.net`);
                            }
                            if (m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
                                const quotedMessage = m.message.extendedTextMessage.contextInfo.quotedMessage;
                                if (quotedMessage.extendedTextMessage?.contextInfo?.mentionedJid) {
                                    const quotedMenciones = quotedMessage.extendedTextMessage.contextInfo.mentionedJid.map(jid => jid.includes('@') ? jid : `${jid}@s.whatsapp.net`);
                                    menciones = [...new Set([...menciones, ...quotedMenciones])];
                                }
                            }
                            
                            // VERIFICACIÓN DE PERMISOS SIMPLIFICADA
                            const permisoUsuario = await obtenerPermisoUsuario(jid, userJid);

                            // Verificar si el comando necesita que el bot sea admin
                            if (cmdObj.needAdminBot && jid.endsWith('@g.us')) {
                                const botEsAdmin = await esBotAdmin(jid);
                                if (!botEsAdmin) {
                                    await ResponderTextoFalso(m, '❌ No soy administrador del grupo. Por favor, dame permisos de administrador para usar este comando.');
                                    continue;
                                }
                            }

                            // Verificar permisos basados en carpetas
                            if (cmdObj.categoria === 'dueño_bot' && permisoUsuario !== 'dueño_bot') {
                                await ResponderTextoFalso(m, '⚠️ Este comando es solo para el dueño del bot.');
                                continue;
                            }

                            if (cmdObj.categoria === 'dueño_grupo' && !['dueño_grupo', 'dueño_bot'].includes(permisoUsuario)) {
                                await ResponderTextoFalso(m, '⚠️ Este comando es solo para el dueño del grupo.');
                                continue;
                            }

                            if (cmdObj.categoria === 'admin' && !['admin', 'dueño_grupo', 'dueño_bot'].includes(permisoUsuario)) {
                                await ResponderTextoFalso(m, '⚠️ Este comando es solo para administradores.');
                                continue;
                            }
                            
                            const ctx = {
                                m, sock, jid, userJid, args, menciones, nombreComando: comando,
                                permisoUsuario, 
                                esDueñoBot: permisoUsuario === 'dueño_bot',
                                esDueñoGrupo: permisoUsuario === 'dueño_grupo', 
                                esAdmin: ['admin', 'dueño_grupo', 'dueño_bot'].includes(permisoUsuario),
                                esMiembro: true,
                                myCache,
                                enviarTexto: (text, mentions) => enviarTexto(jid, text, mentions),
                                responderTexto: (text, mentions) => responderTexto(m, text, mentions),
                                enviarImagen: (image, caption, mentions) => enviarImagen(jid, image, caption, mentions),
                                enviarVideo: (video, caption, isAnimated, mentions) => enviarVideo(jid, video, caption, isAnimated, mentions),
                                enviarGif: (gif, caption, mentions) => enviarGif(jid, gif, caption, mentions),
                                enviarDocumento: (document, fileName, caption) => enviarDocumento(jid, document, fileName, caption),
                                enviarAudio: (audio) => enviarAudio(jid, audio),
                                enviarNotaVoz: (audio) => enviarNotaVoz(jid, audio),
                                EnviarRespuestaFalsa: (text) => EnviarRespuestaFalsa(jid, text),
                                EnviarFotoFalsa: (image, caption, mentions) => EnviarFotoFalsa(jid, image, caption, mentions),
                                EnviarVideoFalsa: (video, caption) => EnviarVideoFalsa(jid, video, caption),
                                EnviarGifFalsa: (gif, caption) => EnviarGifFalsa(jid, gif, caption),
                                EnviarNotaVozFalsa: (audio) => EnviarNotaVozFalsa(jid, audio),
                                ResponderTextoFalso: (text, mentions = []) => ResponderTextoFalso(m, text, mentions),
                                reaccionarMensaje: (emoji) => reaccionarMensaje(m, emoji),
                                ResponderFotoFalsa: (image, caption, mentions) => ResponderFotoFalsa(m, image, caption, mentions),
                                ResponderVideoFalsa: (video, caption, isAnimated) => ResponderVideoFalsa(m, video, caption, isAnimated),
                                ResponderGifFalso: (gif, caption) => ResponderGifFalso(m, gif, caption),
                                EnviarStickerFalso: EnviarStickerFalso.bind({ sock }),
                                comandosMap, config, CHANNEL_ID,
                                cargarArchivoLocal, recargarConfig, guardarConfig,
                                getBotStatus, setBotStatus, delay
                            };
                            await cmdObj.ejecutar(ctx);
                        } catch (error) {
                            console.error(`Error en comando ${comando || 'desconocido'}:`, error);
                            await responderTexto(m, '❌ Ocurrió un error al ejecutar el comando. Inténtalo de nuevo más tarde.');
                        }
                    } else { // <--- Inicia la lógica para mensajes que NO son comandos
                        const esGrupo = jid.endsWith('@g.us');
                        const botActivoAqui = botStatus.global && (esGrupo ? botStatus.group : true);
                        
                        // 🟢 Nueva variable para verificar el estado de la IA de Géminis
                        const geminiNoApagado = config.geminiGroup !== 'apagado'; 

                        // Solo procedemos si el bot está activo en general Y la IA no ha sido apagada
                        if (botActivoAqui && geminiNoApagado) {
                            
                            // Revisa la configuración de activación:
                            // 1. Es un grupo, O
                            // 2. Es un privado Y la configuración de geminiGroup es 'true' (permite privados)
                            if (esGrupo || (!esGrupo && config.geminiGroup === true)) {
                                try {
                                    await delay(config.messageDelayMs);
                                    await procesarMensaje(m);
                                } catch (error) {
                                    console.error('Error en Gemini IA:', error);
                                }
                            }
                        }
                    } // <--- Cierra el 'else' (Mensaje NO es comando)
                } catch (error) {
                    if (error.message.includes('Bad MAC') || error.message.includes('Failed to decrypt') || error.message.includes('Over 2000 messages into the future!')) {
                        return;
                    }
                    console.error('Ocurrió un error inesperado al procesar un mensaje:', error);
                }
            }
        } catch (error) {
            console.error('Error general en el manejador de mensajes:', error);
        }
    });

    console.log(`✅ Bot inicializado correctamente`);
    
    return {
        enviarTexto,
        responderTexto,
        ResponderTextoFalso,
        reaccionarMensaje
    };
};
