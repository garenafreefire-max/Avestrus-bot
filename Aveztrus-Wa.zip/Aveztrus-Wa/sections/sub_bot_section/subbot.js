const fs = require('fs');
const path = require('path');
const pino = require('pino');

const Baileys = require('@whiskeysockets/baileys');
const {
    makeWASocket,
    DisconnectReason,
    Browsers,
    makeCacheableSignalKeyStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState
} = Baileys;

// Almacenar sesiones temporales activas
const sesionesActivas = new Map();

class SesionEmparejamiento {
    constructor(numeroTelefono, userJid, enviarTexto) {
        this.numeroTelefono = numeroTelefono;
        this.userJid = userJid;
        this.enviarTexto = enviarTexto;
        this.socket = null;
        this.authPath = null;
        this.isConnected = false;
        this.timeoutId = null;
        this.cleanupTimeoutId = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.codigoGenerado = false;
    }

    async iniciar() {
        try {
            // Crear la carpeta de sesiones si no existe
            const sesionesPath = path.resolve('secciones');
            if (!fs.existsSync(sesionesPath)) {
                fs.mkdirSync(sesionesPath, { recursive: true });
                console.log('📁 Carpeta "secciones" creada');
            }
            
            // Crear carpeta auth específica para este usuario
            this.authPath = path.join(sesionesPath, `auth${this.numeroTelefono}@s.whatsapp.net`);
            
            // Limpiar sesión anterior si existe
            if (fs.existsSync(this.authPath)) {
                await this.enviarTexto(`⚠️ Eliminando sesión anterior para +${this.numeroTelefono}...`);
                fs.rmSync(this.authPath, { recursive: true, force: true });
                console.log(`🗑️ Sesión anterior eliminada: ${this.authPath}`);
            }
            
            // Crear el directorio de auth
            fs.mkdirSync(this.authPath, { recursive: true });
            
            await this.enviarTexto('⚙️ Configurando nueva sesión de emparejamiento...');
            
            // Crear socket para emparejamiento
            await this.crearSocket();
            
            // Configurar timeout de 15 minutos para el emparejamiento (más tiempo)
            this.timeoutId = setTimeout(() => {
                this.timeoutEmparejamiento();
            }, 15 * 60 * 1000);
            
            // Auto-limpieza después de 20 minutos
            this.cleanupTimeoutId = setTimeout(() => {
                this.limpiezaAutomatica();
            }, 20 * 60 * 1000);
            
            return true;
            
        } catch (error) {
            console.error('Error iniciando emparejamiento:', error);
            await this.limpiarYNotificar('❌ Error al iniciar el proceso de emparejamiento.');
            return false;
        }
    }

    async crearSocket() {
        try {
            // Crear estado de autenticación
            const { state, saveCreds } = await useMultiFileAuthState(this.authPath);
            
            // Logger configurado
            const logger = pino({ 
                level: 'silent',
                name: `pairing-${this.numeroTelefono}`
            });
            
            // Obtener la versión más reciente de Baileys
            const { version } = await fetchLatestBaileysVersion();
            this.socket = makeWASocket({
                version,
                printQRInTerminal: false,
                auth: {
                    creds: state.creds,
                    keys: makeCacheableSignalKeyStore(state.keys, logger)
                },
                browser: Browsers.ubuntu("Chrome"),
                logger,
                connectTimeoutMs: 60000,
                keepAliveIntervalMs: 30000,
                markOnlineOnConnect: false,
                syncFullHistory: false,
                generateHighQualityLinkPreview: false,
                getMessage: async (key) => {
                    return { conversation: '' };
                }
            });
            
            // Configurar eventos
            this.configurarEventos(saveCreds);
            
            // Verificar si ya está registrado
            if (state.creds.registered) {
                await this.limpiarYNotificar('❌ El número ya tiene una sesión activa registrada.');
                return false;
            }
            
            await this.enviarTexto('🔄 Solicitando código de emparejamiento...');
            
            // Solicitar código de emparejamiento
            const codigo = await this.socket.requestPairingCode(this.numeroTelefono);
            
            if (!codigo) {
                await this.limpiarYNotificar('❌ Error al generar el código de emparejamiento.');
                return false;
            }
            
            // Configurar timeout de 15 minutos para el emparejamiento (más tiempo)
            this.timeoutId = setTimeout(() => {
                this.timeoutEmparejamiento();
            }, 15 * 60 * 1000);
            
            // Auto-limpieza después de 20 minutos
            this.cleanupTimeoutId = setTimeout(() => {
                this.limpiezaAutomatica();
            }, 20 * 60 * 1000);
            
            // Enviar código de emparejamiento
            const mensaje = `
🔐 *CÓDIGO DE EMPAREJAMIENTO GENERADO*

📱 *Número:* +${this.numeroTelefono}
🔑 *Código:* \`${codigo}\`

📋 *PASOS PARA EMPAREJAR:*
1. Abre WhatsApp en tu dispositivo
2. Ve a *Configuración* → *Dispositivos vinculados*
3. Toca *Vincular dispositivo*
4. Selecciona *Vincular con número de teléfono*
5. Ingresa este código: *${codigo}*

⏰ *Estado:* Esperando emparejamiento...
🔄 *Tiempo límite:* 15 minutos

⚠️ *IMPORTANTE:*
• No cierres WhatsApp durante el proceso
• El código expira automáticamente
• Una vez emparejado recibirás confirmación
            `.trim();
            
            await this.enviarTexto(mensaje);
            
            console.log(`✅ Código generado para +${this.numeroTelefono}: ${codigo}`);
            console.log(`📁 Esperando emparejamiento en: ${this.authPath}`);
            
            return true;
            
        } catch (error) {
            console.error('Error iniciando emparejamiento:', error);
            await this.limpiarYNotificar('❌ Error al iniciar el proceso de emparejamiento.');
            return false;
        }
    }

    configurarEventos(saveCreds) {
        // Evento de actualización de conexión
        this.socket.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;
            
            if (connection === 'connecting') {
                console.log(`🔄 Conectando dispositivo +${this.numeroTelefono}...`);
            }
            
            if (connection === 'open') {
                this.isConnected = true;
                console.log(`✅ Dispositivo +${this.numeroTelefono} emparejado exitosamente`);
                
                // Limpiar timeouts
                if (this.timeoutId) clearTimeout(this.timeoutId);
                if (this.cleanupTimeoutId) clearTimeout(this.cleanupTimeoutId);
                
                const usuarioInfo = this.socket.user;
                const mensaje = `
🎉 *¡EMPAREJAMIENTO EXITOSO!*

✅ *Dispositivo conectado correctamente*
📱 *Número:* +${this.numeroTelefono}
👤 *Usuario:* ${usuarioInfo?.name || 'Desconocido'}
🆔 *ID:* ${usuarioInfo?.id || 'No disponible'}

🔗 *Estado:* Conectado y funcional
📡 *Conexión:* Activa

🎊 *¡Tu dispositivo ya puede usar el bot!*

ℹ️ *Sesión guardada en:*
\`secciones/auth${this.numeroTelefono}@s.whatsapp.net\`
                `.trim();
                
                await this.enviarTexto(mensaje);
                
                // Mantener la conexión activa por 5 minutos más para estabilizar
                setTimeout(() => {
                    this.finalizarSesion('✅ Sesión estabilizada y guardada correctamente.');
                }, 5 * 60 * 1000);
            }
            
            if (connection === 'close') {
                const error = lastDisconnect?.error;
                const statusCode = error?.output?.statusCode;
                
                console.log(`❌ Conexión cerrada para +${this.numeroTelefono}: ${statusCode} - ${error?.message || 'Sin mensaje'}`);
                
                if (!this.isConnected) {
                    // Si no se había conectado exitosamente
                    switch (statusCode) {
                        case DisconnectReason.loggedOut:
                            await this.limpiarYNotificar('❌ Emparejamiento cancelado o código incorrecto.');
                            break;
                        case DisconnectReason.badSession:
                            await this.limpiarYNotificar('❌ Sesión inválida. Inténtalo de nuevo.');
                            break;
                        case DisconnectReason.timedOut:
                            await this.limpiarYNotificar('⏰ Tiempo de emparejamiento agotado. Genera un nuevo código.');
                            break;
                        case 401: // Unauthorized - típico durante el proceso de emparejamiento
                            console.log(`🔄 Error 401 durante emparejamiento para +${this.numeroTelefono} - Es normal, continuando...`);
                            // No hacer nada, esto es parte del proceso normal de emparejamiento
                            break;
                        case 403: // Forbidden
                            console.log(`⚠️ Error 403 para +${this.numeroTelefono} - Reconectando...`);
                            this.reconectar();
                            break;
                        case 515: // Stream Errored (restart required)
                            console.log(`🔄 Error 515 para +${this.numeroTelefono} - Reconectando automáticamente...`);
                            this.reconectar();
                            break;
                        case 503: // Service Unavailable  
                        case 502: // Bad Gateway
                            console.log(`🔄 Error ${statusCode} para +${this.numeroTelefono} - Reconectando...`);
                            this.reconectar();
                            break;
                        default:
                            // Para otros códigos de error, solo loguear sin cerrar
                            console.log(`🔄 Desconexión durante emparejamiento (${statusCode}): ${error?.message || 'Desconocido'}`);
                            
                            // Solo cerrar si es un error grave
                            if (statusCode >= 500) {
                                await this.limpiarYNotificar('❌ Error del servidor. Inténtalo de nuevo más tarde.');
                            }
                    }
                } else {
                    // Ya se había conectado exitosamente, cerrar normalmente
                    this.finalizarSesion('✅ Emparejamiento completado.');
                }
            }
        });
        
        // Evento de actualización de credenciales
        this.socket.ev.on('creds.update', saveCreds);
        
        // Evento de mensajes (para detectar actividad)
        this.socket.ev.on('messages.upsert', ({ messages }) => {
            if (this.isConnected) {
                console.log(`📨 Actividad detectada en dispositivo +${this.numeroTelefono}`);
            }
        });
    }

    async reconectar() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            await this.limpiarYNotificar('❌ Máximo de intentos de reconexión alcanzado. Genera un nuevo código.');
            return;
        }

        this.reconnectAttempts++;
        console.log(`🔄 Intento de reconexión ${this.reconnectAttempts}/${this.maxReconnectAttempts} para +${this.numeroTelefono}`);
        
        // Cierra el socket existente antes de reconectar
        if (this.socket) {
            try {
                this.socket.end();
            } catch (err) {
                console.error('Error cerrando socket:', err);
            }
            this.socket = null;
        }

        // Espera breve antes de reconectar (con backoff exponencial)
        const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000);
        console.log(`⏳ Esperando ${delay/1000} segundos antes de reconectar...`);
        
        setTimeout(async () => {
            try {
                await this.crearSocket();
            } catch (error) {
                console.error('Error en reconexión:', error);
            }
        }, delay);
    }

    async timeoutEmparejamiento() {
        console.log(`⏰ Timeout de emparejamiento para +${this.numeroTelefono}`);
        await this.limpiarYNotificar('⏰ Tiempo de emparejamiento agotado (15 minutos). El código ha expirado.\n\nGenera un nuevo código con `$code` para intentar de nuevo.');
    }

    async limpiezaAutomatica() {
        console.log(`🧹 Limpieza automática para +${this.numeroTelefono}`);
        this.finalizarSesion();
    }

    async limpiarYNotificar(mensaje) {
        try {
            await this.enviarTexto(mensaje);
        } catch (err) {
            console.error('Error enviando mensaje de limpieza:', err);
        }
        
        // Limpiar archivos de sesión fallida
        if (this.authPath && fs.existsSync(this.authPath)) {
            try {
                fs.rmSync(this.authPath, { recursive: true, force: true });
                console.log(`🗑️ Archivos de sesión fallida eliminados: ${this.authPath}`);
            } catch (err) {
                console.error('Error eliminando archivos de sesión fallida:', err);
            }
        }
        
        this.finalizarSesion();
    }

    finalizarSesion(mensaje = null) {
        // Enviar mensaje final si se proporciona
        if (mensaje) {
            this.enviarTexto(mensaje).catch(err => {
                console.error('Error enviando mensaje final:', err);
            });
        }
        
        // Limpiar timeouts
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
            this.timeoutId = null;
        }
        
        if (this.cleanupTimeoutId) {
            clearTimeout(this.cleanupTimeoutId);
            this.cleanupTimeoutId = null;
        }
        
        // Cerrar socket
        if (this.socket) {
            try {
                this.socket.end();
            } catch (err) {
                console.error('Error cerrando socket:', err);
            }
            this.socket = null;
        }
        
        // Remover de sesiones activas
        sesionesActivas.delete(this.numeroTelefono);
        
        console.log(`🔌 Sesión finalizada para +${this.numeroTelefono}`);
    }
}

// Función principal para iniciar emparejamiento
async function iniciarEmparejamiento(numeroTelefono, userJid, enviarTexto) {
    try {
        // Verificar si ya hay una sesión activa para este número
        if (sesionesActivas.has(numeroTelefono)) {
            const sesionExistente = sesionesActivas.get(numeroTelefono);
            sesionExistente.finalizarSesion();
            await enviarTexto('⚠️ Sesión anterior cancelada. Iniciando nueva sesión...');
        }
        
        // Crear nueva sesión
        const sesion = new SesionEmparejamiento(numeroTelefono, userJid, enviarTexto);
        sesionesActivas.set(numeroTelefono, sesion);
        
        // Iniciar proceso de emparejamiento
        const exito = await sesion.iniciar();
        
        if (!exito) {
            sesionesActivas.delete(numeroTelefono);
        }
        
        return exito;
        
    } catch (error) {
        console.error('Error en iniciarEmparejamiento:', error);
        sesionesActivas.delete(numeroTelefono);
        throw error;
    }
}

// Función para obtener estado de sesiones activas
function obtenerSesionesActivas() {
    const sesiones = [];
    for (const [numero, sesion] of sesionesActivas.entries()) {
        sesiones.push({
            numero: numero,
            conectado: sesion.isConnected,
            userJid: sesion.userJid
        });
    }
    return sesiones;
}

// Función para limpiar sesiones huérfanas al iniciar
function limpiarSesionesHuerfanas() {
    const sesionesPath = path.resolve('secciones');
    if (fs.existsSync(sesionesPath)) {
        const carpetas = fs.readdirSync(sesionesPath);
        for (const carpeta of carpetas) {
            if (carpeta.startsWith('auth') && carpeta.includes('@s.whatsapp.net')) {
                const numero = carpeta.replace('auth', '').replace('@s.whatsapp.net', '');
                if (!sesionesActivas.has(numero)) {
                    const rutaCarpeta = path.join(sesionesPath, carpeta);
                    try {
                        // Verificar si la sesión está completada (tiene creds.json válido)
                        const credsPath = path.join(rutaCarpeta, 'creds.json');
                        if (fs.existsSync(credsPath)) {
                            const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
                            if (!creds.registered) {
                                // Sesión incompleta, eliminar
                                fs.rmSync(rutaCarpeta, { recursive: true, force: true });
                                console.log(`🧹 Sesión incompleta eliminada: ${carpeta}`);
                            }
                        } else {
                            // Sin credenciales, eliminar
                            fs.rmSync(rutaCarpeta, { recursive: true, force: true });
                            console.log(`🧹 Sesión sin credenciales eliminada: ${carpeta}`);
                        }
                    } catch (err) {
                        console.error(`Error limpiando sesión huérfana ${carpeta}:`, err);
                    }
                }
            }
        }
    }
}

// Limpiar al iniciar el módulo
limpiarSesionesHuerfanas();

module.exports = {
    iniciarEmparejamiento,
    obtenerSesionesActivas,
    limpiarSesionesHuerfanas
};