const { iniciarEmparejamiento, obtenerSesionesActivas } = require('../../system/emparejamiento');

module.exports = {
    nombre: 'code',
    descripcion: 'Genera un código de 8 dígitos para vincular un sub-bot (usa el número del usuario si no se especifica).',
    comando: ['code', 'pairing'],
    categoria: 'dueño_bot', // Se mantiene la categoría de dueño
    
    /**
     * @param {object} ctx - Objeto de contexto del bot.
     */
    ejecutar: async (ctx) => {
        const { m, args, ResponderTextoFalso } = ctx;
        
        // Función de envío segura al JID del chat (usada por el módulo de emparejamiento)
        // Se asume que ResponderTextoFalso(texto) sabe a dónde enviar el mensaje.
        const enviarNotificacion = (texto) => {
            return ResponderTextoFalso(texto); 
        };
        
        let numeroTelefono;

        // 1. Obtener el número de teléfono
        if (args.length === 0) {
            // ⚠️ CORRECCIÓN CLAVE: Obtener el número del JID del remitente y limpiarlo.
            if (m.key.remoteJid && m.key.remoteJid.includes('@s.whatsapp.net')) {
                // Extrae la parte numérica del JID (por ejemplo, de '584244309723@s.whatsapp.net' toma '584244309723')
                numeroTelefono = m.key.remoteJid.split('@')[0];
                await ResponderTextoFalso(`🤖 Intentando emparejar con el número detectado: *+${numeroTelefono}*`);
            } else {
                // Si el JID no es un JID de usuario (ej. broadcast), se requiere argumento
                return ResponderTextoFalso('❌ No se proporcionó un número y no se pudo obtener automáticamente del chat. Por favor, ingrésalo manualmente.');
            }
        } else {
            // Si hay argumento, usar el argumento proporcionado.
            numeroTelefono = args[0].replace(/\D/g, ''); 
        }

        // 2. Validar el número (limpio)
        if (numeroTelefono.length < 9 || numeroTelefono.length > 15) {
            return ResponderTextoFalso('❌ El número de teléfono no es válido. Debe tener entre 9 y 15 dígitos.');
        }
        
        // 3. Verificar sesiones activas
        const sesiones = obtenerSesionesActivas();
        if (sesiones.includes(numeroTelefono)) { 
             await ResponderTextoFalso(`⚠️ Ya hay una sesión activa de emparejamiento para el número +${numeroTelefono}. Se reiniciará.`);
        }
        
        // 4. Iniciar emparejamiento
        try {
            await iniciarEmparejamiento(numeroTelefono, m.key.remoteJid, enviarNotificacion);
            
        } catch (error) {
            console.error('Error al ejecutar el comando code:', error);
            
            const mensajeError = error.message || 'Error Desconocido.';
            
            if (error instanceof Error) {
                ResponderTextoFalso(`❌ Error grave e inesperado al iniciar la sesión: ${mensajeError}`);
            } else {
                ResponderTextoFalso(`❌ Error inesperado: El proceso falló. Mensaje: ${String(error)}`);
            }
        }
    }
};
