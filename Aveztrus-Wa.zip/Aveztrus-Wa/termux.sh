#!/bin/bash

# Actualizar e instalar paquetes esenciales
echo "🚀 Actualizando e instalando paquetes esenciales..."
pkg update && pkg upgrade -y
pkg install nodejs python yt-dlp ffmpeg git yarn -y

# Moverse al directorio del bot si no estás allí
# (Asegúrate de cambiar 'BotComandos' por el nombre de tu directorio si es diferente)
echo "📂 Moviendo al directorio del proyecto..."
cd ~/BotComandos || { echo "Error: El directorio BotComandos no existe. ¿Está en la ruta correcta?"; exit 1; }

# Instalar las librerías con yarn
echo "📦 Instalando librerías con yarn..."
yarn add --no-bin-links yt-search pino node-fetch@2 node-cache axios @hapi/boom @whiskeysockets/baileys@6.7.18 @google/generative-ai

# Iniciar el bot
echo "✅ Todos los paquetes y librerías se han instalado."
echo "▶️ Iniciando el bot..."
yarn start

echo "✨ Script completado."
